#include "windows/settingdialog.h"
#include "functions/common.h"
#include <QLabel>
#include <QMouseEvent>
#include <QPixmap>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPainter>
#include <QPen>
#include <QPoint>
#include <QListWidget>
#include <QStackedWidget>
#include <QListWidgetItem>
#include <QLineEdit>
#include <QComboBox>
#include <QDebug>
#include <QSettings>
#include <QCoreApplication>
#include <QFileDialog>


SettingDlg::SettingDlg(QWidget *parent)
    :QDialog(parent)
{
    resize(520, 280);
    setWindowTitle(tr("全版本更新和数据迁移工具-设置"));
    setWindowFlags(Qt::FramelessWindowHint | Qt::Dialog);
    setWindowIcon(QPixmap(":/title/logo"));

    msg= new CustomMessageBox();
    titleIcon = new QLabel();
    titleLabel = new QLabel();
    closeButton = new QPushButton();
    closeButton->setFixedSize(18, 18);
    closeButton->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/title/close);}"
                               "QPushButton:hover{border-radius:5px; border-image:url(:/title/dclose);}"
                               "QPushButton:pressed{border-radius:5px; border-image:url(:/title/dclose);}");
    titleLabel->setStyleSheet("QLabel{color:white;}");
    titleIcon->setPixmap(QPixmap(":/title/logo"));
    titleIcon->setFixedSize(16, 16);
    titleIcon->setScaledContents(true);
    closeButton->setContentsMargins(0, 0, 0, 5);
    leftWidget = new QListWidget();
    rightWidget = new QStackedWidget();
    QListWidgetItem *srcDir = new QListWidgetItem(tr("源路径设置"));
    QListWidgetItem *toDir = new QListWidgetItem(tr("目标路径设置"));
    QListWidgetItem *language= new QListWidgetItem(tr("语言设置"));
    srcDir->setTextAlignment(Qt::AlignCenter);
    toDir->setTextAlignment(Qt::AlignCenter);
    language->setTextAlignment(Qt::AlignCenter);
    leftWidget->setFocusPolicy(Qt::NoFocus);
    leftWidget->setFixedWidth(100);
    leftWidget->insertItem(1,srcDir);
    leftWidget->insertItem(0,toDir);
    leftWidget->insertItem(2,language);
    leftWidget->setContentsMargins(0, 0, 0, 0);
    leftWidget->setStyleSheet("QListWidget{border:0px;background-color:rgb(244, 244, 244)}"
                              "QListWidget::item{color:rgb(101, 101, 101); height: 32px;}"
                              "QListWidget::item:hover{color:white; background-color:rgb(51, 168, 235);}"
                              "QListWidget::item:selected{border:0px; color:white; background-color:rgb(51, 168, 235);}");

    leftWidget->setCurrentRow(0);
    initSrcWidget();
    initToWidget();
    initlanguageWidget();
    rightWidget->insertWidget(0, srcWidget);
    rightWidget->insertWidget(1, toWidget);
    rightWidget->insertWidget(2,languageWidget);
    cancelBtn = new QPushButton();
    cancelBtn->setFixedSize(90, 23);
    cancelBtn->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                             "QPushButton:hover{border-color:green; background:transparent;}");
    ensureButton= new QPushButton();
    ensureButton->setFixedSize(90,23);
    ensureButton->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                                "QPushButton:hover{border-color:green; background:transparent;}");

    QHBoxLayout *bottomHlayout = new QHBoxLayout();
    bottomHlayout->addSpacing(350);
    bottomHlayout->addWidget(ensureButton);
    bottomHlayout->addWidget(cancelBtn);
    bottomHlayout->setContentsMargins(0, 0, 20, 0);
    QHBoxLayout *centerHlayout = new QHBoxLayout();
    centerHlayout->addWidget(leftWidget, 0, Qt::AlignLeft);
    centerHlayout->addWidget(rightWidget);
    centerHlayout->setContentsMargins(0, 12, 0, 0);

    QHBoxLayout *titleLayout = new QHBoxLayout();
    titleLayout->addWidget(titleIcon, 0, Qt::AlignVCenter);
    titleLayout->addWidget(titleLabel, 0, Qt::AlignVCenter);
    titleLayout->addStretch();
    titleLayout->addWidget(closeButton, 0, Qt::AlignVCenter);
    titleLayout->setSpacing(5);
    titleLayout->setContentsMargins(4, 0, 4, 0);

    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(titleLayout);
    mainLayout->addLayout(centerHlayout);
    mainLayout->addLayout(bottomHlayout);
    mainLayout->addSpacing(8);
    mainLayout->setContentsMargins(1, 6, 0, 1);
    setLayout(mainLayout);
    connect(leftWidget, SIGNAL(currentRowChanged(int)), rightWidget,SLOT(setCurrentIndex(int)));
    connect(closeButton, SIGNAL(clicked()), this, SLOT(closeButtonSlot()));
    translateLanguage();
    readInitDisplay();    
    connect(cancelBtn, SIGNAL(clicked()), this, SLOT(closeButtonSlot()));
    connect(ensureButton,SIGNAL(clicked()),this,SLOT(ensureButtonSlot()));

    zip=new Unzip();
    connect(zip,SIGNAL(unzip_start()),this,SLOT(zip_start()));
    connect(zip,SIGNAL(unzip_end()),this,SLOT(zip_end()));
    connect(zip,SIGNAL(unzip_current_stat(QString)),this,SLOT(zip_current_stat(QString)));
    connect(zip,SIGNAL(unzip_error(QString)),this,SLOT(zip_error_name(QString)));
}

SettingDlg::~SettingDlg()
{
}


void SettingDlg::mousePressEvent(QMouseEvent *event)
{
    if(event->buttons() == Qt::LeftButton)
    {
        mouse_press = true;
    }
    move_point = event->globalPos() - pos();
}

void SettingDlg::mouseReleaseEvent(QMouseEvent *)
{
    mouse_press = false;
}

void SettingDlg::mouseMoveEvent(QMouseEvent *event)
{
    if(mouse_press)
    {
        QPoint move_pos = event->globalPos();
        move(move_pos - move_point);
    }
}

void SettingDlg::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), QPixmap(":/background/back"));
    QPainter painterWidget(this);
    QLinearGradient linearWidget(rect().topLeft(), rect().bottomLeft());
    linearWidget.setColorAt(0, Qt::white);
    linearWidget.setColorAt(0.5, Qt::white);
    linearWidget.setColorAt(1, Qt::white);
    painterWidget.setPen(Qt::white);
    painterWidget.setBrush(linearWidget);
    painterWidget.drawRect(QRect(0, 30, this->width(), this->height()-30));

    QPainter painterLeft(this);
    QLinearGradient linearLeft(rect().topLeft(), rect().bottomLeft());
    linearLeft.setColorAt(0, QColor(244,244,244));
    linearLeft.setColorAt(0.5, QColor(244,244,244));
    linearLeft.setColorAt(1, QColor(244,244,244));
    painterLeft.setPen(QColor(244,244,244));
    painterLeft.setBrush(linearLeft);
    painterLeft.drawRect(QRect(0, 30, 100, this->height()-30-1));

    QPainter painterFrame(this);
    painterFrame.setPen(Qt::gray);
    static const QPointF points[4] = {QPointF(0, 30), QPointF(0, this->height()-1), QPointF(this->width()-1, this->height()-1), QPointF(this->width()-1, 30)};
    painterFrame.drawPolyline(points, 4);
}

void SettingDlg::translateLanguage()
{
    titleLabel->setText(tr("数据迁移-设置"));
    cancelBtn->setText(tr("返回"));
    ensureButton->setText(tr("确定"));
}

void SettingDlg::initSrcWidget()
{
    srcWidget = new QWidget();
    QLabel *picLabel = new QLabel();
    QLabel *musicLabel = new QLabel();
    QLabel *videoLabel = new QLabel();
    QLabel *docLabel = new QLabel();
    picLabel->setText(tr("图片"));
    musicLabel->setText(tr("音乐"));
    videoLabel->setText(tr("视频"));
    docLabel->setText(tr("文档"));

    picLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");
    musicLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");
    videoLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");
    docLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");

    picLineEdit = new QComboBox();
    musicLineEdit = new QComboBox();
    videoLineEdit = new QComboBox();
    docLineEdit = new QComboBox();

    picLineEdit->setEditable(true);
    picLineEdit->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:300px; background-color:white;}"
                            "QComboBox QAbstractItemView::item{height:22px;}"
                            "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                            "QComboBox::drop-down{border:0px;}");
    musicLineEdit->setEditable(true);
    musicLineEdit->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:300px; background-color:white;}"
                            "QComboBox QAbstractItemView::item{height:22px;}"
                            "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                            "QComboBox::drop-down{border:0px;}");
    videoLineEdit->setEditable(true);
    videoLineEdit->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:300px; background-color:white;}"
                            "QComboBox QAbstractItemView::item{height:22px;}"
                            "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                            "QComboBox::drop-down{border:0px;}");
    docLineEdit->setEditable(true);
    docLineEdit->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:300px; background-color:white;}"
                            "QComboBox QAbstractItemView::item{height:22px;}"
                            "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                            "QComboBox::drop-down{border:0px;}");

    restoreBtn = new QPushButton();
    picBtn = new QPushButton();
    musicBtn = new QPushButton() ;
    videoBtn = new QPushButton();
    docBtn = new QPushButton();
    restoreBtn->setStyleSheet("QPushButton{border:0px; width:100px; height:18px; color:rgb(51, 168, 235); background-color:white;}"
                              "QPushButton:hover{border:0px; color:rgb(51, 168, 235); background-color:rgb(244, 244, 244);}");
    restoreBtn->setText(tr("恢复默认路径"));
    picBtn->setFixedSize(30, 24);
    musicBtn->setFixedSize(30, 24);
    videoBtn->setFixedSize(30, 24);
    docBtn->setFixedSize(30, 24);
    picBtn->setStyleSheet("QPushButton{width:30px; height:25px; border-image:url(:/icon/file);}"
                          "QPushButton:hover{width:30px; height:25px; border-image:url(:/icon/dfile);}"
                          "QPushButton:pressed{width:30px; height:25px; border-image:url(:/icon/dfile);}");
    musicBtn->setStyleSheet("QPushButton{width:30px; height:28px; border-image:url(:/icon/file);}"
                          "QPushButton:hover{width:30px; height:25px; border-image:url(:/icon/dfile);}"
                          "QPushButton:pressed{width:30px; height:25px; border-image:url(:/icon/dfile);}");
    videoBtn->setStyleSheet("QPushButton{width:30px; height:25px; border-image:url(:/icon/file);}"
                          "QPushButton:hover{width:30px; height:25px; border-image:url(:/icon/dfile);}"
                          "QPushButton:pressed{width:30px; height:25px; border-image:url(:/icon/dfile);}");
    docBtn->setStyleSheet("QPushButton{width:30px; height:25px; border-image:url(:/icon/file);}"
                          "QPushButton:hover{width:30px; height:25px; border-image:url(:/icon/dfile);}"
                          "QPushButton:pressed{width:30px; height:25px; border-image:url(:/icon/dfile);}");

    QHBoxLayout *hlayout1 = new QHBoxLayout();
    QHBoxLayout *hlayout2 = new QHBoxLayout();
    QHBoxLayout *hlayout3 = new QHBoxLayout();
    QHBoxLayout *hlayout4 = new QHBoxLayout();
    QHBoxLayout *toplayout = new QHBoxLayout();
    QVBoxLayout *vlayout = new QVBoxLayout();

    toplayout->addWidget(restoreBtn, 0, Qt::AlignRight);
    toplayout->setContentsMargins(0, 0, 20, 0);
    hlayout1->addWidget(picLabel);
    hlayout1->addWidget(picLineEdit);
    hlayout1->addWidget(picBtn);
    hlayout1->addSpacing(20);
    hlayout2->addWidget(musicLabel);
    hlayout2->addWidget(musicLineEdit);
    hlayout2->addWidget(musicBtn);
    hlayout2->addSpacing(20);
    hlayout3->addWidget(videoLabel);
    hlayout3->addWidget(videoLineEdit);
    hlayout3->addWidget(videoBtn);
    hlayout3->addSpacing(20);
    hlayout4->addWidget(docLabel);
    hlayout4->addWidget(docLineEdit);
    hlayout4->addWidget(docBtn);
    hlayout4->addSpacing(20);

    vlayout->addLayout(toplayout);
    vlayout->addLayout(hlayout1);
    vlayout->addLayout(hlayout2);
    vlayout->addLayout(hlayout3);
    vlayout->addLayout(hlayout4);
    vlayout->addSpacing(20);
    vlayout->setContentsMargins(0, 0, 0, 0);
    srcWidget->setLayout(vlayout);
    /*下一级设置界面接口*/
    connect(picBtn, SIGNAL(clicked(bool)),this, SLOT(switchPicSetting()));
    connect(musicBtn, SIGNAL(clicked(bool)),this, SLOT(switchMusSetting()));
    connect(videoBtn, SIGNAL(clicked(bool)),this, SLOT(switchVidSetting()));
    connect(docBtn, SIGNAL(clicked(bool)),this, SLOT(switchDocSetting()));
    connect(restoreBtn, SIGNAL(clicked(bool)), this, SLOT(restoreIniFile()));
}


void SettingDlg::initToWidget()
{
    toWidget = new QWidget();
    QLabel *toDirLabel = new QLabel();
    toDirLineEdit = new QComboBox();
    toDirBtn = new QPushButton();
    restoreToBtn = new QPushButton();
//    extractDirLabel =new QLabel();
    toDirLineEdit->setEditable(true);
    toDirLineEdit->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:300px; background-color:white;}"
                                 "QComboBox QAbstractItemView::item{height:22px;}"
                                 "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                                 "QComboBox::drop-down{border:0px;}");
    toDirLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");
//    extractDirLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");
    toDirLabel->setText(tr("源路径"));
    toDirBtn->setFixedSize(30, 24);
    toDirBtn->setStyleSheet("QPushButton{width:30px; height:25px; border-image:url(:/icon/file);}"
                            "QPushButton:hover{width:30px; height:25px; border-image:url(:/icon/dfile);}"
                            "QPushButton:pressed{width:30px; height:25px; border-image:url(:/icon/dfile);}");
    restoreToBtn->setStyleSheet("QPushButton{border:0px; width:100px; height:18px; color:rgb(51, 168, 235); background-color:white;}"
                              "QPushButton:hover{border:0px; color:rgb(51, 168, 235); background-color:rgb(244, 244, 244);}");
    restoreToBtn->setText(tr("恢复默认路径"));
    QHBoxLayout *topHlayout = new QHBoxLayout();
    QHBoxLayout *hlayout1 = new QHBoxLayout();
    QVBoxLayout *toMainLayout = new QVBoxLayout();
    QHBoxLayout *extrac= new QHBoxLayout();
    topHlayout->addWidget(restoreToBtn, 0, Qt::AlignRight);
    topHlayout->setContentsMargins(0, 6, 20, 0);
    hlayout1->addWidget(toDirLabel);
    hlayout1->addWidget(toDirLineEdit);
    hlayout1->addWidget(toDirBtn);
    hlayout1->addSpacing(20);
    extractInfo= new QTextEdit();
    extrac->addWidget(extractInfo);
    extrac->addSpacing(20);
    toMainLayout->addLayout(topHlayout);
    toMainLayout->addLayout(hlayout1);
    toMainLayout->addLayout(extrac);
    toMainLayout->addStretch();
    toWidget->setLayout(toMainLayout);    
    connect(toDirBtn, SIGNAL(clicked(bool)), this, SLOT(setupDstDir()));
    connect(restoreToBtn, SIGNAL(clicked(bool)), this, SLOT(restoreToIniFile()));
}

void SettingDlg::initlanguageWidget()
{
    languageWidget = new QWidget();
    language_combo_box = new QComboBox();
    language_combo_box->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:300px; background-color:white; selection-background-color: darkgray;}"
                                      "QComboBox QAbstractItemView::item{height:22px;}"
                                      "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                                      "QComboBox::drop-down{border:0px;}");

    language_combo_box->addItem(tr("中文"));
    language_combo_box->addItem(tr("英文"));
    QHBoxLayout *hlayout1 = new QHBoxLayout();
    QLabel *languageLabel = new QLabel();
    languageLabel->setStyleSheet("QLabel{color:gray;font-size:14px; font-family:微软雅黑;}");
    languageLabel->setText(tr("当前语言"));
    hlayout1->addWidget(languageLabel,0,Qt::AlignRight);
    hlayout1->setContentsMargins(0,6,20,0);
    hlayout1->addSpacing(20);
    hlayout1->addWidget(language_combo_box);
    hlayout1->addStretch();
    languageWidget->setLayout(hlayout1);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {
        language_combo_box->setCurrentIndex(1);
    }
    else
    {
        language_combo_box->setCurrentIndex(0);
    }
//    connect(language_combo_box, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this, &SettingDlg::onIndexChanged);


}

void SettingDlg::onIndexChanged()
{
    int language = language_combo_box->currentIndex();
    emit switchLanguage(language);
    msg->setInfo(tr("数据迁移"), tr("语言切换完成，请重启软件"), QPixmap(":/Message/yes"), true, true);
    msg->exec();
}


void SettingDlg::readInitDisplay()
{
    /*清除Commbox中现有的内容，重新读取并设置*/
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(DOCUMENT_GROUNP);
    QString docPath = appSetting->value("DEFAULT").toString();
    docLineEdit->addItem(docPath);
    appSetting->endGroup();

    appSetting->beginGroup(PICTURE_GROUNP);
    QString picPath = appSetting->value("DEFAULT").toString();
    picLineEdit->addItem(picPath);
    appSetting->endGroup();

    appSetting->beginGroup(VIDEO_GROUNP);
    QString vidPath = appSetting->value("DEFAULT").toString();
    videoLineEdit->addItem(vidPath);
    appSetting->endGroup();

    appSetting->beginGroup(MUSIC_GROUNP);
    QString musPath = appSetting->value("DEFAULT").toString();
    musicLineEdit->addItem(musPath);
    appSetting->endGroup();

    appSetting->beginGroup(DESTINATION_GROUNP);
    QString dstPath = appSetting->value("DEFAULT").toString();
    toDirLineEdit->addItem(dstPath);
    appSetting->endGroup();
    delete appSetting;
}

void SettingDlg::setupDstDir()
{

    toDirLineEdit->removeItem(0);
    //    QString tmpDstDir = QFileDialog::getExistingDirectory(this, tr("选择源路径"),
    //                                                       "～/",
    //                                                       QFileDialog::ShowDirsOnly| QFileDialog::DontResolveSymlinks);
    //    extractDirLabel->setText("请选择压缩包");
    extractInfo->setText(tr("请选择压缩包"));
//    QString tmpDstDir=QFileDialog::getOpenFileName(this,tr("选择源文件路径"),"~/","*.zip");
    QString tmpDstDir=FileDialog::getOpenFileName(this,tr("选择源文件路径"),"~/","*.zip");
    if(tmpDstDir.isEmpty())
    {
        extractInfo->append(tr("选择为空"));
        return;
    }
    QFileInfo info(tmpDstDir);
    zip->zippath=tmpDstDir;
    zip->topath=info.path();
    extractInfo->append(tr("压缩包:")+tmpDstDir);
    extractInfo->append(tr("解压到")+info.path());
    zip->start();
    tmpDstDir=info.path()+"/DataMigration";
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(DESTINATION_GROUNP);
    toDirLineEdit->addItem(tmpDstDir);
    appSetting->setValue(DEFAULT, tmpDstDir);
    appSetting->endGroup();
    delete appSetting;
    emit modifySetting();
}

void SettingDlg::zip_start()
{
    extractInfo->append(tr("解压开始..."));
    extractInfo->moveCursor(QTextCursor::End);
    cancelBtn->setEnabled(false);
    ensureButton->setEnabled(false);
}

void SettingDlg::zip_end()
{
    extractInfo->append(tr("解压完成"));
    extractInfo->moveCursor(QTextCursor::End);
    cancelBtn->setEnabled(true);
    ensureButton->setEnabled(true);
}

void SettingDlg::zip_current_stat(QString cu)
{
    extractInfo->append(cu);
    extractInfo->moveCursor(QTextCursor::End);
}

void SettingDlg::zip_error_name(QString name)
{
    extractInfo->append(name);
    extractInfo->moveCursor(QTextCursor::End);
    cancelBtn->setEnabled(true);
    ensureButton->setEnabled(true);
}

void SettingDlg::switchPicSetting()
{
//    QString picDir= QFileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QString picDir= FileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QSettings *appSetting=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSetting->beginGroup(PICTURE_GROUNP);
    if(picDir.isEmpty())
    {
//        QString picPath=appSetting->value(DEFAULT).toString();
//        picLineEdit->addItem(picPath);
    }
    else
    {
        picLineEdit->clear();
        picLineEdit->addItem(picDir);
//        appSetting->setValue(DEFAULT,picDir);
    }
    appSetting->endGroup();
    delete appSetting;
    emit picSetting();
}

void SettingDlg::switchMusSetting()
{

//    QString musicDir= QFileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QString musicDir= FileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QSettings *appSetting=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSetting->beginGroup(MUSIC_GROUNP);
    if(musicDir.isEmpty())
    {
//        QString musicPath=appSetting->value(DEFAULT).toString();
//        musicLineEdit->addItem(musicPath);
    }
    else
    {
        musicLineEdit->clear();
        musicLineEdit->addItem(musicDir);
//        appSetting->setValue(DEFAULT,musicDir);
    }
    appSetting->endGroup();
    delete appSetting;
    emit musicSetting();
}

void SettingDlg::switchDocSetting()
{

//    QString docDir= QFileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QString docDir= FileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QSettings *appSetting=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSetting->beginGroup(DOCUMENT_GROUNP);
    if(docDir.isEmpty())
    {
//        QString docPath=appSetting->value(DEFAULT).toString();
//        docLineEdit->addItem(docPath);
    }
    else
    {
        docLineEdit->clear();
        docLineEdit->addItem(docDir);
//        appSetting->setValue(DEFAULT,docDir);
    }
    appSetting->endGroup();
    delete appSetting;
    emit docSetting();
}

void SettingDlg::switchVidSetting()
{

//    QString videoDir= QFileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QString videoDir= FileDialog::getExistingDirectory(this,tr("选择目标路径"),"~/",QFileDialog::ShowDirsOnly|QFileDialog::DontResolveSymlinks);
    QSettings *appSetting=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSetting->beginGroup(VIDEO_GROUNP);
    if(videoDir.isEmpty())
    {
//        QString videoPath=appSetting->value(DEFAULT).toString();
//        videoLineEdit->addItem(videoPath);
    }
    else
    {
        videoLineEdit->clear();
        videoLineEdit->addItem(videoDir);
//        appSetting->setValue(DEFAULT,videoDir);
    }
    appSetting->endGroup();
    delete appSetting;
    emit videoSetting();
}

void SettingDlg::readUpdateDisplay()
{
    /*清除commbox原有的item*/
    docLineEdit->clear();
    picLineEdit->clear();
    videoLineEdit->clear();
    musicLineEdit->clear();
    toDirLineEdit->clear();

    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(DOCUMENT_GROUNP);
    QString docPath = appSetting->value("DEFAULT").toString();
    docLineEdit->addItem(docPath);
    appSetting->endGroup();

    appSetting->beginGroup(PICTURE_GROUNP);
    QString picPath = appSetting->value("DEFAULT").toString();
    picLineEdit->addItem(picPath);
    appSetting->endGroup();

    appSetting->beginGroup(VIDEO_GROUNP);
    QString vidPath = appSetting->value("DEFAULT").toString();
    videoLineEdit->addItem(vidPath);
    appSetting->endGroup();

    appSetting->beginGroup(MUSIC_GROUNP);
    QString musPath = appSetting->value("DEFAULT").toString();

    musicLineEdit->addItem(musPath);
    appSetting->endGroup();

    appSetting->beginGroup(DESTINATION_GROUNP);
    QString dstPath = appSetting->value("DEFAULT").toString();
    toDirLineEdit->addItem(dstPath);
    appSetting->endGroup();
    delete appSetting;
}

void SettingDlg::restoreIniFile()
{
    QString def=QString(getenv("HOME"))+"/DataMigrationOut";
    QList<QComboBox*> list;
    list<<docLineEdit<<picLineEdit<<videoLineEdit<<musicLineEdit;
    QStringList defdir;
    defdir<<def+"/Documents"<<def+"/Pictures"<<def+"/Videos"<<def+"/Musics";
    QStringList group;
    group<<DOCUMENT_GROUNP<<PICTURE_GROUNP<<VIDEO_GROUNP<<MUSIC_GROUNP;
    for(int i=0;i<list.count();i++)
    {
        list.at(i)->removeItem(0);
        QSettings *appSetting=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
        appSetting->beginGroup(group.at(i));
        if(defdir.at(i).isEmpty())
        {
            QString videoPath=appSetting->value(DEFAULT).toString();
            list.at(i)->addItem(videoPath);
        }
        else
        {
            list.at(i)->addItem(defdir.at(i));
            appSetting->setValue(DEFAULT,defdir.at(i));
        }
        appSetting->endGroup();
        delete appSetting;
    }
    emit docSetting();
    emit picSetting();
    emit videoSetting();
    emit musicSetting();
}

void SettingDlg::restoreToIniFile()
{
    toDirLineEdit->removeItem(0);
    QString def=QString(getenv("HOME"))+"/DataMigration";
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(DESTINATION_GROUNP);
//    if (!QFileInfo(def).exists())
//    {
//        QString dstPath = appSetting->value(DEFAULT).toString();
//        toDirLineEdit->addItem(dstPath);
//    }
//    else
//    {
//        toDirLineEdit->addItem(def);
//        appSetting->setValue(DEFAULT, def);
//    }
    toDirLineEdit->addItem(def);
    appSetting->setValue(DEFAULT, def);
    appSetting->endGroup();
    delete appSetting;
    emit modifySetting();
}

void SettingDlg::closeButtonSlot()
{
    readUpdateDisplay();
    hide();
}

void SettingDlg::ensureButtonSlot()
{
    QStringList grouplist;
    grouplist<<VIDEO_GROUNP<<MUSIC_GROUNP<<PICTURE_GROUNP<<DOCUMENT_GROUNP;
    QList<QComboBox*> LineEditlist;
    LineEditlist<<videoLineEdit<<musicLineEdit<<picLineEdit<<docLineEdit;
    for(int i=0;i<LineEditlist.count();i++)
    {
        QSettings *appSetting=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
        appSetting->beginGroup(grouplist.at(i));
        for(int j=0;j<LineEditlist.at(i)->count();j++)
        {
            appSetting->setValue(DEFAULT,LineEditlist.at(i)->itemText(j));
        }
        appSetting->endGroup();
        delete appSetting;
    }
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString vd=appSettings->value("DEFAULT").toString();
    int language = language_combo_box->currentIndex();
    QString v;
    switch(language)
    {
    case UI_ZH:
        language = UI_ZH;
        v="CN";
        break;

    case UI_EN:
        language = UI_EN;
        v="EN";
        break;

    default:
        language = UI_ZH;
        v="CN";
    }
    if(v!=vd)
    {
        onIndexChanged();
    }
    emit docSetting();
    emit videoSetting();
    emit musicSetting();
    emit picSetting();
    hide();
}




#ifndef FILEDIALOG_H
#define FILEDIALOG_H

#include <QWidget>
#include <QFileDialog>
#include <QPushButton>
#include <QDialogButtonBox>
#include <QLabel>
#include <QString>
#include <QFlags>
#include <QObject>
#include <QStringList>
#include <QSettings>
#include <QCoreApplication>
#include "functions/common.h"
class FileDialog : public QFileDialog
{
public:
    static QString getOpenFileName(QWidget *parent = 0,
                            const QString &caption = QString(),
                            const QString &dir = QString(),
                            const QString &filter = QString(),
                            QString *selectedFilter = 0,
                            Options options = 0);
    static QString getExistingDirectory(QWidget *parent = 0,
                                            const QString &caption = QString(),
                                            const QString &dir = QString(),
                                            Options options = ShowDirsOnly);
};

#endif // FILEDIALOG_H

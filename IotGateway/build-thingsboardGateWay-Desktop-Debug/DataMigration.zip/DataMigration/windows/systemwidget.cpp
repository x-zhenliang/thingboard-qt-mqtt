#include "windows/systemwidget.h"
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPixmap>
#include <QPainter>
#include <QPushButton>

SystemWidget::SystemWidget(QWidget *parent)
    :QWidget(parent)
{

    QVBoxLayout *rightLayout = new QVBoxLayout();
    QHBoxLayout *mainLayout = new QHBoxLayout();

    QHBoxLayout *networkTypeout = new QHBoxLayout();
    QHBoxLayout *IPLayout = new QHBoxLayout();
    QHBoxLayout *maskLayout = new QHBoxLayout();
    QHBoxLayout *gatewayLayout = new QHBoxLayout();
    QHBoxLayout *dnsLayout = new QHBoxLayout();
    QHBoxLayout *btnLayout = new QHBoxLayout();
    sysExportBtn = new QPushButton();
    //sysExportBtn
    sysExportBtn->setFixedSize(173, 40);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        sysExportBtn->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/computer/exportone_en); color:white;}"
                                    "QPushButton:hover{border-radius:5px; border-image:url(:/computer/dexportone_en);}"
                                    "QPushButton:pressed{border-radius:5px; border-image:url(:/computer/ddexportone_en);}");
    }
    else
    {
        sysExportBtn->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/computer/exportone); color:white;}"
                                    "QPushButton:hover{border-radius:5px; border-image:url(:/computer/dexportone);}"
                                    "QPushButton:pressed{border-radius:5px; border-image:url(:/computer/ddexportone);}");
    }


    btnLayout->addWidget(sysExportBtn);
    btnLayout->setContentsMargins(0, 20, 0, 0);
    QLabel *leftIcon = new QLabel();
    leftIcon->setPixmap(QPixmap(":/syswin/sysnetwork"));
    leftIcon->setFixedWidth(520);

    QLabel *networklabel = new QLabel();
    networkTypeLabel = new QLabel();
    networklabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    networkTypeLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    networklabel->setText(tr("联网方式"));
    networkTypeout->addWidget(networklabel);
    networkTypeout->addWidget(networkTypeLabel);
    networkTypeout->setSpacing(50);

    QLabel *ipNameLabel = new QLabel();
    ipContentLabel = new QLabel();
    ipNameLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    ipContentLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    ipNameLabel->setText(tr("IP"));
    IPLayout->addWidget(ipNameLabel);
    IPLayout->addWidget(ipContentLabel);
    IPLayout->setSpacing(50);

    QLabel *maskNameLabel = new QLabel();
    maskContentLabel = new QLabel();
    maskNameLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    maskContentLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    maskNameLabel->setText(tr("子网掩码"));
    maskLayout->addWidget(maskNameLabel);
    maskLayout->addWidget(maskContentLabel);
    maskLayout->setSpacing(50);

    QLabel *gatewayNameLabel = new QLabel();
    gatewayContentLabel = new QLabel();
    gatewayNameLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    gatewayContentLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    gatewayNameLabel->setText(tr("网关"));
    gatewayLayout->addWidget(gatewayNameLabel);
    gatewayLayout->addWidget(gatewayContentLabel);
    gatewayLayout->setSpacing(50);

    QLabel *dnsNameLabel = new QLabel();
    dnsContentLabel = new QLabel();
    dnsNameLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    dnsContentLabel->setStyleSheet("QLabel{color:gray; font-size:20px; font-family:微软雅黑;}");
    dnsNameLabel->setText(tr("DNS"));
    dnsLayout->addWidget(dnsNameLabel);
    dnsLayout->addWidget(dnsContentLabel);
    dnsLayout->setSpacing(50);

    rightLayout->addLayout(networkTypeout);
    rightLayout->addLayout(IPLayout);
    rightLayout->addLayout(maskLayout);
    rightLayout->addLayout(gatewayLayout);
    rightLayout->addLayout(dnsLayout);
    rightLayout->setSpacing(15);
    rightLayout->addLayout(btnLayout);
    rightLayout->addStretch();

    //mainLayout->addWidget(leftIcon);
    mainLayout->addStretch();
    mainLayout->addLayout(rightLayout);
    mainLayout->addSpacing(150);
    mainLayout->setContentsMargins(1, 120, 0, 100);
    mainLayout->setSpacing(0);
    setLayout(mainLayout);

    msg=new CustomMessageBox();
    _init();

    connect(sysExportBtn, SIGNAL(clicked(bool)), this, SLOT(exportSys()));
}

SystemWidget::~SystemWidget()
{

}

void SystemWidget::_init()
{
    QSettings setting(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    setting.beginGroup(DESTINATION_GROUNP);
    QString desPath=setting.value(DEFAULT).toString()+"/Network/sock.ini";
    QFile *fd=new QFile(desPath);
    if(!fd->exists())
    {
        qDebug()<<"网络配置文件不存在";
        delete fd;
        return;
    }
    delete fd;
    QSettings set(desPath,QSettings::IniFormat);
    set.beginGroup("Network");
    networkTypeLabel->setText(set.value("NetWorkType").toString());
    ipContentLabel->setText( set.value("IP").toString());
    maskContentLabel->setText(set.value("Mask").toString());
    gatewayContentLabel->setText(set.value("Gate").toString());
    dnsContentLabel->setText(set.value("Dns").toString());
    set.endGroup();
}

void SystemWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), QPixmap(":/syswin/sysnetwork"));

    QPainter painterFrame(this);
    painterFrame.setPen(Qt::gray);
    static const QPointF points[4] = {QPointF(0, 0), QPointF(0, this->height()-1), QPointF(this->width()-1, this->height()-1), QPointF(this->width()-1, 0)};
    painterFrame.drawPolyline(points, 4);
}

int SystemWidget::staticexport()
{
    QString strAll;
    QStringList strList;
    QFile readFile("/etc/network/interfaces");
//    QFile readFile("/home/weiming/interfaces");
    if(readFile.open((QIODevice::ReadOnly|QIODevice::Text)))
    {
        QTextStream stream(&readFile);
        strAll=stream.readAll();
    }
    else
    {
        qDebug()<<"readopen /etc/network/interfaces error";
        return -1;
    }
    readFile.close();
    QFile writeFile("/etc/network/interfaces");
//    QFile writeFile("/home/weiming/interfaces");
    if(writeFile.open(QIODevice::WriteOnly|QIODevice::Text))
    {
        QTextStream stream(&writeFile);
        strList=strAll.split("\n");
        int f=0;
        for(int i=0;i<strList.count();i++)
        {
            if(i==strList.count()-1)
            {
                if(!f)
                {
                    QString nettype=networkTypeLabel->text();
                    if(nettype.contains("自动DNS")||nettype.contains("固定DNS"))
                    {
                        stream<<"auto eth0"<<'\n';
                        stream<<"iface eth0 inet dhcp"<<'\n';
                    }
                    else
                    {
                        stream<<"auto eth0"<<'\n';
                        stream<<"iface eth0 inet static"<<'\n';
                        stream<<"address "<<ipContentLabel->text()<<'\n';
                        stream<<"netmask "<<maskContentLabel->text()<<'\n';
                        stream<<"gateway "<<gatewayContentLabel->text()<<'\n';
                    }
                }
                else
                    stream<<strList.at(i);
            }
            else
            {
                if(strList.at(i).contains("iface eth0 inet")&&(!strList.at(i).contains("#")))
                {
                    f=1;
                    QString tempStr=strList.at(i);
                    QString nett=networkTypeLabel->text();
                    if(nett.contains("自动DNS")||nett.contains("固定DNS"))
                    {
                        stream<<"auto eth0"<<'\n';
                        stream<<"iface eth0 inet dhcp"<<'\n';
                    }
                    else
                    {
                        tempStr.replace(0,tempStr.length(),"iface eth0 inet static");
                        stream<<tempStr<<'\n';
                        i++;
                        if(i>strList.count())
                        {
                            stream<<"address "<<ipContentLabel->text()<<'\n';
                            stream<<"netmask "<<maskContentLabel->text()<<'\n';
                            stream<<"gateway "<<gatewayContentLabel->text();
                            break;
                        }
                        int ip=0,mask=0,gate=0;
                        while(!((tempStr=strList.at(i)).contains("auto")))
                        {
                            if(tempStr.contains("address")&&(!tempStr.contains("#")))
                            {
                                tempStr.replace(0,tempStr.length(),QString("address ")+ipContentLabel->text());
                                stream<<tempStr<<'\n';
                                ip=1;
                            }
                            else if(tempStr.contains("netmask")&&(!tempStr.contains("#")))
                            {
                                tempStr.replace(0,tempStr.length(),QString("netmask ")+maskContentLabel->text());
                                stream<<tempStr<<'\n';
                                mask=1;
                            }
                            else if(tempStr.contains("gateway")&&(!tempStr.contains("#")))
                            {
                                tempStr.replace(0,tempStr.length(),QString("gateway ")+gatewayContentLabel->text());
                                stream<<tempStr<<'\n';
                                gate=1;
                            }
                            else
                            {
                                if(tempStr.contains("#"))
                                {
                                    stream<<tempStr<<'\n';
                                }
                                else
                                {
                                    stream<<"#"<<tempStr<<'\n';
                                }
                            }
                            i++;
                            if(i>=strList.count())
                            {
                                break;
                            }
                        }
                        if(!ip)
                        {
                            stream<<"address "<<ipContentLabel->text()<<'\n';
                        }
                        if(!mask)
                        {
                            stream<<"netmask "<<maskContentLabel->text()<<'\n';
                        }
                        if(!gate)
                        {
                            stream<<"gateway "<<gatewayContentLabel->text()<<'\n';
                        }
                        if(tempStr.contains("auto"))
                        {
                            stream<<tempStr<<'\n';
                        }
                    }
                }
                else
                    stream<<strList.at(i)<<'\n';
            }
        }
    }
    else
    {
        qDebug()<<"writeopen /etc/network/interfaces error";
        return -2;
    }
    writeFile.close();
    QString nett=networkTypeLabel->text();
    if(nett.contains("自动DNS"))
    {
        return 0;
    }
    readFile.setFileName("/etc/resolv.conf");
//    readFile.setFileName("/home/weiming/resolv.conf");
    if(readFile.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        QTextStream stream(&readFile);
        strAll=stream.readAll();
    }
    else
    {
        qDebug()<<"readopen /etc/resolv.conf error";
        return -3;
    }
    readFile.close();
    writeFile.setFileName("/etc/resolv.conf");
//    writeFile.setFileName("/home/weiming/resolv.conf");
    if(writeFile.open(QIODevice::WriteOnly|QIODevice::Text))
    {
        QTextStream stream(&writeFile);
        strList=strAll.split('\n');
        for(int i=0;i<strList.count();i++)
        {
            if(i==strList.count()-1)
            {
                stream<<strList.at(i)<<'\n';
                stream<<"# Dynamic resolv.conf(5) file for glibc resolver(3) generated by resolvconf(8)"<<'\n';
                stream<<"#     DO NOT EDIT THIS FILE BY HAND -- YOUR CHANGES WILL BE OVERWRITTEN"<<'\n';
                stream<<"nameserver "<<dnsContentLabel->text()<<'\n';
            }
            else
            {
                stream<<strList.at(i)<<'\n';
            }
        }
    }
    else
    {
        qDebug()<<"writeopen /etc/resolv.conf error";
        return -4;
    }
    writeFile.close();
    return 0;
}

void SystemWidget::exportSys()
{
    if(staticexport()==0)
    {
        msg->setInfo(tr("数据迁移-网络导入"),tr("网络设置数据导入完成，下次开机时配置生效"),QPixmap(":/Message/yes"),true,true);
        msg->exec();
    }
    else
    {
        msg->setInfo(tr("数据迁移-网络导入"),tr("网络设置数据导入失败"),QPixmap(":/Message/error"),true,true);
        msg->exec();
    }
}

void SystemWidget::system_onekey()
{
    staticexport();
    emit exportSys_onekey_progressBar_num(1,1);
}

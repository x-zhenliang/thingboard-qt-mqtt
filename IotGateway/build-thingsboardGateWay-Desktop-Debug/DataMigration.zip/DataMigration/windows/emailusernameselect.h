#ifndef EMAILUSERNAMESELECT_H
#define EMAILUSERNAMESELECT_H
#include <QDialog>
#include <QWidget>
#include <QPoint>
#include <QMouseEvent>
#include <QPainter>
#include <QPixmap>
#include <QLabel>
#include <QMouseEvent>
#include <QPixmap>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPainter>
#include <QPen>
#include <QPoint>
#include <QListWidget>
#include <QStackedWidget>
#include <QListWidgetItem>
#include <QLineEdit>
#include <QComboBox>
#include <QDebug>
#include <QSettings>
#include <QCoreApplication>
#include <QFileDialog>
#include <QCheckBox>
#include <QStandardItemModel>
#include <QTableView>
class QWidget;
class QLabel;
class QListWidget;
class QStackedWidget;
class QPoint;
class QLineEdit;
class QComboBox;
class EmailUserNameSelect: public QDialog
{
    Q_OBJECT
public:
    explicit EmailUserNameSelect(QWidget*parent = 0);
    ~EmailUserNameSelect();
    void setUserName(QStringList name);
    void setsignal(QString name);
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *);
signals:
    void SelectUserName(QString name);
    void updateUserName(QStringList name);
    void AddUserName(QStringList name,QStringList pass);
public slots:
    void UserAdd(void);
    void UserAddSure(void);
    void TableView_Select(QModelIndex buf);
    void ensureButton_Slot();
private:
    QPoint move_point;
    bool   mouse_press;
    QLabel *titleLabel;
    QLabel *titleIcon;
    QPushButton *closeButton;
    QPushButton *ensureButton;
    QPushButton *cancelButton;
    QPushButton *addButton;
    QPushButton *addsureButton;
    QTableView *leftPathView;
    QStandardItemModel *listItemModel;
    QModelIndex currentindex;
    QStringList sqlusername;
    QLabel *signalLabel;

public:
    void translateLanguage();
};

#endif // EMAILUSERNAMESELECT_H

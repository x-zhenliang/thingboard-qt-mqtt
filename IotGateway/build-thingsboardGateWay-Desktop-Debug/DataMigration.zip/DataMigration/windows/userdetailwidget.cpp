#include "windows/userdetailwidget.h"
#include "windows/userdatamodel.h"
#include "windows/messagebox.h"
#include "functions/common.h"
#include "tools/utils.h"
#include <QLabel>
#include <QMouseEvent>
#include <QPixmap>
#include <QScrollBar>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPainter>
#include <QPen>
#include <QPoint>
#include <QListWidget>
#include <QStackedWidget>
#include <QListWidgetItem>
#include <QLineEdit>
#include <QTableView>
#include <QHeaderView>
#include <QCheckBox>
#include <QSettings>
#include <QCoreApplication>
#include <QDebug>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QProgressBar>



UserDetailWidget::UserDetailWidget(QWidget *parent)
    :QDialog(parent)
{
    /*用于从配置文件中获取文件路径，必须要调用*/
    getInitFilePath();
    msg_pic = new CustomMessageBox();
    msg_mus = new CustomMessageBox();
    msg_vid = new CustomMessageBox();
    msg_doc = new CustomMessageBox();

    th_pic = new QThread();
    th_mus = new QThread();
    th_vid = new QThread();
    th_doc = new QThread();
    th_one = new QThread();

    userdata_pic = new UserData();
    userdata_mus = new UserData();
    userdata_vid = new UserData();
    userdata_doc = new UserData();
    userdata_one = new UserData();

    connect(userdata_pic,SIGNAL(UserDataCopy_Error_name(int,QStringList)),this,SLOT(UserDataCopy_Error_nameSlot(int,QStringList)));
    connect(userdata_pic,SIGNAL(UserData_Copyover_name(int,QString,int)),this,SLOT(UserData_Copyover_nameSlot(int,QString,int)));
    connect(userdata_pic,SIGNAL(UserData_currentCopy_name(int,QString)),this,SLOT(UserData_currentCopy_nameSlot(int,QString)));
    connect(userdata_pic,SIGNAL(UserData_progress_num(int,int)),this,SLOT(UserData_progress_numSlot(int,int)));
    userdata_pic->moveToThread(th_pic);
    connect(th_pic,SIGNAL(started()),userdata_pic,SLOT(CopyFileToPath()));

    connect(userdata_mus,SIGNAL(UserDataCopy_Error_name(int,QStringList)),this,SLOT(UserDataCopy_Error_nameSlot(int,QStringList)));
    connect(userdata_mus,SIGNAL(UserData_Copyover_name(int,QString,int)),this,SLOT(UserData_Copyover_nameSlot(int,QString,int)));
    connect(userdata_mus,SIGNAL(UserData_currentCopy_name(int,QString)),this,SLOT(UserData_currentCopy_nameSlot(int,QString)));
    connect(userdata_mus,SIGNAL(UserData_progress_num(int,int)),this,SLOT(UserData_progress_numSlot(int,int)));
    userdata_mus->moveToThread(th_mus);
    connect(th_mus,SIGNAL(started()),userdata_mus,SLOT(CopyFileToPath()));

    connect(userdata_vid,SIGNAL(UserDataCopy_Error_name(int,QStringList)),this,SLOT(UserDataCopy_Error_nameSlot(int,QStringList)));
    connect(userdata_vid,SIGNAL(UserData_Copyover_name(int,QString,int)),this,SLOT(UserData_Copyover_nameSlot(int,QString,int)));
    connect(userdata_vid,SIGNAL(UserData_currentCopy_name(int,QString)),this,SLOT(UserData_currentCopy_nameSlot(int,QString)));
    connect(userdata_vid,SIGNAL(UserData_progress_num(int,int)),this,SLOT(UserData_progress_numSlot(int,int)));
    userdata_vid->moveToThread(th_vid);
    connect(th_vid,SIGNAL(started()),userdata_vid,SLOT(CopyFileToPath()));

    connect(userdata_doc,SIGNAL(UserDataCopy_Error_name(int,QStringList)),this,SLOT(UserDataCopy_Error_nameSlot(int,QStringList)));
    connect(userdata_doc,SIGNAL(UserData_Copyover_name(int,QString,int)),this,SLOT(UserData_Copyover_nameSlot(int,QString,int)));
    connect(userdata_doc,SIGNAL(UserData_currentCopy_name(int,QString)),this,SLOT(UserData_currentCopy_nameSlot(int,QString)));
    connect(userdata_doc,SIGNAL(UserData_progress_num(int,int)),this,SLOT(UserData_progress_numSlot(int,int)));
    userdata_doc->moveToThread(th_doc);
    connect(th_doc,SIGNAL(started()),userdata_doc,SLOT(CopyFileToPath()));

    connect(userdata_one,SIGNAL(UserData_progress_onekey_num(int,int)),this,SLOT(UserData_progress_onekey_numSlot(int,int)));
    userdata_one->moveToThread(th_one);
    connect(th_one,SIGNAL(started()),userdata_one,SLOT(CopyFileToPath()));

    setWindowFlags(Qt::FramelessWindowHint);
    leftListWidget = new QListWidget();
    rightStackWidget = new QStackedWidget();
    QListWidgetItem *picDetalItem = new QListWidgetItem(tr("图片"));
    QListWidgetItem *vidDetailItem = new QListWidgetItem(tr("视频"));
    QListWidgetItem *musDetailItem = new QListWidgetItem(tr("音乐"));
    QListWidgetItem *docDetailItem = new QListWidgetItem(tr("文档"));
    picDetalItem->setTextAlignment(Qt::AlignCenter);
    vidDetailItem->setTextAlignment(Qt::AlignCenter);
    musDetailItem->setTextAlignment(Qt::AlignCenter);
    docDetailItem->setTextAlignment(Qt::AlignCenter);
    leftListWidget->setFixedWidth(97);
    leftListWidget->insertItem(0, picDetalItem);
    leftListWidget->insertItem(1, vidDetailItem);
    leftListWidget->insertItem(2, musDetailItem);
    leftListWidget->insertItem(3, docDetailItem);
    leftListWidget->setStyleSheet("QListWidget{border:0px;background-color:rgb(244, 244, 244)}"
                                  "QListWidget::item{color:rgb(101, 101, 101); height: 40px;}"
                                  "QListWidget::item:hover{color:white; background-color:rgb(51, 200, 235);}"
                                  "QListWidget::item:selected{border:0px; color:white; background-color:rgb(51, 168, 235);}");
    leftListWidget->setCurrentRow(0);
    leftListWidget->setFocusPolicy(Qt::NoFocus);
    initPicWidget();
    initVidWidget();
    initMusWidget();
    initDocWidget();
    rightStackWidget->insertWidget(0, picDetalWidget);
    rightStackWidget->insertWidget(1, vidDetailWidget);
    rightStackWidget->insertWidget(2, musDetailWidget);
    rightStackWidget->insertWidget(3, docDetailWidget);
    QHBoxLayout *centerHlayout = new QHBoxLayout();
    centerHlayout->addWidget(leftListWidget, 0, Qt::AlignLeft);
    centerHlayout->addWidget(rightStackWidget);
    centerHlayout->setSpacing(0);
    centerHlayout->setContentsMargins(1, 0, 0, 1);
    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(centerHlayout);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    setLayout(mainLayout);
    connect(leftListWidget, SIGNAL(currentRowChanged(int)), rightStackWidget,SLOT(setCurrentIndex(int)));
    connect(leftListWidget, SIGNAL(currentRowChanged(int)), this,SLOT(updateDataModel()));
}

UserDetailWidget::~UserDetailWidget()
{

}

void UserDetailWidget::paintEvent(QPaintEvent *)
{
    QPainter painterWidget(this);
    QLinearGradient linearWidget(rect().topLeft(), rect().bottomLeft());
    linearWidget.setColorAt(0, Qt::white);
    linearWidget.setColorAt(0.5, Qt::white);
    linearWidget.setColorAt(1, Qt::white);
    painterWidget.setPen(Qt::white);
    painterWidget.setBrush(linearWidget);
    painterWidget.drawRect(QRect(0, 30, this->width(), this->height()-30));
    QPainter painterLeft(this);
    QLinearGradient linearLeft(rect().topLeft(), rect().bottomLeft());
    linearLeft.setColorAt(0, QColor(244,244,244));
    linearLeft.setColorAt(0.5, QColor(244,244,244));
    linearLeft.setColorAt(1, QColor(244,244,244));
    painterLeft.setPen(QColor(244,244,244));
    painterLeft.setBrush(linearLeft);
    painterLeft.drawRect(QRect(0, 0, 97, this->height()-5));
    QPainter painterFrame(this);
    painterFrame.setPen(Qt::gray);
    static const QPointF points[4] = {QPointF(0, 0), QPointF(0, this->height()-1), QPointF(this->width()-1, this->height()-1), QPointF(this->width()-1, 0)};
    painterFrame.drawPolyline(points, 4);

}

void UserDetailWidget::translateLanguage()
{
}

void UserDetailWidget::initPicWidget()
{
    picDetalWidget = new QWidget();
    picTableView = new QTableView(this);
    picModel     = new TableModel(this);
    picDelegate = new CheckBoxDelegate(this);
    picTableView->setStyleSheet("QTableView{border:none; background: white;}"
                                "QTableView::item {color:rgb(50, 50, 50); border: none; border-bottom: 0px solid rgb(50, 50, 50);}"
                                "QTableView::item:selected {background: rgb(0, 160, 230);}");
    picTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    picTableView->horizontalHeader()->setStretchLastSection(true);
    picTableView->horizontalHeader()->setHighlightSections(false);
    picTableView->verticalHeader()->setVisible(false);
    picTableView->setShowGrid(false);
    picTableView->setFrameShape(QFrame::NoFrame);
    picTableView->horizontalHeader()->setStyleSheet("QHeaderView::section{height:26px; border:1px solid #333333; border-color:white; background-color:rgb(244, 244, 244);}");
    picTableView->horizontalScrollBar()->setStyleSheet("QScrollBar{background:transparent; height:10px;}"
                                                       "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                       "QScrollBar::handle:hover{background:gray;}"
                                                       "QScrollBar::sub-line{background:transparent;}"
                                                       "QScrollBar::add-line{background:transparent;}");

    picTableView->verticalScrollBar()->setStyleSheet("QScrollBar{background:transparent; width: 10px;}"
                                                     "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                     "QScrollBar::handle:hover{background:gray;}"
                                                     "QScrollBar::sub-line{background:transparent;}"
                                                     "QScrollBar::add-line{background:transparent;}");

    picTableView->setSelectionMode(QAbstractItemView::SingleSelection); //设置为单选模式
    picTableView->setModel(picModel);
    picTableView->setItemDelegate(picDelegate);
    picTableView->setColumnWidth(0,100);
    picTableView->setColumnWidth(1,100);
    picTableView->setColumnWidth(2,100);
    picTableView->setColumnWidth(3,100);
    picTableView->setColumnWidth(4,320);

    QLabel *picCheckPrompt = new QLabel();
    QPushButton *picStartExport = new QPushButton();
    picCheckPrompt->setStyleSheet("QLabel{color:gray;}");
    picCheckPrompt->setText(tr("检测到以下数据可以选择导入"));
    picStartExport->setFixedSize(90, 28);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        picStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport_en); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport_en); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport_en); color:gray;}");
    }
    else
    {
        picStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport); color:gray;}");
    }

    picProgressBar = new QProgressBar();
    picProgressBar->setStyleSheet("QProgressBar{border:none; color:white; text-align:center; background:white; }"
                                  "QProgressBar::chunk{background: rgb(0, 160, 230); }");

    picProgressBar->setRange(0,100);
    picProgressBar->setValue(90);
    picAllchecked = new QCheckBox();
    picAllchecked->setText(tr("全选"));
    picExportToPath = new QPushButton(); //背景设置为透明或者白色，前景色设置为蓝色，显示和更改导出路径
    QLabel *picExportToLabel = new QLabel();
    picAllchecked->setStyleSheet("QCheckBox{color:gray;}");
    picExportToLabel->setStyleSheet("QLabel{color:gray;}");
    picExportToPath->setStyleSheet("QPushButton{border:none; color:rgb(51, 168, 235); background:white;}");
    picExportToLabel->setText(tr("导入路径"));
    picExportToPath->setText(picScanPath);
    QVBoxLayout *picMainLayout = new QVBoxLayout();
    QHBoxLayout *picTopMainLayout = new QHBoxLayout();
    QHBoxLayout *picCenterMainLayout = new QHBoxLayout();
    QHBoxLayout *picBottomMainLayout = new QHBoxLayout();
    picTopMainLayout->addWidget(picCheckPrompt);

    picTopMainLayout->addSpacing(10);
    picTopMainLayout->addWidget(picProgressBar);
    picTopMainLayout->addSpacing(10);
    picTopMainLayout->addWidget(picStartExport);
    picTopMainLayout->setContentsMargins(10, 10, 10, 5);
    picCenterMainLayout->addWidget(picTableView);
    picBottomMainLayout->addWidget(picAllchecked);
    picBottomMainLayout->addSpacing(80);
    picBottomMainLayout->addWidget(picExportToLabel);
    picBottomMainLayout->addWidget(picExportToPath);
    picBottomMainLayout->addStretch();
    picBottomMainLayout->setContentsMargins(50, 0, 0, 5);
    picBottomMainLayout->setSpacing(4);
    picMainLayout->setMargin(0);
    picMainLayout->addLayout(picTopMainLayout);
    picMainLayout->addLayout(picCenterMainLayout);
    picMainLayout->addLayout(picBottomMainLayout);
    picMainLayout->setSpacing(0);
    picMainLayout->setContentsMargins(0, 0, 1, 0);
    picDetalWidget->setLayout(picMainLayout);

    connect(picTableView, SIGNAL(clicked(QModelIndex)), this, SLOT(getPicCheckedSlot(QModelIndex)));
    connect(picAllchecked, SIGNAL(stateChanged(int)),this, SLOT(picCheckedBoxAll(int)));
    connect(picAllchecked, SIGNAL(clicked()),this,SLOT(picAllcheckedSlot()));
    connect(picStartExport, SIGNAL(clicked()), this, SLOT(exportPicSlot()));

}

void UserDetailWidget::initVidWidget()
{

    vidDetailWidget = new QWidget();    
    vidTableView = new QTableView(this);
    vidModel = new TableModel(this);
    vidDelegate = new CheckBoxDelegate(this);
    vidTableView->setStyleSheet("QTableView{border:0px solid rgb(50, 50, 50); background: rgb(255, 255, 255);color: rgb(50, 50, 50);}"
                               "QTableView::item {color:rgb(50, 50, 50); border: none;border-bottom: 0px solid rgb(50, 50, 50);}"
                               "QTableView::item:selected {background: rgb(0, 160, 230);}");

    vidTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    vidTableView->horizontalHeader()->setStretchLastSection(true);
    vidTableView->horizontalHeader()->setHighlightSections(false);
    vidTableView->verticalHeader()->setVisible(false);
    vidTableView->setShowGrid(false);
    vidTableView->setFrameShape(QFrame::NoFrame);
    vidTableView->horizontalHeader()->setStyleSheet("QHeaderView::section{height:26px; border:1px solid #333333; border-color:white; background-color:rgb(244, 244, 244);}");
    vidTableView->horizontalScrollBar()->setStyleSheet("QScrollBar{background:transparent; height:10px;}"
                                                       "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                       "QScrollBar::handle:hover{background:gray;}"
                                                       "QScrollBar::sub-line{background:transparent;}"
                                                       "QScrollBar::add-line{background:transparent;}");

    vidTableView->verticalScrollBar()->setStyleSheet("QScrollBar{background:transparent; width: 10px;}"
                                                     "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                     "QScrollBar::handle:hover{background:gray;}"
                                                     "QScrollBar::sub-line{background:transparent;}"
                                                     "QScrollBar::add-line{background:transparent;}");

    vidTableView->setSelectionMode(QAbstractItemView::SingleSelection); //设置为单选模式
    vidTableView->setModel(vidModel);
    vidTableView->setItemDelegate(vidDelegate);
    vidTableView->setColumnWidth(0,100);
    vidTableView->setColumnWidth(1,100);
    vidTableView->setColumnWidth(2,100);
    vidTableView->setColumnWidth(3,100);
    vidTableView->setColumnWidth(4,320);
    QLabel *vidCheckPrompt = new QLabel();
    QPushButton *vidStartExport = new QPushButton();
    vidCheckPrompt->setStyleSheet("QLabel{color:gray;}");
    vidCheckPrompt->setText(tr("检测到以下数据可以选择导入"));
    vidStartExport->setFixedSize(90, 28);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        vidStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport_en); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport_en); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport_en); color:gray;}");
    }
    else
    {
        vidStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport); color:gray;}");
    }

    vidProgressBar = new QProgressBar();
    vidProgressBar->setStyleSheet("QProgressBar{border:none; color:white; text-align:center; background:white; }"
                                  "QProgressBar::chunk{background: rgb(0, 160, 230); }");

    vidProgressBar->setRange(0,100);


    vidAllchecked = new QCheckBox();
    vidAllchecked->setText(tr("全选"));
    vidExportToPath = new QPushButton();
    QLabel *vidExportToLabel = new QLabel();
    vidAllchecked->setStyleSheet("QCheckBox{color:gray;}");
    vidExportToLabel->setStyleSheet("QLabel{color:gray;}");
    vidExportToPath->setStyleSheet("QPushButton{border:none; color:rgb(51, 168, 235); background:white;}");
    vidExportToLabel->setText(tr("导入路径"));
    vidExportToPath->setText(vidScanPath);

    QVBoxLayout *vidMainLayout = new QVBoxLayout();
    QHBoxLayout *vidTopMainLayout = new QHBoxLayout();
    QHBoxLayout *vidCenterMainLayout = new QHBoxLayout();
    QHBoxLayout *vidBottomMainLayout = new QHBoxLayout();
    vidTopMainLayout->addWidget(vidCheckPrompt);
    vidTopMainLayout->addSpacing(10);
    vidTopMainLayout->addWidget(vidProgressBar);
    vidTopMainLayout->addSpacing(10);
    vidTopMainLayout->addWidget(vidStartExport);
    vidTopMainLayout->setContentsMargins(10, 10, 10, 5);
    vidCenterMainLayout->addWidget(vidTableView);

    vidBottomMainLayout->addWidget(vidAllchecked);
    vidBottomMainLayout->addSpacing(80);
    vidBottomMainLayout->addWidget(vidExportToLabel);
    vidBottomMainLayout->addWidget(vidExportToPath);
    vidBottomMainLayout->addStretch();
    vidBottomMainLayout->setContentsMargins(50, 0, 0, 5);
    vidBottomMainLayout->setSpacing(4);

    vidMainLayout->setMargin(0);
    vidMainLayout->addLayout(vidTopMainLayout);
    vidMainLayout->addLayout(vidCenterMainLayout);
    vidMainLayout->addLayout(vidBottomMainLayout);
    vidMainLayout->setSpacing(0);
    vidMainLayout->setContentsMargins(0, 0, 1, 0);
    vidDetailWidget->setLayout(vidMainLayout);

    connect(vidTableView, SIGNAL(clicked(QModelIndex)), this, SLOT(getVidCheckedSlot(QModelIndex)));
    connect(vidAllchecked, SIGNAL(stateChanged(int)),this, SLOT(vidCheckedBoxAll(int)));
    connect(vidAllchecked, SIGNAL(clicked()),this,SLOT(vidAllcheckedSlot()));
    connect(vidStartExport, SIGNAL(clicked()), this, SLOT(exportVidSlot()));
}
void UserDetailWidget::initMusWidget()
{
    musDetailWidget = new QWidget();
    musTableView = new QTableView(this);
    musModel = new TableModel(this);
    musDelegate = new CheckBoxDelegate(this);
    musTableView->setStyleSheet("QTableView{border:0px solid rgb(50, 50, 50); background: rgb(255, 255, 255);color: rgb(50, 50, 50);}"
                                "QTableView::item {color:rgb(50, 50, 50); border: none;border-bottom: 0px solid rgb(50, 50, 50);}"
                                "QTableView::item:selected {background: rgb(0, 160, 230);}");

    musTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    musTableView->horizontalHeader()->setStretchLastSection(true);
    musTableView->horizontalHeader()->setHighlightSections(false);
    musTableView->verticalHeader()->setVisible(false);
    musTableView->setShowGrid(false);
    musTableView->setFrameShape(QFrame::NoFrame);
    musTableView->horizontalHeader()->setStyleSheet("QHeaderView::section{height:26px; border:1px solid #333333; border-color:white; background-color:rgb(244, 244, 244);}");
    musTableView->horizontalScrollBar()->setStyleSheet("QScrollBar{background:transparent; height:10px;}"
                                                       "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                       "QScrollBar::handle:hover{background:gray;}"
                                                       "QScrollBar::sub-line{background:transparent;}"
                                                       "QScrollBar::add-line{background:transparent;}");

    musTableView->verticalScrollBar()->setStyleSheet("QScrollBar{background:transparent; width: 10px;}"
                                                     "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                     "QScrollBar::handle:hover{background:gray;}"
                                                     "QScrollBar::sub-line{background:transparent;}"
                                                     "QScrollBar::add-line{background:transparent;}");

    musTableView->setSelectionMode(QAbstractItemView::SingleSelection); //设置为单选模式
    musTableView->setModel(musModel);
    musTableView->setItemDelegate(musDelegate);
    musTableView->setColumnWidth(0,100);
    musTableView->setColumnWidth(1,100);
    musTableView->setColumnWidth(2,100);
    musTableView->setColumnWidth(3,100);
    musTableView->setColumnWidth(4,320);
    QLabel *musCheckPrompt = new QLabel();
    QPushButton *musStartExport = new QPushButton();
    musCheckPrompt->setStyleSheet("QLabel{color:gray;}");
    musCheckPrompt->setText(tr("检测到以下数据可以选择导入"));
    musStartExport->setFixedSize(90, 28);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        musStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport_en); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport_en); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport_en); color:gray;}");
    }
    else
    {
        musStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport); color:gray;}");
    }

    musProgressBar = new QProgressBar();
    musProgressBar->setStyleSheet("QProgressBar{border:none; color:white; text-align:center; background:white; }"
                                   "QProgressBar::chunk{background: rgb(0, 160, 230); }");

    musProgressBar->setRange(0,100);
    musAllchecked = new QCheckBox();
    musAllchecked->setText(tr("全选"));
    musExportToPath = new QPushButton();
    QLabel *musExportToLabel = new QLabel();
    musAllchecked->setStyleSheet("QCheckBox{color:gray;}");
    musExportToLabel->setStyleSheet("QLabel{color:gray;}");
    musExportToLabel->setText(tr("导入路径"));
    musExportToPath->setStyleSheet("QPushButton{border:none; color:rgb(51, 168, 235); background:white;}");
    musExportToPath->setText(musScanPath);

    QVBoxLayout *musMainLayout = new QVBoxLayout();
    QHBoxLayout *musTopMainLayout = new QHBoxLayout();
    QHBoxLayout *musCenterMainLayout = new QHBoxLayout();
    QHBoxLayout *musBottomMainLayout = new QHBoxLayout();
    musTopMainLayout->addWidget(musCheckPrompt);
    musTopMainLayout->addSpacing(10);
    musTopMainLayout->addWidget(musProgressBar);
    musTopMainLayout->addSpacing(10);
    musTopMainLayout->addWidget(musStartExport);
    musTopMainLayout->setContentsMargins(10, 10, 10, 5);
    musCenterMainLayout->addWidget(musTableView);
    musBottomMainLayout->addWidget(musAllchecked);
    musBottomMainLayout->addSpacing(80);
    musBottomMainLayout->addWidget(musExportToLabel);
    musBottomMainLayout->addWidget(musExportToPath);
    musBottomMainLayout->addStretch();
    musBottomMainLayout->setContentsMargins(50, 0, 0, 5);
    musBottomMainLayout->setSpacing(4);
    musMainLayout->setMargin(0);
    musMainLayout->addLayout(musTopMainLayout);
    musMainLayout->addLayout(musCenterMainLayout);
    musMainLayout->addLayout(musBottomMainLayout);
    musMainLayout->setSpacing(0);
    musMainLayout->setContentsMargins(0, 0, 1, 0);
    musDetailWidget->setLayout(musMainLayout);

    connect(musTableView, SIGNAL(clicked(QModelIndex)), this, SLOT(getMusicCheckedSlot(QModelIndex)));
    connect(musAllchecked, SIGNAL(stateChanged(int)),this, SLOT(musCheckedBoxAll(int)));
    connect(musAllchecked, SIGNAL(clicked()),this,SLOT(musAllcheckedSlot()));
    connect(musStartExport, SIGNAL(clicked()), this, SLOT(exportMusSlot()));
}

void UserDetailWidget::initDocWidget()
{
    docDetailWidget = new QWidget();
    docTableView = new QTableView(this);
    docModel = new TableModel(this);
    docDelegate = new CheckBoxDelegate(this);
    docTableView->setStyleSheet("QTableView{border:0px solid rgb(50, 50, 50); background: rgb(255, 255, 255);color: rgb(50, 50, 50);}"
                               "QTableView::item {color:rgb(50, 50, 50); border: none;border-bottom: 0px solid rgb(50, 50, 50);}"
                               "QTableView::item:selected {background: rgb(0, 160, 230);}");

    docTableView->setSelectionBehavior(QAbstractItemView::SelectRows);
    docTableView->horizontalHeader()->setStretchLastSection(true);
    docTableView->horizontalHeader()->setHighlightSections(false);
    docTableView->verticalHeader()->setVisible(false);
    docTableView->setShowGrid(false);
    docTableView->setFrameShape(QFrame::NoFrame);
    docTableView->horizontalHeader()->setStyleSheet("QHeaderView::section{height:26px; border:1px solid #333333; border-color:white; background-color:rgb(244, 244, 244);}");
    docTableView->horizontalScrollBar()->setStyleSheet("QScrollBar{background:transparent; height:10px;}"
                                                       "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                       "QScrollBar::handle:hover{background:gray;}"
                                                       "QScrollBar::sub-line{background:transparent;}"
                                                       "QScrollBar::add-line{background:transparent;}");

    docTableView->verticalScrollBar()->setStyleSheet("QScrollBar{background:transparent; width: 10px;}"
                                                     "QScrollBar::handle{background:lightgray; border:2px solid transparent; border-radius:5px;}"
                                                     "QScrollBar::handle:hover{background:gray;}"
                                                     "QScrollBar::sub-line{background:transparent;}"
                                                     "QScrollBar::add-line{background:transparent;}");

    docTableView->setSelectionMode(QAbstractItemView::SingleSelection); //设置为单选模式
    docTableView->setModel(docModel);
    docTableView->setItemDelegate(docDelegate);
    docTableView->setColumnWidth(0,100);
    docTableView->setColumnWidth(1,100);
    docTableView->setColumnWidth(2,100);
    docTableView->setColumnWidth(3,100);
    docTableView->setColumnWidth(4,320);
    QLabel *docCheckPrompt = new QLabel();
    QPushButton *docStartExport = new QPushButton();
    docCheckPrompt->setStyleSheet("QLabel{color:gray;}");
    docCheckPrompt->setText(tr("检测到以下数据可以选择导入"));
    docStartExport->setFixedSize(90, 28);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        docStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport_en); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport_en); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport_en); color:gray;}");
    }
    else
    {
        docStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport); color:gray;}"
                                      "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport); color:gray;}"
                                      "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport); color:gray;}");
    }


    docProgressBar = new QProgressBar();
    docProgressBar->setStyleSheet("QProgressBar{border:none; color:white; text-align:center; background:white; }"
                                  "QProgressBar::chunk{background: rgb(0, 160, 230); }");

    docProgressBar->setRange(0,100);
    docAllchecked = new QCheckBox();
    docAllchecked->setText(tr("全选"));
    docExportToPath = new QPushButton();
    QLabel *docExportToLabel = new QLabel();
    docAllchecked->setStyleSheet("QCheckBox{color:gray;}");
    docExportToLabel->setStyleSheet("QLabel{color:gray;}");
    docExportToPath->setStyleSheet("QPushButton{border:none; color:rgb(51, 168, 235); background:white;}");
    docExportToLabel->setText(tr("导入路径"));
    docExportToPath->setText(docScanPath);
    QVBoxLayout *docMainLayout = new QVBoxLayout();
    QHBoxLayout *docTopMainLayout = new QHBoxLayout();
    QHBoxLayout *docCenterMainLayout = new QHBoxLayout();
    QHBoxLayout *docBottomMainLayout = new QHBoxLayout();
    docTopMainLayout->addWidget(docCheckPrompt);
    docTopMainLayout->addSpacing(10);
    docTopMainLayout->addWidget(docProgressBar);
    docTopMainLayout->addSpacing(10);
    docTopMainLayout->addWidget(docStartExport);
    docTopMainLayout->setContentsMargins(10, 10, 10, 5);
    docCenterMainLayout->addWidget(docTableView);
    docBottomMainLayout->addWidget(docAllchecked);
    docBottomMainLayout->addSpacing(80);
    docBottomMainLayout->addWidget(docExportToLabel);
    docBottomMainLayout->addWidget(docExportToPath);
    docBottomMainLayout->addStretch();
    docBottomMainLayout->setContentsMargins(50, 0, 0, 5);
    docBottomMainLayout->setSpacing(4);
    docMainLayout->setMargin(0);
    docMainLayout->addLayout(docTopMainLayout);
    docMainLayout->addLayout(docCenterMainLayout);
    docMainLayout->addLayout(docBottomMainLayout);
    docMainLayout->setSpacing(0);
    docMainLayout->setContentsMargins(0, 0, 1, 0);
    docDetailWidget->setLayout(docMainLayout);
    connect(docTableView, SIGNAL(clicked(QModelIndex)), this, SLOT(getDocCheckedSlot(QModelIndex)));
    connect(docAllchecked, SIGNAL(stateChanged(int)),this, SLOT(docCheckedBoxAll(int)));
    connect(docAllchecked, SIGNAL(clicked()),this,SLOT(docAllcheckedSlot()));
    connect(docStartExport,SIGNAL(clicked()), this, SLOT(exportDocSlot()));
}

void UserDetailWidget::getInitFilePath()
{
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope,
                                          QCoreApplication::organizationName(),
                                          QCoreApplication::applicationName());
    appSetting->beginGroup(DESTINATION_GROUNP);
    dstDirPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    appSetting->beginGroup(PICTURE_GROUNP);
    picScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    appSetting->beginGroup(DOCUMENT_GROUNP);
    docScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    appSetting->beginGroup(MUSIC_GROUNP);
    musScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    appSetting->beginGroup(VIDEO_GROUNP);
    vidScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
}

void UserDetailWidget::updateReadIniFilePath()
{
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope,
                                          QCoreApplication::organizationName(),
                                          QCoreApplication::applicationName());
    appSetting->beginGroup(DESTINATION_GROUNP);
    dstDirPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();

    appSetting->beginGroup(PICTURE_GROUNP);
    picScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    picExportToPath->setText(picScanPath);
    appSetting->beginGroup(DOCUMENT_GROUNP);
    docScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    docExportToPath->setText(docScanPath);
    appSetting->beginGroup(MUSIC_GROUNP);
    musScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    musExportToPath->setText(musScanPath);
    appSetting->beginGroup(VIDEO_GROUNP);
    vidScanPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    vidExportToPath->setText(vidScanPath);
    delete appSetting;
}

void UserDetailWidget::setDataAllModel()
{
    picProgressBar->hide();
    vidProgressBar->hide();
    musProgressBar->hide();
    docProgressBar->hide();
    if(!picFileList.isEmpty())
    {
        picFileList.clear();
    }
    if(!musFileList.isEmpty())
    {
        musFileList.clear();
    }
    if(!vidFileList.isEmpty())
    {
        vidFileList.clear();
    }
    if(!docFileList.isEmpty())
    {
        docFileList.clear();
    }
    //搜索图片
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(DESTINATION_GROUNP);
    QString desPath=appSettings->value(DEFAULT).toString();
    QMap<QString, QString> m=Util::findDirs("Pictures",desPath);
    if(!m.isEmpty())
    {
        QList<QString> k=m.keys();
        QStringList format;
        format<<"*.png"<<"*.jpg"<<"*.bmp"<<"*.jpeg"<<"*.gif";
        for(int i=0;i<format.count();i++)
        {
            QList< QString > list= Util::findFileList(format.at(i), m[k.at(0)]);
            QString picFile;
            foreach (picFile, list)
            {
                picFileList.append(picFile);
            }
        }
        m.clear();
    }
    //搜索音乐
    m=Util::findDirs("Musics",desPath);
    if(!m.isEmpty())
    {
        QList<QString> k=m.keys();
        QStringList format;
        format<<"*.mp3"<<"*.wav"<<"*.wma"<<"*.aac"<<"*.ape";
        for(int i=0;i<format.count();i++)
        {
            QList<QString> list=Util::findFileList(format.at(i),m[k.at(0)]);
            QString musicFile;
            foreach (musicFile, list)
            {
                musFileList.append(musicFile);
            }
        }
        m.clear();
    }
    //搜索文档
    m=Util::findDirs("Documents",desPath);
    if(!m.isEmpty())
    {
        QList<QString> k=m.keys();
        QStringList format;
        format<<"*.doc"<<"*.docx"<<"*.pdf"<<"*.ppt"<<"*.pptx"<<"*.xls"<<"*.xlsx"<<"*.txt";
        for(int i=0;i<format.count();i++)
        {
            QList<QString> list =Util::findFileList(format.at(i),m[k.at(0)]);
            QString docFile;
            foreach (docFile, list)
            {
                docFileList.append(docFile);
            }
        }
        m.clear();
    }
    //搜索视频
    m=Util::findDirs("Videos",desPath);
    if(!m.isEmpty())
    {
        QList<QString> k=m.keys();
        QStringList format;
        format<<"*.mp4"<<"*.avi"<<"*.rmvb"<<"*.rm"<<"*.wmv"<<"*.mkv";
        for(int i=0;i<format.count();i++)
        {
            QList<QString> list =Util::findFileList(format.at(i),m[k.at(0)]);
            QString videoFile;
            foreach (videoFile, list)
            {
                vidFileList.append(videoFile);
            }
        }
        m.clear();
    }
    QList<TableModel*> tablelist;
    tablelist<<picModel<<docModel<<vidModel<<musModel;
    QList<QList<QString>> filelist;
    filelist<<picFileList<<docFileList<<vidFileList<<musFileList;
    QList<QCheckBox *> checklist;
    checklist<<picAllchecked<<docAllchecked<<vidAllchecked<<musAllchecked;
    for(int i=0;i<tablelist.count();i++)
    {
        QList<FileRecord> RecordFile;
        QString Record;
        int c=0;
        if (!filelist.at(i).isEmpty())
        {
            foreach (Record, filelist.at(i))
            {
                QFileInfo picRecordInfo(Record);
                FileRecord record;
                int n=0;
                for(int j=0;j<filelist.at(i).count();j++)
                {
                    QModelIndex checkIndex = tablelist.at(i)->index(j, FILE_NAME_COLUMN);
                    QVariant v=tablelist.at(i)->data(checkIndex, Qt::DisplayRole);
                    if(v.isNull())
                    {
                        break;
                    }
                    else if(v.toString()==picRecordInfo.fileName())
                    {
                        checkIndex = tablelist.at(i)->index(j, CHECK_BOX_COLUMN);
                        record.bChecked=tablelist.at(i)->data(checkIndex, Qt::UserRole).toBool();
                        if(record.bChecked)
                        {
                            c++;
                        }
                        n=1;
                        break;
                    }
                }
                if(n==0)
                {
                    record.bChecked=false;
                }
                record.strFileName = picRecordInfo.fileName();
                record.dateTime = picRecordInfo.lastModified();
                double size = (double)picRecordInfo.size()/1024;
                QString sizeDis = QString::number(size, 'f', 2);
                record.nSize = sizeDis;
                record.strFilePath = picRecordInfo.filePath();
                record.copyStart= tr("等待");
                RecordFile.append(record);
            }
            tablelist.at(i)->updateData(RecordFile);
            if(c==0)
            {
                checklist.at(i)->setCheckState(Qt::Unchecked);
            }
            else if(c==filelist.at(i).count())
            {
                checklist.at(i)->setCheckState(Qt::Checked);
            }
            else
            {
                checklist.at(i)->setCheckState(Qt::PartiallyChecked);
            }
        }
        else
        {
            QList<FileRecord> RecordFile;
            tablelist.at(i)->updateData(RecordFile);
            checklist.at(i)->setCheckState(Qt::Unchecked);
        }
    }
}


void UserDetailWidget::updateDataModel()
{
    if((!th_doc->isRunning()&&(!th_pic->isRunning())&&(!th_mus->isRunning())&&(!th_vid->isRunning())))
        setDataAllModel();
}


void UserDetailWidget::getPicChecked(const QModelIndex &index)
{
    if(index.isValid())
    {
         QModelIndex checkIndex = picModel->index(index.row(), CHECK_BOX_COLUMN);
         QModelIndex fileNameIndex = picModel->index(index.row(), FILE_PATH_COLUMN);
         bool bChecked = picModel->data(checkIndex, Qt::UserRole).toBool();
         picCopyFileCount=picCopyFileList.count();
         if (bChecked)
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if(!picCopyFileList.contains(filename))
             {
                picCopyFileList.append(filename);
                picCopyFileCount++;
             }
         }
         else
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if (picCopyFileList.contains(filename))
             {
                 picCopyFileList.removeOne(filename);
                 picCopyFileCount--;
             }
         }
         int totalCount = picFileList.count();
         if(totalCount > 0 && picCopyFileCount < totalCount)
         {
//             picAllchecked->setTristate(true);
             picAllchecked->setCheckState(Qt::PartiallyChecked);
         }
         if(totalCount > 0 && picCopyFileCount == totalCount)
         {
//             picAllchecked->setTristate(true);
             picAllchecked->setCheckState(Qt::Checked);
         }
         if(picCopyFileCount == 0)
         {
//             picAllchecked->setTristate(true);
             picAllchecked->setCheckState(Qt::Unchecked);
         }
    }
}


void UserDetailWidget::getVidChecked(const QModelIndex &index)
{

    if(index.isValid())
    {
         QModelIndex checkIndex = vidModel->index(index.row(), CHECK_BOX_COLUMN);
         QModelIndex fileNameIndex = vidModel->index(index.row(), FILE_PATH_COLUMN);
         bool bChecked = vidModel->data(checkIndex, Qt::UserRole).toBool();
         vidCopyFileCount=vidCopyFileList.count();
         if (bChecked)
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if(!vidCopyFileList.contains(filename))
             {
                vidCopyFileList.append(filename);
                vidCopyFileCount++;
             }
         }
         else
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if (vidCopyFileList.contains(filename))
             {
                 vidCopyFileList.removeOne(filename);
                 vidCopyFileCount--;
             }
         }
         int totalCount = vidFileList.count();
         if(totalCount > 0 && vidCopyFileCount < totalCount)
         {
//             vidAllchecked->setTristate(true);
             vidAllchecked->setCheckState(Qt::PartiallyChecked);
         }
         if(totalCount > 0 && vidCopyFileCount == totalCount)
         {
//             vidAllchecked->setTristate(true);
             vidAllchecked->setCheckState(Qt::Checked);
         }
         if(vidCopyFileCount == 0)
         {
//             vidAllchecked->setTristate(true);
             vidAllchecked->setCheckState(Qt::Unchecked);
         }
    }
}


void UserDetailWidget::getMusicChecked(const QModelIndex &index)
{
    if(index.isValid())
    {
         QModelIndex checkIndex = musModel->index(index.row(), CHECK_BOX_COLUMN);
         QModelIndex fileNameIndex = musModel->index(index.row(), FILE_PATH_COLUMN);
         bool bChecked = musModel->data(checkIndex, Qt::UserRole).toBool();
         musCopyFileCount=musCopyFileList.count();
         if (bChecked)
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if(!musCopyFileList.contains(filename))
             {
                musCopyFileList.append(filename);
                musCopyFileCount++;
             }
         }
         else
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if (musCopyFileList.contains(filename))
             {
                 musCopyFileList.removeOne(filename);
                 musCopyFileCount--;
             }
         }
         int totalCount = musFileList.count();
         if(totalCount > 0 && musCopyFileCount < totalCount)
         {
//             musAllchecked->setTristate(true);
             musAllchecked->setCheckState(Qt::PartiallyChecked);
         }
         if(totalCount > 0 && musCopyFileCount == totalCount)
         {
//             musAllchecked->setTristate(true);
             musAllchecked->setCheckState(Qt::Checked);
         }
         if(musCopyFileCount == 0)
         {
//             musAllchecked->setTristate(true);
             musAllchecked->setCheckState(Qt::Unchecked);
         }
    }
}


void UserDetailWidget::getDocChecked(const QModelIndex &index)
{
    if(index.isValid())
    {
         QModelIndex checkIndex = docModel->index(index.row(), CHECK_BOX_COLUMN);
         QModelIndex fileNameIndex = docModel->index(index.row(), FILE_PATH_COLUMN);
         bool bChecked = docModel->data(checkIndex, Qt::UserRole).toBool();
         musCopyFileCount=musCopyFileList.count();
         if (bChecked)
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if(!docCopyFileList.contains(filename))
             {
                docCopyFileList.append(filename);
                docCopyFileCount++;
             }
         }
         else
         {
             QString filename = fileNameIndex.data(Qt::DisplayRole).toString();
             if (docCopyFileList.contains(filename))
             {
                 docCopyFileList.removeOne(filename);
                 docCopyFileCount--;
             }
         }
         int totalCount = docFileList.count();
         if(totalCount > 0 && docCopyFileCount < totalCount)
         {
//             docAllchecked->setTristate(true);
             docAllchecked->setCheckState(Qt::PartiallyChecked);
         }
         if(totalCount > 0 && docCopyFileCount == totalCount)
         {
//             docAllchecked->setTristate(true);
             docAllchecked->setCheckState(Qt::Checked);
         }
         if(docCopyFileCount == 0)
         {
//             docAllchecked->setTristate(true);
             docAllchecked->setCheckState(Qt::Unchecked);
         }
    }
}



void UserDetailWidget::getPicCheckedSlot(const QModelIndex &index)
{
    this->getPicChecked(index);
}


void UserDetailWidget::getVidCheckedSlot(const QModelIndex &index)
{
    this->getVidChecked(index);
}

void UserDetailWidget::getMusicCheckedSlot(const QModelIndex &index)
{
    this->getMusicChecked(index);
}

void UserDetailWidget::getDocCheckedSlot(const QModelIndex &index)
{
    this->getDocChecked(index);
}

/*
    QList < QString > picFileList;
    QList < QString > musFileList;
    QList < QString > vidFileList;
    QList < QString > docFileList;

*/


void UserDetailWidget::picCheckedBoxAll(int state)
{
    if (state == Qt::Checked)
    {
        int row = picModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = picModel->index(i, CHECK_BOX_COLUMN);
                picModel->setData(checkIndex, true, Qt::UserRole);
            }
        }
        /*文件拷贝列表原样复制  picCopyFileList  picFileList*/
        QString picFile;
        picCopyFileList.clear();
        foreach(picFile, picFileList)
        {
            picCopyFileList.append(picFile);
        }
    }
    else if(state == Qt::Unchecked)
    {
        int row = picModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = picModel->index(i, CHECK_BOX_COLUMN);
                picModel->setData(checkIndex, false, Qt::UserRole);
            }
        }
        /*文件拷贝列表清空，开始导出之前进行判断，如果为空则进行提示未选中文件*/
        picCopyFileList.clear();
    }
}


void UserDetailWidget::vidCheckedBoxAll(int state)
{
    if (state == Qt::Checked)
    {
        int row = vidModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = vidModel->index(i, CHECK_BOX_COLUMN);
                vidModel->setData(checkIndex, true, Qt::UserRole);
            }
        }
        /*文件拷贝列表原样复制*/
        QString vidFile;
        vidCopyFileList.clear();
        foreach(vidFile, vidFileList)
        {
            vidCopyFileList.append(vidFile);
        }
    }
    if(state == Qt::Unchecked)
    {
        int row = vidModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = vidModel->index(i, CHECK_BOX_COLUMN);
                vidModel->setData(checkIndex, false, Qt::UserRole);
            }
        }
        /*文件拷贝列表清空，开始导出之前进行判断，如果为空则进行提示未选中文件*/
        vidCopyFileList.clear();
    }

}


void UserDetailWidget::musCheckedBoxAll(int state)
{
    if (state == Qt::Checked)
    {
        int row = musModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = musModel->index(i, CHECK_BOX_COLUMN);
                musModel->setData(checkIndex, true, Qt::UserRole);
            }
        }
        /*文件拷贝列表原样复制*/
        QString musFile;
        musCopyFileList.clear();
        foreach(musFile, musFileList)
        {
            musCopyFileList.append(musFile);
        }
    }
    if(state == Qt::Unchecked)
    {
        int row = musModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = musModel->index(i, CHECK_BOX_COLUMN);
                musModel->setData(checkIndex, false, Qt::UserRole);
            }
        }
        /*文件拷贝列表清空，开始导出之前进行判断，如果为空则进行提示未选中文件*/
        musCopyFileList.clear();
    }
}


void UserDetailWidget::docCheckedBoxAll(int state)
{
    if (state == Qt::Checked)
    {
        int row = docModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = docModel->index(i, CHECK_BOX_COLUMN);
                docModel->setData(checkIndex, true, Qt::UserRole);
            }
        }
        /*文件拷贝列表原样复制*/
        QString docFile;
        docCopyFileList.clear();
        foreach(docFile, docFileList)
        {
            docCopyFileList.append(docFile);
        }
    }
    if(state == Qt::Unchecked)
    {
        int row = docModel->rowNumber();
        if (row > 0)
        {
            for (int i = 0; i < row; i++)
            {
                QModelIndex checkIndex = docModel->index(i, CHECK_BOX_COLUMN);
                docModel->setData(checkIndex, false, Qt::UserRole);
            }
        }
        /*文件拷贝列表清空，开始导出之前进行判断，如果为空则进行提示未选中文件*/
        docCopyFileList.clear();
    }
}

void UserDetailWidget::picAllcheckedSlot()
{
    if(picAllchecked->checkState()==Qt::PartiallyChecked)
    {
        picAllchecked->setCheckState(Qt::Checked);
        picCheckedBoxAll(Qt::Checked);
    }
}

void UserDetailWidget::musAllcheckedSlot()
{
    if(musAllchecked->checkState()==Qt::PartiallyChecked)
    {
        musAllchecked->setCheckState(Qt::Checked);
        musCheckedBoxAll(Qt::Checked);
    }
}

void UserDetailWidget::vidAllcheckedSlot()
{
    if(vidAllchecked->checkState()==Qt::PartiallyChecked)
    {
        vidAllchecked->setCheckState(Qt::Checked);
        vidCheckedBoxAll(Qt::Checked);
    }
}

void UserDetailWidget::docAllcheckedSlot()
{
    if(docAllchecked->checkState()==Qt::PartiallyChecked)
    {
        docAllchecked->setCheckState(Qt::Checked);
        docCheckedBoxAll(Qt::Checked);
    }
}

void UserDetailWidget::exportPicSlot()
{
    if(picCopyFileList.isEmpty())
    {
        msg_pic->setInfo(tr("数据迁移"), tr("尚未选择任何图像文件，请勾选要迁移的文件"), QPixmap(":/Message/error"), true, true);
        msg_pic->exec();
        return ;
    }
    if(picScanPath.isEmpty())
    {
        msg_pic->setInfo(tr("数据迁移"),tr("尚未设置导入目录，请设置导入目录"),QPixmap(":/Message/error"),true,true);
        msg_pic->exec();
        return ;
    }
    if(th_pic->isRunning())
    {
        msg_pic->setInfo(tr("数据迁移"),tr("正在进行图片导入"),QPixmap(":/Message/warning"),true,true);
        msg_pic->exec();
    }
    else
    {
        userdata_pic->CopyList=picCopyFileList;
        userdata_pic->CopytoDst.clear();
        userdata_pic->current_index=USERDATA_PIC;
        for(int i=0;i<picCopyFileList.count();i++)
        {
            userdata_pic->CopytoDst.insert(picCopyFileList.at(i),picScanPath);
        }
        th_pic->start();
    }
}

void UserDetailWidget::exportVidSlot()
{
    if(vidCopyFileList.isEmpty())
    {
        msg_vid->setInfo(tr("数据迁移"), tr("尚未选择任何视频文件，请勾选要迁移的文件"), QPixmap(":/Message/error"), true, true);
        msg_vid->exec();
        return ;
    }
    if(vidScanPath.isEmpty())
    {
        msg_vid->setInfo(tr("数据迁移"),tr("尚未设置导入目录，请设置导入目录"),QPixmap(":/Message/error"),true,true);
        msg_vid->exec();
        return ;
    }
    if(th_vid->isRunning())
    {
        msg_vid->setInfo(tr("数据迁移"),tr("正在进行视频导入"),QPixmap(":/Message/warning"),true,true);
        msg_vid->exec();

    }
    else
    {
        userdata_vid->CopyList=vidCopyFileList;
        userdata_vid->CopytoDst.clear();
        userdata_vid->current_index=USERDATA_VID;
        for(int i=0;i<vidCopyFileList.count();i++)
        {
            userdata_vid->CopytoDst.insert(vidCopyFileList.at(i),vidScanPath);
        }
        th_vid->start();
    }
}

void UserDetailWidget::exportMusSlot()
{
    if(musCopyFileList.isEmpty())
    {
        msg_mus->setInfo(tr("数据迁移"), tr("尚未选择任何音频文件，请勾选要迁移的文件"), QPixmap(":/Message/error"), true, true);
        msg_mus->exec();
        return ;
    }
    if(musScanPath.isEmpty())
    {
        msg_mus->setInfo(tr("数据迁移"),tr("尚未设置导入目录，请设置导入目录"),QPixmap(":/Message/error"),true,true);
        msg_mus->exec();
        return ;
    }
    if(th_mus->isRunning())
    {
        msg_mus->setInfo(tr("数据迁移"),tr("正在进行音频导入"),QPixmap(":/Message/warning"),true,true);
        msg_mus->exec();
    }
    else
    {
        userdata_mus->CopyList=musCopyFileList;
        userdata_mus->CopytoDst.clear();
        userdata_mus->current_index=USERDATA_MUS;
        for(int i=0;i<musCopyFileList.count();i++)
        {
            userdata_mus->CopytoDst.insert(musCopyFileList.at(i),musScanPath);
        }
        th_mus->start();
    }

}

void UserDetailWidget::exportDocSlot()
{
    if(docCopyFileList.isEmpty())
    {
        msg_doc->setInfo(tr("数据迁移"), tr("尚未选择任何文档，请勾选要迁移的文件"), QPixmap(":/Message/error"), true, true);
        msg_doc->exec();
        return ;
    }
    if(docScanPath.isEmpty())
    {
        msg_doc->setInfo(tr("数据迁移"),tr("尚未设置导入目录，请设置导入目录"),QPixmap(":/Message/error"),true,true);
        msg_doc->exec();
        return ;
    }
    if(th_doc->isRunning())
    {
        msg_doc->setInfo(tr("数据迁移"),tr("正在进行文档导入"),QPixmap(":/Message/warning"),true,true);
        msg_doc->exec();
    }
    else
    {
        userdata_doc->CopyList=docCopyFileList;
        userdata_doc->CopytoDst.clear();
        userdata_doc->current_index=USERDATA_DOC;
        for(int i=0;i<docCopyFileList.count();i++)
        {
            userdata_doc->CopytoDst.insert(docCopyFileList.at(i),docScanPath);
        }
        th_doc->start();
    }
}

void UserDetailWidget::UserDataCopy_Error_nameSlot(int c,QStringList name)
{
    QList<CustomMessageBox *> l;
    l<<msg_pic<<msg_mus<<msg_doc<<msg_vid;
    int i=0;
    QString n;
    switch(c)
    {
    case USERDATA_PIC:
        th_pic->exit();
        n=tr("图片");
        i=0;
        Util::checkDirown(Util::getSysPictureDir());
        break;
    case USERDATA_MUS:
        th_mus->exit();
        n=tr("音频");
        i=1;
        Util::checkDirown(Util::getSysMusicDir());
        break;
    case USERDATA_DOC:
        th_doc->exit();
        n=tr("文档");
        i=2;
        Util::checkDirown(Util::getUserDocDir());
        break;
    case USERDATA_VID:
        th_vid->exit();
        n=tr("视频");
        i=3;
        Util::checkDirown(Util::getSysVideoDir());
        break;
    }
    if(name.isEmpty())
    {
        l.at(i)->setInfo(tr("数据迁移"),n+tr("数据导入成功"), QPixmap(":/Message/yes"), true, true);
        l.at(i)->exec();
    }
    else
    {
        l.at(i)->setInfo(tr("数据迁移"),n+tr("数据导入失败"),QPixmap(":/Message/error"),true,true);
        l.at(i)->exec();
    }

}

void UserDetailWidget::UserData_progress_numSlot(int c,int over)
{
    double co;
    double o=over;
    if(o<=0)
    {
        picProgressBar->hide();
        musProgressBar->hide();
        vidProgressBar->hide();
        docProgressBar->hide();
    }
    else
    {
        switch(c)
        {
        case USERDATA_PIC://图片
            picProgressBar->show();
            co=userdata_pic->CopyList.count();
            picProgressBar->setValue(o/co*100.0);
            break;
        case USERDATA_VID://视频
            vidProgressBar->show();
            co=userdata_vid->CopyList.count();
            vidProgressBar->setValue(o/co*100.0);
            break;
        case USERDATA_MUS://音乐
            musProgressBar->show();
            co=userdata_mus->CopyList.count();
            musProgressBar->setValue(o/co*100.0);
            break;
        case USERDATA_DOC://文档
            docProgressBar->show();
            co=userdata_doc->CopyList.count();
            docProgressBar->setValue(o/co*100.0);
            break;
        }
    }
}

void UserDetailWidget::UserData_Copyover_nameSlot(int c, QString name,int f)
{
    if(f==0)
    {
        updataUserData_table(c,name,tr("导入完成"));
    }
    else
    {
        updataUserData_table(c,name,tr("导入失败"));
    }
}

void UserDetailWidget::UserData_currentCopy_nameSlot(int c, QString name)
{
    updataUserData_table(c,name,tr("正在导入"));
}

void UserDetailWidget::updataUserData_table(int c,QString name,QString start)
{
    QList<TableModel*> tablelist;
    tablelist<<picModel<<docModel<<vidModel<<musModel;
    QList<QList<QString>> filelist;
    filelist<<picFileList<<docFileList<<vidFileList<<musFileList;
    QList<QCheckBox *> checklist;
    checklist<<picAllchecked<<docAllchecked<<vidAllchecked<<musAllchecked;
    int i=0;
    switch(c)
    {
    case USERDATA_PIC://图片
        i=0;
        break;
    case USERDATA_VID://视频
        i=2;
        break;
    case USERDATA_MUS://音乐
        i=3;
        break;
    case USERDATA_DOC://文档
        i=1;
        break;
    }
    QList<FileRecord> RecordFile;
    QString Record;
    int c=0;
    if (!filelist.at(i).isEmpty())
    {
        foreach (Record, filelist.at(i))
        {
            QFileInfo picRecordInfo(Record);
            FileRecord record;
            int n=0;
            for(int j=0;j<filelist.at(i).count();j++)
            {
                QModelIndex checkIndex = tablelist.at(i)->index(j, FILE_NAME_COLUMN);
                QVariant v=tablelist.at(i)->data(checkIndex, Qt::DisplayRole);
                if(v.isNull())
                {
                    break;
                }
                else if(v.toString()==picRecordInfo.fileName())
                {
                    if(v.toString()==name)
                    {
                        record.copyStart=start;
                    }
                    else
                    {
                        checkIndex=tablelist.at(i)->index(j,FILE_COPY_COLUMN);
                        record.copyStart=tablelist.at(i)->data(checkIndex,Qt::DisplayRole).toString();
                    }
                    checkIndex = tablelist.at(i)->index(j, CHECK_BOX_COLUMN);
                    record.bChecked=tablelist.at(i)->data(checkIndex, Qt::UserRole).toBool();
                    if(record.bChecked)
                    {
                        c++;
                    }
                    n=1;
                    break;
                }
            }
            if(n==0)
            {
                record.bChecked=false;
            }
            record.strFileName = picRecordInfo.fileName();
            record.dateTime = picRecordInfo.lastModified();
            double size = (double)picRecordInfo.size()/1024;
            QString sizeDis = QString::number(size, 'f', 2);
            record.nSize = sizeDis;
            record.strFilePath = picRecordInfo.filePath();
            RecordFile.append(record);
        }
        tablelist.at(i)->updateData(RecordFile);
        if(c==0)
        {
            checklist.at(i)->setCheckState(Qt::Unchecked);
        }
        else if(c==filelist.at(i).count())
        {
            checklist.at(i)->setCheckState(Qt::Checked);
        }
        else
        {
            checklist.at(i)->setCheckState(Qt::PartiallyChecked);
        }
    }
}

void UserDetailWidget::userData_onekey()
{
    updateDataModel();
    picCheckedBoxAll(Qt::Checked);
    vidCheckedBoxAll(Qt::Checked);
    musCheckedBoxAll(Qt::Checked);
    docCheckedBoxAll(Qt::Checked);
    UserData_count=0;
    UserData_over=0;
    if(!th_one->isRunning())
    {
        userdata_one->CopyList=picCopyFileList+vidCopyFileList+musCopyFileList+docCopyFileList;
        UserData_count=userdata_one->CopyList.count();
        QList<QString> ls;
        ls<<picScanPath<<vidScanPath<<musScanPath<<docScanPath;
        QList<QStringList> lsl;
        lsl<<picCopyFileList<<vidCopyFileList<<musCopyFileList<<docCopyFileList;
        for(int i=0;i<ls.count();i++)
        {
            for(int j=0;j<lsl.at(i).count();j++)
            {
                userdata_one->CopytoDst.insert(lsl.at(i).at(j),ls.at(i));
            }
        }
    }
}

void UserDetailWidget::userData_onekey_start()
{
    if(!th_one->isRunning())
        th_one->start();
}

void UserDetailWidget::UserData_progress_onekey_numSlot(int c, int over)
{
    UserData_over++;
    emit UserData_progress_onekey_num(UserData_count,UserData_over);
    if(UserData_over==UserData_count)
    {
        th_one->exit();
    }
}

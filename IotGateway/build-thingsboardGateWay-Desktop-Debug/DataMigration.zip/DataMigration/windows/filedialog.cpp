#include "filedialog.h"

QString FileDialog::getOpenFileName(QWidget *parent, const QString &caption, const QString &dir, const QString &filter, QString *selectedFilter, Options options)
{
    QFileDialog *fd=new QFileDialog(parent,caption,dir,filter);
    fd->setOptions(options);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(!v.contains("EN"))
    {
        foreach(QObject *obj,fd->children())
        {

            if (obj->objectName() == "buttonBox")
            {
                QDialogButtonBox *l= qobject_cast<QDialogButtonBox *>(obj);
                QPushButton *aaa=l->button(QDialogButtonBox::Cancel);
                aaa->setText(tr("取消(&C)"));
                aaa=l->button(QDialogButtonBox::Open);
                aaa->setText(tr("打开(&O)"));
            }
            if(obj->objectName()=="lookInLabel")
            {
                QLabel *l=qobject_cast<QLabel*>(obj);
                l->setText(tr("查看："));
            }
            if(obj->objectName()=="fileNameLabel")
            {
                QLabel *l=qobject_cast<QLabel*>(obj);
                l->setText(tr("文件名称："));
            }
            if(obj->objectName()=="fileTypeLabel")
            {
                QLabel *l=qobject_cast<QLabel*>(obj);
                l->setText(tr("文件类型："));
            }
        }
    }
    if(fd->exec())
        return fd->selectedFiles().at(0);
    else
        return "";
}

QString FileDialog::getExistingDirectory(QWidget *parent, const QString &caption, const QString &dir, Options options)
{
    QFileDialog *fd=new QFileDialog(parent,caption,dir);
    fd->setFileMode(QFileDialog::Directory);
    fd->setOptions(options);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(!v.contains("EN"))
    {
        foreach(QObject *obj,fd->children())
        {
            if (obj->objectName() == "buttonBox")
            {
                QDialogButtonBox *l= qobject_cast<QDialogButtonBox *>(obj);
                QPushButton *aaa=l->button(QDialogButtonBox::Cancel);
                aaa->setText(tr("取消(&C)"));
                aaa=l->button(QDialogButtonBox::Open);
                aaa->setText(tr("打开(&O)"));
            }
            if(obj->objectName()=="lookInLabel")
            {
                QLabel *l=qobject_cast<QLabel*>(obj);
                l->setText(tr("查看："));
            }
            if(obj->objectName()=="fileNameLabel")
            {
                QLabel *l=qobject_cast<QLabel*>(obj);
                l->setText(tr("目录："));
            }
            if(obj->objectName()=="fileTypeLabel")
            {
                QLabel *l=qobject_cast<QLabel*>(obj);
                l->setText(tr("文件类型："));
            }
        }
    }
    if(fd->exec())
        return fd->selectedFiles().at(0);
    else
        return "";
}

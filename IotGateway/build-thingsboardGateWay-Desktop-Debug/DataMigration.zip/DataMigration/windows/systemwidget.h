#ifndef SYSTEMWIDGET_H
#define SYSTEMWIDGET_H
#include <QWidget>
#include <QLabel>
#include "windows/messagebox.h"
#include <QSettings>
#include <QCoreApplication>
#include "functions/common.h"
#include <QDebug>
#include <QFile>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <arpa/inet.h>
#include <net/if.h>
class QPushButton;

class SystemWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SystemWidget(QWidget *parent = 0);
    ~SystemWidget();
    void _init(void);
    void system_onekey(void);
public:
    QPushButton *sysExportBtn;
public slots:
    void exportSys(void);
signals:
    void exportSys_onekey_progressBar_num(int count,int over);

protected:
    void paintEvent(QPaintEvent *);

    int staticexport(void);

private:
    QLabel *networkTypeLabel;
    QLabel *ipContentLabel;
    QLabel *maskContentLabel;
    QLabel *gatewayContentLabel;
    QLabel *dnsContentLabel;
    CustomMessageBox *msg;

};

#endif // SYSTEMWIDGET_H


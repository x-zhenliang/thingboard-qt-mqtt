#ifndef DATAMIGRATION_H
#define DATAMIGRATION_H

#include "windows/titlewidget.h"
#include "windows/mainmenu.h"
#include "windows/systemtray.h"
#include "windows/computerwidget.h"
#include "windows/aboutus.h"
#include "windows/settingdialog.h"
#include "windows/userwidget.h"
#include "windows/appwidget.h"
#include "windows/systemwidget.h"
#include "windows/userdetailwidget.h"
#include "windows/appdetailwidget.h"
#include "windows/messagebox.h"
#include "windows/networkwidget.h"
#include <QWidget>
#include <QtScript/QScriptEngine>
#include <QtScript/QScriptValue>
#include <QtScript/QScriptValueList>
#include "tools/utils.h"
class QVBoxLayout;
class QStackedWidget;

using namespace std;

class DataMigration : public QWidget
{
    Q_OBJECT

public:
    DataMigration(QWidget *parent = 0);
    ~DataMigration();
    void setTranslator(QTranslator* translator);
public slots:
    void showWidget();

private slots:
    void showMainMenu();
    void showSettingDialog();
    void showAboutUs();
    void showLogin();
    void iconIsActived(QSystemTrayIcon::ActivationReason reason);
    void switchComputerWin();
    void switchUserWin();
    void switchAppWin();
    void switchSysWin();
    void switchUserPic();
    void switchUserMusic();
    void switchUserVideo();
    void switchUserDoc();
    void switchAppEmail();
    void switchAppBrowser();
    void exportEmailData();
    void exportBrowerData();
    void switchLanguage(int language);

    void onekeyexportSlot();
    void onekey_progressBar_num(int count,int over);

protected:
    void paintEvent(QPaintEvent *);

private:
    TitleWidget *titleWidget;
    QVBoxLayout *mainVlayout;
    MainMenu    *mainMenu;
    SystemTray  *systemTray;
    QStackedWidget *stackWidget;
    ComputerWidget *compuWidget;
    AboutUsDialog  *aboutUs;
    SettingDlg     *settingDlg;
    UserWidget     *userWidget;
    AppWidget      *appWidget;
    SystemWidget   *sysWidget;
    UserDetailWidget *userDetailWidget;
    AppDetailWidget  *appDetailWidget;
    CustomMessageBox *infoMsg;
    NetworkWidget *networkWidget;

    double datamigration_count;
    double datamigration_over;
    int current_language;
    QTranslator* languagetranslator;
    QApplication* languageapp;
};

#endif // DATAMIGRATION_H

#include "windows/appdetailwidget.h"
#include "windows/comboboxdelegate.h"
#include "windows/customdelegate.h"
#include "windows/messagebox.h"
#include "tools/utils.h"
#include <QLabel>
#include <QMouseEvent>
#include <QPixmap>
#include <QPushButton>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPainter>
#include <QPen>
#include <QPoint>
#include <QListWidget>
#include <QStackedWidget>
#include <QListWidgetItem>
#include <QLineEdit>
#include <QCheckBox>
#include <QComboBox>
#include <QTreeView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QDebug>
#include <QFileDialog>
#include <QProgressBar>
#include <QProcess>
#include "functions/common.h"


AppDetailWidget::AppDetailWidget(QWidget *parent)
    :QDialog(parent)
{
    setWindowFlags(Qt::FramelessWindowHint);
    dstFilePath =Util::DestinationPath();
    emailTreeView = new QTreeView();
    emailTreeView->setContentsMargins(0, 0, 0, 0);
    emailTreeView->setStyleSheet("QTreeView{border:0px;}"
                                 "QTreeView::item{font-size:30px; font-family:黑体; height:26px;}"
                                 "QTreeView::item:hover{color:black; background:transparent; font-size:30px; font-family:黑体; height:26px;}"
                                 "QTreeView::item:selected{color:black; background:transparent; font-size:30px; font-family:黑体; height:26px;}");
    emailTreeView->setEditTriggers(QAbstractItemView::NoEditTriggers);
    emailModel = new QStandardItemModel(emailTreeView);
    emailTreeView->setModel(emailModel);
    customDelegate = new CustomDelegate();
    emailTreeView->setMouseTracking(true);
    emailTreeView->setItemDelegate(customDelegate);
    outlookItem = new QStandardItem(QIcon(":/appwin/outlook"),QStringLiteral("Microsoft Outlook"));
    foxmailItem = new QStandardItem(QIcon(":/appwin/foxmail"),QStringLiteral("Foxmail 7"));
    outlookItem->setCheckable(true);
    outlookItem->setTristate(true);
    foxmailItem->setCheckable(true);
    foxmailItem->setTristate(true);
    ComboBoxDelegate  *ieComboxDelegate = new ComboBoxDelegate(this);
    ComboBoxDelegate  *firefoxComboxDelegate = new ComboBoxDelegate(this);
    ComboBoxDelegate  *chromeComboxDelegate = new ComboBoxDelegate(this);
//    ComboBoxDelegate  *CDOSBrowserComboxDelegate = new ComboBoxDelegate(this);
    ieBtn = new QPushButton();
    firfoxBtn = new QPushButton();
    chromeBtn = new QPushButton();
//    CDOSBrowserBtn = new QPushButton();
    IEcombox = new QComboBox();
    firfoxCombox = new QComboBox();
    chromeCombox = new QComboBox();
//    CDOSBrowserCombox = new QComboBox();
    IEcombox->setItemDelegate(ieComboxDelegate);
    firfoxCombox->setItemDelegate(firefoxComboxDelegate);
    chromeCombox->setItemDelegate(chromeComboxDelegate);
//    CDOSBrowserCombox->setItemDelegate(CDOSBrowserComboxDelegate);
    connect(ieComboxDelegate, SIGNAL(deleteItem(QModelIndex)),this, SLOT(iecomboboxdelete(QModelIndex)));
    connect(firefoxComboxDelegate, SIGNAL(deleteItem(QModelIndex)),this, SLOT(firefoxcomboboxdelete(QModelIndex)));
    connect(chromeComboxDelegate, SIGNAL(deleteItem(QModelIndex)),this, SLOT(chromecomboboxdelete(QModelIndex)));
//    connect(CDOSBrowserComboxDelegate, SIGNAL(deleteItem(QModelIndex)),this,SLOT(CDOSBrowsercomboboxdelete(QModelIndex)));

    initAppEmailWidget();
    initAppBrowerWidget();
    updateBrowserData();
    checkClient();
    appLeftListWidget = new QListWidget();
    appRightStackWidget = new QStackedWidget();
    QListWidgetItem *emailDetalItem = new QListWidgetItem(tr("邮件"));
    QListWidgetItem *browserDetailItem = new QListWidgetItem(tr("收藏夹"));
    emailDetalItem->setTextAlignment(Qt::AlignCenter);
    browserDetailItem->setTextAlignment(Qt::AlignCenter);
    appLeftListWidget->setFixedWidth(97);
    appLeftListWidget->insertItem(0, emailDetalItem);
    appLeftListWidget->insertItem(1, browserDetailItem);
    appLeftListWidget->setStyleSheet("QListWidget{border:0px;background-color:rgb(244, 244, 244)}"
                                     "QListWidget::item{color:rgb(101, 101, 101); height: 40px;}"
                                     "QListWidget::item:hover{color:white; background-color:rgb(51, 198, 235);}"
                                     "QListWidget::item:selected{border:0px; color:white; background-color:rgb(51, 168, 235);}");
    appLeftListWidget->setFocusPolicy(Qt::NoFocus);
    appLeftListWidget->setCurrentRow(0);
    appRightStackWidget->insertWidget(0, emailDetalWidget);
    appRightStackWidget->insertWidget(1, browserDetailWidget);
    QHBoxLayout *centerHlayout = new QHBoxLayout();
    centerHlayout->addWidget(appLeftListWidget, 0, Qt::AlignLeft);
    centerHlayout->addWidget(appRightStackWidget);
    centerHlayout->setSpacing(0);
    centerHlayout->setContentsMargins(0, 0, 0, 1);
    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(centerHlayout);
    mainLayout->setContentsMargins(0, 0, 0, 0);
    setLayout(mainLayout);
    emailMigration = new EmailDataMigration();
    connect(emailMigration,SIGNAL(EmailDataMigtation_progressBar_num(int,int)),this,SLOT(EmailDataMigtation_progressBar_numSlot(int,int)));
    connect(emailMigration,SIGNAL(EmailDataMigtation_error_num(QList<int>,QList<QString>)),this,SLOT(EmailDataMigtation_Error_NumSlot(QList<int>,QList<QString>)));
    connect(emailMigration,SIGNAL(CDOSMail_AddUserName_Error()),this,SLOT(CDOSMail_AddUserName_Error_Slot()));
    connect(emailMigration,SIGNAL(CDOSMail_AddUserName_Ok()),this,SLOT(CDOSMail_AddUserName_Ok_Slot()));
    connect(emailMigration,SIGNAL(CDOSMail_SelectUserName()),this,SLOT(CDOSMail_SelectUserName_Slot()));
    connect(emailMigration,SIGNAL(EmailDataMigration_success()),this,SLOT(EmailDataMigration_success_Slot()));
    emailMigration_one = new EmailDataMigration();
    connect(emailMigration_one,SIGNAL(EmailDataMigtation_progressBar_num(int,int)),this,SLOT(appData_onekey_progressBar_numSlot(int,int)));

    msg = new CustomMessageBox();
    usemsg =new EmailUserNameSelect();
    connect(usemsg,SIGNAL(SelectUserName(QString)),this->emailMigration, SLOT(EmailMsg_SelectUserName_Slot(QString)));
    connect(usemsg,SIGNAL(AddUserName(QStringList,QStringList)),this->emailMigration,SLOT(EmailMsg_AddUserName_Slot(QStringList,QStringList)));
    usemsg_one = new EmailUserNameSelect();
    connect(usemsg_one,SIGNAL(SelectUserName(QString)),this->emailMigration_one, SLOT(EmailMsg_SelectUserName_Slot(QString)));
    connect(usemsg_one,SIGNAL(AddUserName(QStringList,QStringList)),this->emailMigration_one,SLOT(EmailMsg_AddUserName_Slot(QStringList,QStringList)));
    connect(appLeftListWidget, SIGNAL(currentRowChanged(int)), appRightStackWidget,SLOT(setCurrentIndex(int)));
    connect(appLeftListWidget, SIGNAL(currentRowChanged(int)), this,SLOT(updateEmailDataSlot()));
    connect(appLeftListWidget,SIGNAL(currentRowChanged(int)),this,SLOT(updateBrowserSlot()));
    connect(customDelegate,SIGNAL(open(QModelIndex)),this,SLOT(emailBtnSlot(QModelIndex)));
    connect(emailModel, SIGNAL(itemChanged(QStandardItem*)),this,SLOT(treeItemChanged(QStandardItem*)));
    connect(emailModel, SIGNAL(itemChanged(QStandardItem*)),this,SLOT(getemailItemData(QStandardItem*)));
    connect(ieBtn, SIGNAL(clicked()),this,SLOT(IEBrowserAdd()));
    connect(firfoxBtn, SIGNAL(clicked()),this,SLOT(FirefoxBrowserAdd()));
    connect(chromeBtn, SIGNAL(clicked()),this,SLOT(ChromeBrowserAdd()));
//    connect(CDOSBrowserBtn, SIGNAL(clicked()),this,SLOT(CDOSBrowserAdd()));


    favorites = new BrowserFavorites();
    connect(favorites,SIGNAL(BrowserFavorites_error_num(QList<int>,QList<QString>)),this,SLOT(Favorites_error_numSlot(QList<int>,QList<QString>)));
    connect(favorites,SIGNAL(BrowserFavorites_progress_num(int,int)),this,SLOT(Favorites_progress_numSlot(int,int)));
    connect(favorites,SIGNAL(BrowserFavorites_success()),this,SLOT(Favorites_successSlot()));
    favorites_one = new BrowserFavorites();
    connect(favorites_one,SIGNAL(BrowserFavorites_progress_num(int,int)),this,SLOT(appData_onekey_progressBar_numSlot(int,int)));
}

AppDetailWidget::~AppDetailWidget()
{
}


void AppDetailWidget::iecomboboxdelete(const QModelIndex &index)
{
    IEcombox->removeItem(index.row());
}

void AppDetailWidget::firefoxcomboboxdelete(const QModelIndex &index)
{
    firfoxCombox->removeItem(index.row());
}

void AppDetailWidget::chromecomboboxdelete(const QModelIndex &index)
{
    chromeCombox->removeItem(index.row());
}

//void AppDetailWidget::CDOSBrowsercomboboxdelete(const QModelIndex &index)
//{
//    CDOSBrowserCombox->removeItem(index.row());
//}

void AppDetailWidget::paintEvent(QPaintEvent *)
{
    QPainter painterWidget(this);
    QLinearGradient linearWidget(rect().topLeft(), rect().bottomLeft());
    linearWidget.setColorAt(0, Qt::white);
    linearWidget.setColorAt(0.5, Qt::white);
    linearWidget.setColorAt(1, Qt::white);
    painterWidget.setPen(Qt::white);
    painterWidget.setBrush(linearWidget);
    painterWidget.drawRect(QRect(0, 30, this->width(), this->height()-30));

    QPainter painterLeft(this);
    QLinearGradient linearLeft(rect().topLeft(), rect().bottomLeft());
    linearLeft.setColorAt(0, QColor(244,244,244));
    linearLeft.setColorAt(0.5, QColor(244,244,244));
    linearLeft.setColorAt(1, QColor(244,244,244));
    painterLeft.setPen(QColor(244,244,244));
    painterLeft.setBrush(linearLeft);
    painterLeft.drawRect(QRect(0, 0, 97, this->height()-5));

    QPainter painterFrame(this);
    painterFrame.setPen(Qt::gray);
    static const QPointF points[4] = {QPointF(0, 0), QPointF(0, this->height()-1), QPointF(this->width()-1, this->height()-1), QPointF(this->width()-1, 0)};
    painterFrame.drawPolyline(points, 4);
}


void AppDetailWidget::translateLanguage()
{
}


void AppDetailWidget::initAppEmailWidget()
{
    emailDetalWidget = new QWidget();
    QStandardItem *emailItem = new QStandardItem(tr("邮件客户端数据"));
    //emailItem
    emailModel->setHorizontalHeaderLabels(QStringList() << tr(""));
    emailModel->appendRow(emailItem);
    emailItem->appendRow(outlookItem);
    emailItem->appendRow(foxmailItem);

    emailProgressBar = new QProgressBar();
    emailProgressBar->setStyleSheet("QProgressBar{border:none; color:white; text-align:center; background:white; }"
                                    "QProgressBar::chunk{background: rgb(0, 160, 230); }");


    QLabel *emailCheckPrompt = new QLabel();
    QPushButton *emailStartExport = new QPushButton();
    emailCheckPrompt->setStyleSheet("QLabel{color:gray;}");
    emailCheckPrompt->setText(tr("检测到以下数据可以选择导入:"));
    emailStartExport->setFixedSize(90, 28);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        emailStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport_en); color:gray;}"
                                        "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport_en); color:gray;}"
                                        "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport_en); color:gray;}");
    }
    else
    {
        emailStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport); color:gray;}"
                                        "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport); color:gray;}"
                                        "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport); color:gray;}");
    }

    browserInfo = new QLabel();
    /*设置一下QSS 在检测的过程中设置text*/
    browserInfo->setStyleSheet("QLabel{color:lightgray;}");
    emailInfo = new QLabel();
    emailInfo->setStyleSheet("QLabel{color:lightgray;}");
    //browserInfo->setText(tr("Microsoft Outlook 未安装"));



    QCheckBox *emailAllchecked = new QCheckBox();
    emailAllchecked->setText(tr("全选"));
    emailExportToPath = new QPushButton();
    QLabel *emailExportToLabel = new QLabel();
    emailAllchecked->setStyleSheet("QCheckBox{color:gray;}");
    emailExportToLabel->setStyleSheet("QLabel{color:gray;}");
    emailExportToPath->setStyleSheet("QPushButton{border:none; color:rgb(51, 168, 235); background:white;}");
    emailExportToLabel->setText(tr("源路径"));
    emailExportToPath->setText(this->dstFilePath);

    QVBoxLayout *emailMainLayout = new QVBoxLayout();
    QHBoxLayout *emailTopMainLayout = new QHBoxLayout();
    QVBoxLayout *emailCenterMainLayout = new QVBoxLayout();
    QHBoxLayout *emailBottomMainLayout = new QHBoxLayout();

    emailTopMainLayout->addWidget(emailCheckPrompt);
    emailTopMainLayout->addSpacing(10);
    emailTopMainLayout->addWidget(emailProgressBar);
    emailTopMainLayout->addSpacing(10);
    emailTopMainLayout->addWidget(emailStartExport);
    emailTopMainLayout->setContentsMargins(10, 12, 10, 0);
    emailCenterMainLayout->addWidget(emailTreeView);
    emailCenterMainLayout->setContentsMargins(0, 0, 0, 0);
    emailCenterMainLayout->setMargin(0);
    emailBottomMainLayout->addWidget(emailInfo);
    emailBottomMainLayout->addSpacing(80);
    emailBottomMainLayout->addWidget(emailExportToLabel);
    emailBottomMainLayout->addWidget(emailExportToPath);
    emailBottomMainLayout->addStretch();
    emailBottomMainLayout->setContentsMargins(12, 0, 0, 5);
    emailBottomMainLayout->setSpacing(4);
    emailMainLayout->setMargin(0);
    emailMainLayout->addLayout(emailTopMainLayout);
    emailMainLayout->addLayout(emailCenterMainLayout);
    emailMainLayout->addLayout(emailBottomMainLayout);
    emailMainLayout->setSpacing(0);
    emailMainLayout->setContentsMargins(0, 0, 1, 0);
    emailDetalWidget->setLayout(emailMainLayout);
    connect(emailStartExport, SIGNAL(clicked(bool)),this, SLOT(exportEmailDataSlot()));

}

void AppDetailWidget::initAppBrowerWidget()
{
    browserDetailWidget = new QWidget();
    QLabel *browserCheckPrompt = new QLabel();
    QPushButton *browserStartExport = new QPushButton();
    browserCheckPrompt->setStyleSheet("QLabel{color:gray;}");
    browserCheckPrompt->setText(tr("检测到以下数据可以选择导入:"));
    browserStartExport->setFixedSize(90, 28);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        browserStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport_en); color:gray;}"
                                          "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport_en); color:gray;}"
                                          "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport_en); color:gray;}");
    }
    else
    {
        browserStartExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/userwin/dstartexport); color:gray;}"
                                          "QPushButton:hover{border-radius:5px; border-image:url(:/userwin/startexport); color:gray;}"
                                          "QPushButton:pressed{border-radius:5px; border-image:url(:/userwin/ddstartexport); color:gray;}");
    }



    browserProgressBar = new QProgressBar();
    browserProgressBar->setStyleSheet("QProgressBar{border:none; color:white; text-align:center; background:white; }"
                                      "QProgressBar::chunk{background: rgb(0, 160, 230); }");

    browserAllchecked = new QCheckBox();
    browserAllchecked->setText(tr("全选"));
    browserExportToPath = new QPushButton();
    QLabel *browserExportToLabel = new QLabel();
    browserAllchecked->setStyleSheet("QCheckBox{color:gray;}");
    browserAllchecked->setTristate(true);
    connect(browserAllchecked,SIGNAL(stateChanged(int)),this,SLOT(browserAllcheckedstateChangedSlot(int)));
    browserExportToLabel->setStyleSheet("QLabel{color:gray;}");
    browserExportToPath->setStyleSheet("QPushButton{border:none; color:rgb(51, 168, 235); background:white;}");
    browserExportToLabel->setText(tr("源路径"));
    browserExportToPath->setText(this->dstFilePath);

    IESel = new QCheckBox();
    QLabel    *IEIcon = new QLabel();
    QLabel    *IETitle = new QLabel();

    IEcombox->setEditable(true);
    IEcombox->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:550px; background-color:white;}"
                            "QComboBox QAbstractItemView::item{height:22px;}"
                            "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                            "QComboBox::drop-down{border:0px;}");
    ieBtn->setStyleSheet("QPushButton{border-image:url(:/icon/file);}"
                         "QPushButton:hover{border-image:url(:/icon/dfile);}"
                         "QPushButton:pressed{border-image:url(:/icon/dfile);}");
    ieBtn->setFixedSize(26, 20);
    ieBtn->setContentsMargins(0, 0, 0, 1);

    /*是否要显示多行数据，下拉列表*/
    IETitle->setStyleSheet("QLabel{color:gray;}");
    IEIcon->setPixmap(QPixmap(":/appwin/ie"));
    IETitle->setText(tr("IE浏览器收藏夹"));
    QHBoxLayout *IEHlayout = new QHBoxLayout();
    IEHlayout->addSpacing(12);
    IEHlayout->addWidget(IESel);
    IEHlayout->addSpacing(15);
    IEHlayout->addWidget(IEIcon);
    IEHlayout->addWidget(IETitle);
    IEHlayout->addSpacing(30);
    IEHlayout->addWidget(IEcombox);
    IEHlayout->addWidget(ieBtn);
    IEHlayout->setSpacing(5);
    IEHlayout->addStretch();

    firefoxSel = new QCheckBox();
    QLabel    *firefoxIcon = new QLabel();
    QLabel    *firefoxTitle = new QLabel();

    firfoxCombox->setEditable(true);
    firfoxCombox->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:550px; background-color:white;}"
                                "QComboBox QAbstractItemView::item{height:22px;}"
                                "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                                "QComboBox::drop-down{border:0px;}");
    firfoxBtn->setStyleSheet("QPushButton{border-image:url(:/icon/file);}"
                             "QPushButton:hover{border-image:url(:/icon/dfile);}"
                             "QPushButton:pressed{border-image:url(:/icon/dfile);}");
    firfoxBtn->setFixedSize(26, 20);
    firfoxBtn->setContentsMargins(0, 0, 0, 1);

    /*是否要显示多行数据，下拉列表*/
    firefoxTitle->setStyleSheet("QLabel{color:gray;}");
    firefoxIcon->setPixmap(QPixmap(":/appwin/firefox"));
    firefoxTitle->setText(tr("火狐浏览器收藏夹"));
    QHBoxLayout *firefoxHlayout = new QHBoxLayout();
    firefoxHlayout->addSpacing(12);
    firefoxHlayout->addWidget(firefoxSel);
    firefoxHlayout->addSpacing(15);
    firefoxHlayout->addWidget(firefoxIcon);
    firefoxHlayout->addWidget(firefoxTitle);
    firefoxHlayout->addSpacing(18);
    firefoxHlayout->addWidget(firfoxCombox);
    firefoxHlayout->addWidget(firfoxBtn);
    firefoxHlayout->setSpacing(5);
    firefoxHlayout->addStretch();

    chromeSel = new QCheckBox();
    QLabel    *chromeIcon = new QLabel();
    QLabel    *chromeTitle = new QLabel();

    chromeCombox->setEditable(true);
    chromeCombox->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:550px; background-color:white;}"
                                "QComboBox QAbstractItemView::item{height:22px;}"
                                "QComboBox::down-arrow{image:url(:/icon/arrow);}"
                                "QComboBox::drop-down{border:0px;}");
    chromeBtn->setStyleSheet("QPushButton{border-image:url(:/icon/file);}"
                             "QPushButton:hover{border-image:url(:/icon/dfile);}"
                             "QPushButton:pressed{border-image:url(:/icon/dfile);}");
    chromeBtn->setFixedSize(26, 20);
    chromeBtn->setContentsMargins(0, 0, 0, 1);

    /*是否要显示多行数据，下拉列表*/
    chromeTitle->setStyleSheet("QLabel{color:gray;}");
    chromeIcon->setPixmap(QPixmap(":/appwin/chrome"));
    chromeTitle->setText(tr("谷歌浏览器收藏夹"));
    QHBoxLayout *chromeHlayout = new QHBoxLayout();
    chromeHlayout->addSpacing(12);
    chromeHlayout->addWidget(chromeSel);
    chromeHlayout->addSpacing(15);
    chromeHlayout->addWidget(chromeIcon);
    chromeHlayout->addWidget(chromeTitle);
    chromeHlayout->addSpacing(18);
    chromeHlayout->addWidget(chromeCombox);
    chromeHlayout->addWidget(chromeBtn);
    chromeHlayout->setSpacing(5);
    chromeHlayout->addStretch();

//    CDOSBrowserSel = new QCheckBox();
//    QLabel    *CDOSBrowserIcon = new QLabel();
//    QLabel    *CDOSBrowserTitle = new QLabel();

//    CDOSBrowserCombox->setEditable(true);
//    CDOSBrowserCombox->setStyleSheet("QComboBox{border:0.5px solid lightgray; height:18px; width:550px; background-color:white;}"
//                                "QComboBox QAbstractItemView::item{height:22px;}"
//                                "QComboBox::down-arrow{image:url(:/icon/arrow);}"
//                                "QComboBox::drop-down{border:0px;}");
//    CDOSBrowserBtn->setStyleSheet("QPushButton{border-image:url(:/icon/file);}"
//                             "QPushButton:hover{border-image:url(:/icon/dfile);}"
//                             "QPushButton:pressed{border-image:url(:/icon/dfile);}");
//    CDOSBrowserBtn->setFixedSize(26, 20);
//    CDOSBrowserBtn->setContentsMargins(0, 0, 0, 1);

//    /*是否要显示多行数据，下拉列表*/
//    CDOSBrowserTitle->setStyleSheet("QLabel{color:gray;}");
//    CDOSBrowserIcon->setPixmap(QPixmap(":/appwin/cdosbrowser"));
//    CDOSBrowserTitle->setText(tr("谷歌浏览器收藏夹"));
//    QHBoxLayout *CDOSBrowserHlayout = new QHBoxLayout();
//    CDOSBrowserHlayout->addSpacing(12);
//    CDOSBrowserHlayout->addWidget(CDOSBrowserSel);
//    CDOSBrowserHlayout->addSpacing(15);
//    CDOSBrowserHlayout->addWidget(CDOSBrowserIcon);
//    CDOSBrowserHlayout->addWidget(CDOSBrowserTitle);
//    CDOSBrowserHlayout->addSpacing(18);
//    CDOSBrowserHlayout->addWidget(CDOSBrowserCombox);
//    CDOSBrowserHlayout->addWidget(CDOSBrowserBtn);
//    CDOSBrowserHlayout->setSpacing(5);
//    CDOSBrowserHlayout->addStretch();

    QVBoxLayout *browserMainLayout = new QVBoxLayout();
    QHBoxLayout *browserTopMainLayout = new QHBoxLayout();
    QVBoxLayout *browserCenterMainLayout = new QVBoxLayout();
    QHBoxLayout *browserBottomMainLayout = new QHBoxLayout();
    browserTopMainLayout->addWidget(browserCheckPrompt);
    browserTopMainLayout->addSpacing(10);
    browserTopMainLayout->addWidget(browserProgressBar);
    browserTopMainLayout->addSpacing(10);
    browserTopMainLayout->addWidget(browserStartExport);
    browserTopMainLayout->setContentsMargins(10, 20, 10, 5);
    browserCenterMainLayout->addLayout(IEHlayout);
    browserCenterMainLayout->addLayout(firefoxHlayout);
    browserCenterMainLayout->addLayout(chromeHlayout);
//    browserCenterMainLayout->addLayout(CDOSBrowserHlayout);
    browserCenterMainLayout->setSpacing(15);
    browserCenterMainLayout->addStretch();
    browserCenterMainLayout->setContentsMargins(0, 15, 0, 0);
    browserBottomMainLayout->addWidget(browserInfo);
//    browserBottomMainLayout->addWidget(browserAllchecked);
    browserBottomMainLayout->addSpacing(80);
    browserBottomMainLayout->addWidget(browserExportToLabel);
    browserBottomMainLayout->addWidget(browserExportToPath);
    browserBottomMainLayout->addStretch();
    browserBottomMainLayout->setContentsMargins(12, 0, 0, 5);
    browserBottomMainLayout->setSpacing(4);
    browserMainLayout->setMargin(0);
    browserMainLayout->addLayout(browserTopMainLayout);
    browserMainLayout->addLayout(browserCenterMainLayout);
    browserMainLayout->addLayout(browserBottomMainLayout);
    browserMainLayout->setSpacing(0);
    browserMainLayout->setContentsMargins(0, 0, 1, 0);
    browserDetailWidget->setLayout(browserMainLayout);

    connect(IESel, SIGNAL(stateChanged(int)), this, SLOT(IECheckBoxSlot(int)));
    connect(firefoxSel, SIGNAL(stateChanged(int)), this, SLOT(FireFoxCheckBoxSlot(int)));
    connect(chromeSel, SIGNAL(stateChanged(int)), this, SLOT(ChromeCheckBoxSlot(int)));
//    connect(CDOSBrowserSel, SIGNAL(stateChanged(int)),this,SLOT(CDOSBrowsercheckBoxSlot(int)));
    connect(browserStartExport, SIGNAL(clicked()), this, SLOT(exportBrowserDataSlot()));
}

void AppDetailWidget::updateBrowserData()
{
    browserProgressBar->hide();
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(DESTINATION_GROUNP);
    QString desPath=appSettings->value(DEFAULT).toString();
    browserExportToPath->setText(desPath);
    QMap<QString, QString> m=Util::findDirs("Browser",desPath);
    QFileInfoList list;
    if(m.isEmpty())
    {
        list=Util::convenienceDir(desPath);
    }
    else
    {
        QList<QString> k=m.keys();
        list=Util::convenienceDir(m[k.at(0)]);
    }
    IEcombox->clear();
    firfoxCombox->clear();
    chromeCombox->clear();
//    CDOSBrowserCombox->clear();
    for(int i=0;i<list.count();i++)
    {
        QFileInfo info=list.at(i);
        if(info.suffix()=="sqlite")
        {
            firfoxCombox->addItem(info.filePath());
        }
        else if(info.suffix()=="url")
        {
            IEcombox->addItem(info.filePath());
        }
        else if(info.fileName()=="Bookmarks"&&(!info.filePath().contains("CDOSBrowser")))
        {
            chromeCombox->addItem(info.filePath());
        }
//        else if(info.fileName()=="Bookmarks"&&info.filePath().contains("CDOSBrowser"))
//        {
//            CDOSBrowserCombox->addItem(info.filePath());
//        }
    }
}

void AppDetailWidget::updateBrowserSlot()
{
    if(!favorites->isRunning())
        updateBrowserData();
}

void AppDetailWidget::updateEmailData()
{
    emailProgressBar->hide();
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(DESTINATION_GROUNP);
    QString desPath=appSettings->value(DEFAULT).toString();
    emailExportToPath->setText(desPath);
    QMap<QString, QString> m=Util::findDirs("Email",desPath);
    QFileInfoList list;
    if(m.isEmpty())
    {
        list=Util::convenienceDir(desPath);
    }
    else
    {
        QList<QString> k=m.keys();
        list=Util::convenienceDir(m[k.at(0)]);
    }
    for(int i=0;i<list.count();i++)
    {
        QFileInfo info=list.at(i);
        QStandardItem *accountItem = new QStandardItem(QIcon(":/appwin/account"), info.fileName()+"              FilePath:("+info.filePath()+"):End");
        accountItem->setCheckable(true);
        if(info.suffix()=="pst")
        {
            int j=0;
            for(j=0;j<outlookItem->rowCount();j++)
            {
                if(outlookItem->index().child(j,0).data().toString()==accountItem->text())
                {
                    break;
                }

            }
            if(outlookItem->index().child(j,0).data().toString()!=accountItem->text())
            {
                outlookItem->appendRow(accountItem);
                if(outlookItem->checkState()==Qt::Checked)
                {
                    outlookItem->setCheckState(Qt::PartiallyChecked);
                }
            }
        }
        else if(info.suffix()=="eml"&&info.filePath().contains("/DataMigration/Email/Foxmail"))
        {
            int j;
            for(j=0;j<foxmailItem->rowCount();j++)
            {
                if(foxmailItem->index().child(j,0).data().toString()==accountItem->text())
                {
                    break;
                }
            }
            if(foxmailItem->index().child(j,0).data().toString()!=accountItem->text())
            {
                foxmailItem->appendRow(accountItem);
                if(foxmailItem->checkState()==Qt::Checked)
                {
                    outlookItem->setCheckState(Qt::PartiallyChecked);
                }
            }
        }
    }
    for(int i=0;i<outlookItem->rowCount();i++)
    {
        int f=0;
        int j=0;
        for(j=0;j<list.count();j++)
        {
            QString s=list.at(j).fileName()+"              FilePath:("+list.at(j).filePath()+"):End";
            if(outlookItem->index().child(i,0).data().toString()==s)
            {
                f=1;
                break;
            }
        }
        if(f==0)
        {
            outlookItem->removeRow(i);
            i--;
        }
    }
    for(int i=0;i<foxmailItem->rowCount();i++)
    {
        int f=0;
        int j=0;
        for(j=0;j<list.count();j++)
        {
            QString s=list.at(j).fileName()+"              FilePath:("+list.at(j).filePath()+"):End";
            if(foxmailItem->index().child(i,0).data().toString()==s)
            {
                f=1;
                break;
            }
        }
        if(f==0)
        {
            foxmailItem->removeRow(i);
            i--;
        }
    }
    appSettings->endGroup();
    delete appSettings;
}

void AppDetailWidget::updateEmailDataSlot()
{
    if(!emailMigration->isRunning())
        updateEmailData();
}


void AppDetailWidget::emailBtnSlot(const QModelIndex &index)
{
    QString data = index.data().toString();
    if (data == "Microsoft Outlook")
    {
//        QString path=QFileDialog::getOpenFileName(this,tr("添加PST文件"),"~/","*.pst");
        QString path=FileDialog::getOpenFileName(this,tr("添加PST文件"),"~/","*.pst");
        if(!path.isEmpty())
        {
            QFileInfo info;
            info.setFile(path);
            QStandardItem *accountItem = new QStandardItem(QIcon(":/appwin/account"), info.fileName()+"              FilePath:("+info.filePath()+"):End");
            accountItem->setCheckable(true);
            outlookItem->appendRow(accountItem);
            if(outlookItem->checkState()==Qt::Checked)
            {
                outlookItem->setCheckState(Qt::PartiallyChecked);
            }
        }
    }
    if(data == "Foxmail 7")
    {
//        QString path=QFileDialog::getOpenFileName(this,tr("添加EML文件"),"~/","*.eml");
        QString path=FileDialog::getOpenFileName(this,tr("添加EML文件"),"~/","*.eml");
        if(!path.isEmpty())
        {
            QFileInfo info;
            info.setFile(path);
            QStandardItem *accountItem = new QStandardItem(QIcon(":/appwin/account"), info.fileName()+"              FilePath:("+info.filePath()+"):End");
            accountItem->setCheckable(true);
            foxmailItem->appendRow(accountItem);
            if(foxmailItem->checkState()==Qt::Checked)
            {
                foxmailItem->setCheckState(Qt::PartiallyChecked);
            }
        }
    }
}

void AppDetailWidget::treeItemChanged(QStandardItem * item)
{
    if(item == nullptr)
        return;
    if(item->isCheckable())
    {
        //如果条目是存在复选框的，那么就进行下面的操作
        Qt::CheckState state = item->checkState();//获取当前的选择状态
        if(item->isTristate())
        {
            //如果条目是三态的，说明可以对子目录进行全选和全不选的设置
            if(state != Qt::PartiallyChecked)
            {
                //当前是选中状态，需要对其子项目进行全选
                treeItem_checkAllChild(item,state == Qt::Checked ? true : false);
            }
        }
        else
        {
            //说明是两态的，两态会对父级的三态有影响
            //判断兄弟节点的情况
            treeItem_CheckChildChanged(item);
        }
    }
}

void AppDetailWidget::treeItem_checkAllChild(QStandardItem * item,bool check)
{
    if(item == nullptr)
        return;
    int rowCount = item->rowCount();
    for(int i=0; i < rowCount; ++i)
    {
        QStandardItem* childItems = item->child(i);
        treeItem_checkAllChild_recursion(childItems,check);
    }
    if(item->isCheckable())
        item->setCheckState(check ? Qt::Checked : Qt::Unchecked);
}

void AppDetailWidget::treeItem_checkAllChild_recursion(QStandardItem * item, bool check )
{
    if(item == nullptr)
        return;
    int rowCount = item->rowCount();
    for(int i=0;i<rowCount;++i)
    {
        QStandardItem* childItems = item->child(i);
        treeItem_checkAllChild_recursion(childItems,check);
    }
    if(item->isCheckable())
        item->setCheckState(check ? Qt::Checked : Qt::Unchecked);
}

Qt::CheckState AppDetailWidget::checkSibling(QStandardItem * item)
{
    //先通过父节点获取兄弟节点
    QStandardItem * parent = item->parent();
    if(nullptr == parent)
        return item->checkState();

    int brotherCount = parent->rowCount();
    int checkedCount(0),unCheckedCount(0);
    Qt::CheckState state;
    for(int i=0;i<brotherCount;++i)
    {
        QStandardItem* siblingItem = parent->child(i);
        state = siblingItem->checkState();
        if(Qt::PartiallyChecked == state)
            return Qt::PartiallyChecked;
        else if(Qt::Unchecked == state)
            ++unCheckedCount;
        else
            ++checkedCount;
        if(checkedCount>0 && unCheckedCount>0)
            return Qt::PartiallyChecked;
    }
    if(unCheckedCount>0)
        return Qt::Unchecked;
    return Qt::Checked;
}

void AppDetailWidget::treeItem_CheckChildChanged(QStandardItem * item)
{
    if(nullptr == item)
        return;
    Qt::CheckState siblingState = checkSibling(item);
    QStandardItem * parentItem = item->parent();
    if(nullptr == parentItem)
        return;
    if(Qt::PartiallyChecked == siblingState)
    {
        if(parentItem->isCheckable() && parentItem->isTristate())
            parentItem->setCheckState(Qt::PartiallyChecked);
    }
    else if(Qt::Checked == siblingState)
    {
        if(parentItem->isCheckable())
            parentItem->setCheckState(Qt::Checked);
    }
    else
    {
        if(parentItem->isCheckable())
            parentItem->setCheckState(Qt::Unchecked);
    }
    treeItem_CheckChildChanged(parentItem);
}

void AppDetailWidget::IEBrowserAdd()
{
//    QString fileName = QFileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
    QString fileName = FileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
    if(!fileName.isEmpty())
    {
        IEcombox->addItem(fileName);
    }
}

void AppDetailWidget::FirefoxBrowserAdd()
{
//    QString fileName = QFileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
    QString fileName = FileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
    if(!fileName.isEmpty())
    {
        firfoxCombox->addItem(fileName);
    }
}

void AppDetailWidget::ChromeBrowserAdd()
{
//    QString fileName = QFileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
    QString fileName = FileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
    if(!fileName.isEmpty())
    {
        chromeCombox->addItem(fileName);
    }
}

//void AppDetailWidget::CDOSBrowserAdd()
//{
//    QString fileName = QFileDialog::getOpenFileName(this, tr("添加浏览器收藏夹文件"), "~/");
//    if(!fileName.isEmpty())
//    {
//        CDOSBrowserCombox->addItem(fileName);
//    }
//}

void AppDetailWidget::checkClient()
{
    //调用其BrowserData   EmailData类中的客户端检测函数，进行本地显示
    //browserInfo->setText(tr("Firefox浏览器未安装"));
    //emailInfo->setText(tr("Microsoft Outlook客户端未安装"));
}

void AppDetailWidget::IECheckBoxSlot(int state)
{
    IECopyFileList.clear();
    if(state == Qt::Checked)
    {
        int count = IEcombox->count();
        for (int i = 0;i < count; i++)
        {
            IEcombox->setCurrentIndex(i);
            QString currentText = IEcombox->currentText();
            IECopyFileList.append(currentText);
        }
    }
    else if(state == Qt::Unchecked)
    {
        IECopyFileList.clear();
    }
    browserAllcheckedChange();
}

void AppDetailWidget::ChromeCheckBoxSlot(int state)
{
    ChromeCopyFileList.clear();
    if(state == Qt::Checked)
    {
        int count = chromeCombox->count();
        for (int i = 0;i < count; i++)
        {
            chromeCombox->setCurrentIndex(i);
            QString currentText = chromeCombox->currentText();
            ChromeCopyFileList.append(currentText);
        }
    }
    if(state == Qt::Unchecked)
    {
        ChromeCopyFileList.clear();
    }
    browserAllcheckedChange();
}

//void AppDetailWidget::CDOSBrowsercheckBoxSlot(int state)
//{
//    CDOSBrowserCopyFileList.clear();
//    if(state == Qt::Checked)
//    {
//        int count = CDOSBrowserCombox->count();
//        for (int i = 0;i < count; i++)
//        {
//            CDOSBrowserCombox->setCurrentIndex(i);
//            QString currentText = CDOSBrowserCombox->currentText();
//            CDOSBrowserCopyFileList.append(currentText);
//        }
//    }
//    if(state == Qt::Unchecked)
//    {
//        CDOSBrowserCopyFileList.clear();
//    }
//    browserAllcheckedChange();
//}

void AppDetailWidget::FireFoxCheckBoxSlot(int state)
{
    FireFoxCopyFileList.clear();
    if(state == Qt::Checked)
    {
        int count = firfoxCombox->count();
        for (int i = 0;i < count; i++)
        {
            firfoxCombox->setCurrentIndex(i);
            QString currentText = firfoxCombox->currentText();
            FireFoxCopyFileList.append(currentText);
        }
    }
    if(state == Qt::Unchecked)
    {
        FireFoxCopyFileList.clear();
    }
    browserAllcheckedChange();
}

void AppDetailWidget::browserAllcheckedstateChangedSlot(int state)
{
    if(state==Qt::Checked)
    {
        IESel->setChecked(true);
        firefoxSel->setChecked(true);
        chromeSel->setChecked(true);
//        CDOSBrowserSel->setChecked(true);
    }
    else if(state==Qt::Unchecked)
    {
        IESel->setChecked(false);
        IECopyFileList.clear();
        firefoxSel->setChecked(false);
        FireFoxCopyFileList.clear();
        chromeSel->setChecked(false);
        ChromeCopyFileList.clear();
//        CDOSBrowserSel->setChecked(false);
//        CDOSBrowserCopyFileList.clear();
    }
}

void AppDetailWidget::browserAllcheckedChange()
{
    int i=0;
    if(IESel->isChecked())
    {
        i++;
    }
    if(firefoxSel->isChecked())
    {
        i++;
    }
    if(chromeSel->isChecked())
    {
        i++;
    }
//    if(CDOSBrowserSel->isChecked())
//    {
//        i++;
//    }
//    if(i>=4)
    if(i>=3)
    {
        browserAllchecked->setCheckState(Qt::Checked);
    }
    else if(i==0)
    {
        browserAllchecked->setCheckState(Qt::Unchecked);
    }
    else
    {
        browserAllchecked->setCheckState(Qt::PartiallyChecked);
    }
}


void AppDetailWidget::exportBrowserDataSlot()
{
    if(IECopyFileList.isEmpty() && ChromeCopyFileList.isEmpty() && FireFoxCopyFileList.isEmpty())//&&CDOSBrowserCopyFileList.isEmpty())
    {
        msg->setInfo(tr("数据迁移"), tr("尚未选择浏览器收藏夹文件"), QPixmap(":/Message/error"), true, true);
        msg->exec();
    }
    if(!favorites->BrowserFavorites_Init())
    {
        QStringList listpath;
        favorites->FirefoxFavoritesPath.clear();
        favorites->ChromeFavoritesPath.clear();
        favorites->IEFavoritesPath.clear();
        favorites->CDOSBrowserFavoritesPath.clear();
        listpath.clear();
        if(!FireFoxCopyFileList.isEmpty())
        {
            for(int i=0;i<FireFoxCopyFileList.count();i++)
            {
                listpath.append(FireFoxCopyFileList.at(i));
            }
            favorites->FirefoxFavoritesPath=listpath;
        }
        if(!ChromeCopyFileList.isEmpty())
        {
            listpath.clear();
            for(int i=0;i<ChromeCopyFileList.count();i++)
            {
                listpath.append(ChromeCopyFileList.at(i));
            }
            favorites->ChromeFavoritesPath=listpath;
        }
        if(!IECopyFileList.isEmpty())
        {
            listpath.clear();
            for(int i=0;i<IECopyFileList.count();i++)
            {
                listpath.append(IECopyFileList.at(i));
            }
            favorites->IEFavoritesPath=listpath;
        }
//        if(!CDOSBrowserCopyFileList.isEmpty())
//        {
//            listpath.clear();
//            for(int i=0;i<CDOSBrowserCopyFileList.count();i++)
//            {
//                listpath.append(CDOSBrowserCopyFileList.at(i));
//            }
//            favorites->CDOSBrowserFavoritesPath=listpath;
//        }
//        Util::writecoreFile("app",QString::number(CDOSBrowserCopyFileList.count()));
        qDebug()<<favorites->IEFavoritesPath.count()<<favorites->FirefoxFavoritesPath.count()<<favorites->ChromeFavoritesPath.count();
        if(!listpath.isEmpty())
        {
            browserProgressBar->show();
            favorites->start();
        }
    }
    else
    {
        msg->setInfo(tr("数据迁移"),tr("未检测到浏览器客户端"),QPixmap(":/Message/error"),true,true);
        msg->exec();
    }

}

void AppDetailWidget::Favorites_successSlot()
{
    msg->setInfo(tr("数据迁移"),tr("收藏夹数据导入完成"),QPixmap(":/Message/yes"),true,true);
    msg->exec();
}

void AppDetailWidget::Favorites_error_numSlot(QList<int> ret, QList<QString> retname)
{
    QString msginfo;
    if(retname.contains("ImportFirefox_init error")||"ImportFirefox error")
    {
        msginfo.append(tr("Firefox失败"));
    }
    if(retname.contains("ImportCDOSBrowser2_init error")||retname.contains("ImportCDOSBrowser2 error"))
    {
        if(msginfo.isEmpty())
        {
            msginfo.append(tr("、CDOSBrowser2失败"));
        }
    }
    if(msginfo.isEmpty())
    {
        msginfo.append(tr("部分数据失败"));
    }
    else
    {
        msg->setInfo(tr("数据迁移"),tr("收藏夹数据导入")+msginfo,QPixmap(":/Message/error"),true,true);
        msg->exec();
    }
}

void AppDetailWidget::Favorites_progress_numSlot(int count, int over)
{
    double c=count;
    double o=over;
    browserProgressBar->setValue(o/c*100.0);
}

void AppDetailWidget::getEmailTreeView(const QModelIndex &index)
{

}

void AppDetailWidget::getemailItemData(QStandardItem * item)
{
    if(item == nullptr)
        return;
    if(item->isCheckable())
    {
        Qt::CheckState state = item->checkState();//获取当前的选择状态
        if(state == Qt::Checked)
        {
            QString data = item->index().data().toString();
            if(!emailFileList.contains(data) && !data.isEmpty())
            {
                emailFileList.append(data);
            }
        }
        if(state == Qt::Unchecked)
        {
            QString data = item->index().data().toString();
            if(emailFileList.contains(data))
            {
                emailFileList.removeOne(data);
            }
        }
    }
}

void AppDetailWidget::exportEmailDataSlot()
{
    if(outlookItem->checkState()==Qt::Unchecked&&foxmailItem->checkState()==Qt::Unchecked)
    {
        msg->setInfo(tr("数据迁移"), tr("尚未选择邮件文件"), QPixmap(":/Message/error"), true, true);
        msg->exec();
        return;
    }
    if(emailMigration->EmailDataMigration_Check_Client()==-1)
    {
        msg->setInfo(tr("数据迁移"),tr("未检测到邮件客户端"),QPixmap(":/Message/error"),true,true);
        msg->exec();
        return ;
    }
    QStringList name;
    if(emailMigration->EmailDataMigration_init())
    {
        msg->setInfo(tr("数据迁移"),tr("初始化失败"),QPixmap(":/Message/error"),true,true);
        msg->exec();
        return ;
    }
    if(emailMigration->CDOSMail_flag==0)
    {
        if(emailMigration->EmailDataMigration_check_CDOSMail_username(name)<0)
        {
            msg->setInfo(tr("数据迁移"),tr("用户名检测失败"),QPixmap(":/Message/error"),true,true);
            msg->exec();
            return ;
        }
        usemsg->setsignal("");
        usemsg->setUserName(name);
        usemsg->exec();
    }
    else
    {
        CDOSMail_SelectUserName_Slot();
    }
}

void AppDetailWidget::CDOSMail_SelectUserName_Slot()
{
    QStringList pstlist,emllist;
    int n=pstlist.count();
    for(int i=0;i<outlookItem->rowCount();i++)
    {
        if(outlookItem->child(i,0)->checkState()==Qt::Checked)
        {
            QString l=outlookItem->index().child(i,0).data().toString();
            QString p=l.section("              FilePath:(",1,1).section("):End",0,0);
            pstlist.append(p);
            n++;
        }
    }
    emailMigration->pstfilepath=pstlist;
    n=0;
    for(int i=0;i<foxmailItem->rowCount();i++)
    {
        if(foxmailItem->child(i,0)->checkState()==Qt::Checked)
        {
            QString l=foxmailItem->index().child(i,0).data().toString();
            QString p=l.section("              FilePath:(",1,1).section("):End",0,0);
            emllist.append(p);
            n++;
        }
    }
    emailMigration->emlfilepath=emllist;
    emailMigration->start();
    emailProgressBar->show();
}

void AppDetailWidget::CDOSMail_AddUserName_Error_Slot()
{
    usemsg->setsignal("Add Error");
}

void AppDetailWidget::CDOSMail_AddUserName_Ok_Slot()
{
    usemsg->setsignal("Add Ok");
}

void AppDetailWidget::EmailDataMigtation_Error_NumSlot(QList<int> ret,QList<QString> retname)
{
    if(ret.isEmpty())
    {
        msg->setInfo(tr("数据迁移"),tr("邮件数据导入失败:")+QString::number(ret.count()),QPixmap(":/Message/error"),true,true);
        msg->exec();
    }
}

void AppDetailWidget::EmailDataMigration_success_Slot()
{
    msg->setInfo(tr("数据迁移"),tr("邮件数据导入成功"),QPixmap(":/Message/yes"),true,true);
    msg->exec();
}

void AppDetailWidget::EmailDataMigtation_progressBar_numSlot(int count,int over)
{
    double c=count;
    double o=over;
    emailProgressBar->setValue(o/c*100.0);
}

void AppDetailWidget::appData_onekey()
{
    updateBrowserSlot();
    updateEmailDataSlot();
//    FireFoxCheckBoxSlot(Qt::Checked);
//    ChromeCheckBoxSlot(Qt::Checked);
//    IECheckBoxSlot(Qt::Checked);
    IESel->setCheckState(Qt::Checked);
    firefoxSel->setCheckState(Qt::Checked);
    chromeSel->setCheckState(Qt::Checked);
//    CDOSBrowserSel->setCheckState(Qt::Checked);
    appcount=0;
    appover=0;
    int emailcheck=emailMigration_one->EmailDataMigration_Check_Client();
    if(emailcheck!=-1&&!emailMigration_one->isRunning())
    {
        if(emailMigration_one->EmailDataMigration_init())
        {
            msg->setInfo(tr("数据迁移"),tr("应用数据导入初始化失败,获取本地路径错误，请确认邮件客户端和浏览器客户端的本地文件是否存在。"),QPixmap(":/Message/error"),true,true);
            msg->exec();
            return ;
        }
        QStringList name;
        if(emailcheck==-2||emailcheck==0)
        {
            if(emailMigration_one->EmailDataMigration_check_CDOSMail_username(name)<0)
            {
                msg->setInfo(tr("数据迁移"),tr("用户名检测失败"),QPixmap(":/Message/error"),true,true);
                msg->exec();
                return ;
            }
            usemsg_one->setsignal("");
            usemsg_one->setUserName(name);
            usemsg_one->exec();
        }
        appcount=outlookItem->rowCount()+foxmailItem->rowCount();
        QStringList pstlist,emllist;
        int n=pstlist.count();
        for(int i=0;i<outlookItem->rowCount();i++)
        {
            QString l=outlookItem->index().child(i,0).data().toString();
            pstlist.append(l.section("              FilePath:(",1,1).section("):End",0,0));
            n++;
        }
        emailMigration_one->pstfilepath=pstlist;
        n=0;
        for(int i=0;i<foxmailItem->rowCount();i++)
        {
            QString l=foxmailItem->index().child(i,0).data().toString();
            emllist.append(l.section("              FilePath:(",1,1).section("):End",0,0));
            n++;
        }
        emailMigration_one->emlfilepath=emllist;
    }
    if(!favorites_one->BrowserFavorites_Init()&&!favorites_one->isRunning())
    {
        appcount+=FireFoxCopyFileList.count()+ChromeCopyFileList.count()+IECopyFileList.count();//+CDOSBrowserCopyFileList.count();
        QStringList listpath;
        if(!FireFoxCopyFileList.isEmpty())
        {
            for(int i=0;i<FireFoxCopyFileList.count();i++)
            {
                listpath.append(FireFoxCopyFileList.at(i));
            }
            favorites_one->FirefoxFavoritesPath=listpath;
        }

        if(!ChromeCopyFileList.isEmpty())
        {
            listpath.clear();
            for(int i=0;i<ChromeCopyFileList.count();i++)
            {
                listpath.append(ChromeCopyFileList.at(i));
            }
            favorites_one->ChromeFavoritesPath=listpath;
        }
        if(!IECopyFileList.isEmpty())
        {
            listpath.clear();
            for(int i=0;i<IECopyFileList.count();i++)
            {
                listpath.append(IECopyFileList.at(i));
            }
            favorites_one->IEFavoritesPath=listpath;
        }
        favorites_one->CDOSBrowserFavoritesPath.clear();
//        if(!CDOSBrowserCopyFileList.isEmpty())
//        {
//            listpath.clear();
//            for(int i=0;i<CDOSBrowserCopyFileList.count();i++)
//            {
//                listpath.append(CDOSBrowserCopyFileList.at(i));
//            }
//            favorites_one->CDOSBrowserFavoritesPath=listpath;
//        }
    }
}

void AppDetailWidget::appData_onekey_progressBar_numSlot(int count, int over)
{
    appover++;
    emit appData_onekey_progress_num(appcount,appover);
}

void AppDetailWidget::appData_onekey_start()
{
    if(!emailMigration_one->isRunning())
        emailMigration_one->start();
    if(!favorites_one->isRunning())
        favorites_one->start();
}

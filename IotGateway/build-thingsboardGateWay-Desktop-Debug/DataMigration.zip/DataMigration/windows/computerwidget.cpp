#include "windows/computerwidget.h"
#include "windows/QRoundProgressBar.h"
#include "tools/utils.h"
#include <QLabel>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QColor>
#include <QTimer>

ComputerWidget::ComputerWidget(QWidget *parent)
    :QWidget(parent)
{
    compuLabel = new SysInfoLabel();
    progressBar = new QRoundProgressBar();
    sysverLabel = new QLabel();
    onebtnExport = new QPushButton();
    QGradientStops gradientPoints;
    gradientPoints << QGradientStop(0, QColor(149, 210, 244)) << QGradientStop(0.5, QColor(51, 153, 255)) << QGradientStop(1, QColor(31, 136, 216));

    QPalette pal;
    pal.setBrush(QPalette::Base, QColor(240, 240, 240));
    pal.setColor(QPalette::Background, Qt::white);
    pal.setColor(QPalette::Text, Qt::blue);
    pal.setColor(QPalette::Shadow, QColor(149, 210, 244));

//    QTimer *timer = new QTimer(this);
//    connect(timer, SIGNAL(timeout()), this, SLOT(progressBarSlot()));
//    timer->start(10);

    progressBar->setPalette(pal);
    progressBar->setNullPosition(QRoundProgressBar::PositionRight);
    progressBar->setBarStyle(QRoundProgressBar::StylePie);
    progressBar->setDataColors(gradientPoints);
    progressBar->setFixedSize(225, 225);
    progressBar->setValue(0);
    //progressBar
    compuLabel->loadPixmap(":/computer/maincom");
    onebtnExport->setFixedSize(173, 40);
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString v=appSettings->value("DEFAULT").toString();
    if(v.contains("EN"))
    {//此处把图片换成英文图片
        onebtnExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/computer/exportone_en); color:white;}"
                                    "QPushButton:hover{border-radius:5px; border-image:url(:/computer/dexportone_en);}"
                                    "QPushButton:pressed{border-radius:5px; border-image:url(:/computer/ddexportone_en);}");
    }
    else
    {
        onebtnExport->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/computer/exportone); color:white;}"
                                    "QPushButton:hover{border-radius:5px; border-image:url(:/computer/dexportone);}"
                                    "QPushButton:pressed{border-radius:5px; border-image:url(:/computer/ddexportone);}");
    }
    sysverLabel->setStyleSheet("QLabel{color:lightgray; font-size:24px; font-family:微软雅黑;}");
    compuLabel->setStyleSheet("QLabel{color:white; font-size:24px; font-family:微软雅黑;}");
    _init();
    compuLabel->setContentsMargins(0, 0, 0, 70);
    compuLabel->setAlignment(Qt::AlignCenter);
    QHBoxLayout *mainHLayout = new QHBoxLayout();
    QVBoxLayout *leftLayout = new QVBoxLayout();
    QVBoxLayout *rightLayout = new QVBoxLayout();
    leftLayout->addWidget(compuLabel, 0, Qt::AlignCenter);
    //leftLayout->addWidget(sysverLabel, 0, Qt::AlignCenter);
    leftLayout->setContentsMargins(0, 50, 0, 50);

    rightLayout->addWidget(progressBar, 0, Qt::AlignCenter);
    rightLayout->addWidget(onebtnExport, 0, Qt::AlignCenter);
    rightLayout->setSpacing(10);
    rightLayout->setContentsMargins(0, 80, 0, 60);

    mainHLayout->addLayout(leftLayout);
    mainHLayout->addLayout(rightLayout);
    mainHLayout->setContentsMargins(0, 0, 0, 30);
    setLayout(mainHLayout);
    connect(onebtnExport, SIGNAL(clicked(bool)), this, SIGNAL(exportOnekey()));
}

ComputerWidget::~ComputerWidget()
{
}

void ComputerWidget::setValues(double value)
{
    progressBar->setValue(value);
}

//void ComputerWidget::progressBarSlot()
//{
//    int i = progressBar->value();
//    if( i == 100)
//    {
//        i = 0;
//    }
//    i = i+1;
//    progressBar->setValue(i);
//}

void ComputerWidget::_init()
{
    QFile fd("/etc/issue");
    if(!fd.open(QIODevice::ReadOnly))
    {
        compuLabel->setText(tr("未识别的系统"));
        return ;
    }
    QString l=QString(fd.readLine().trimmed());
    compuLabel->setText(l.section(" ",0,0));
    fd.close();
}


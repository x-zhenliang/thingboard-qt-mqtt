#ifndef APPDETAILWIDGET_H
#define APPDETAILWIDGET_H
#include <QDialog>
#include <QSettings>
#include <QCoreApplication>
#include <QFileInfoList>
#include <QMap>
#include <QCheckBox>
#include "functions/browserfavorites.h"
#include "functions/emaildatamigration.h"
#include "windows/emailusernameselect.h"
#include "tools/utils.h"
#include "windows/filedialog.h"
class QWidget;
class QLabel;
class QListWidget;
class QStackedWidget;
class QPoint;
class QLineEdit;
class QComboBox;
class QPushButton;
class QTreeView;
class QStandardItemModel;
class QStandardItem;
class CustomDelegate;
class QProgressBar;
class CustomMessageBox;
class QModelIndex;

class AppDetailWidget : public QDialog
{
    Q_OBJECT
public:
    explicit AppDetailWidget(QWidget *parent = 0);
    ~AppDetailWidget();


protected:
    void paintEvent(QPaintEvent *);
public slots:
    void updateBrowserSlot();
    void updateEmailDataSlot();
    void emailBtnSlot(const QModelIndex &index);

private slots:
    void treeItemChanged(QStandardItem * item);
    void treeItem_checkAllChild(QStandardItem * item,bool check = true);
    void treeItem_checkAllChild_recursion(QStandardItem * item,bool check = true);
    Qt::CheckState checkSibling(QStandardItem * item);
    void treeItem_CheckChildChanged(QStandardItem * item);
    void iecomboboxdelete(const QModelIndex &index);
    void firefoxcomboboxdelete(const QModelIndex &index);
    void chromecomboboxdelete(const QModelIndex &index);
//    void CDOSBrowsercomboboxdelete(const QModelIndex &index);
    void browserAllcheckedstateChangedSlot(int state);

    void IEBrowserAdd();
    void FirefoxBrowserAdd();
    void ChromeBrowserAdd();
//    void CDOSBrowserAdd();
    void IECheckBoxSlot(int state);
    void ChromeCheckBoxSlot(int state);
//    void CDOSBrowsercheckBoxSlot(int state);
    void FireFoxCheckBoxSlot(int state);
    void exportBrowserDataSlot();
    void exportEmailDataSlot();
    void getEmailTreeView(const QModelIndex &index);
    void getemailItemData(QStandardItem * item);

    void EmailDataMigtation_Error_NumSlot(QList<int> ret,QList<QString> retname);
    void EmailDataMigtation_progressBar_numSlot(int count,int over);
    void CDOSMail_AddUserName_Error_Slot();
    void CDOSMail_AddUserName_Ok_Slot();
    void CDOSMail_SelectUserName_Slot();
    void EmailDataMigration_success_Slot();
//BrowserFavorites Slot
    void Favorites_error_numSlot(QList<int> ret,QList<QString> retname);
    void Favorites_progress_numSlot(int count,int over);
    void Favorites_successSlot(void);

    void appData_onekey_progressBar_numSlot(int count,int over);



private:
    void browserAllcheckedChange(void);

public:
    QLabel *browserInfo;
    QLabel *emailInfo;
    QString IEDir;
    QList <QString> chromeFile;
//    QList <QString> CDOSBrowserFile;
    QList <QString> firefoxFile;
    QListWidget *appLeftListWidget;
    QStackedWidget *appRightStackWidget;
    QWidget *emailDetalWidget;
    QWidget *browserDetailWidget;
    QProgressBar *emailProgressBar;
    QProgressBar *browserProgressBar;
    CustomMessageBox *msg;
    EmailUserNameSelect *usemsg;
    EmailUserNameSelect *usemsg_one;

    int appcount;

    void translateLanguage();
    void initAppEmailWidget();
    void initAppBrowerWidget();
    void updateBrowserData();
    void updateEmailData();
    void checkClient();

    void appData_onekey(void);
    void appData_onekey_start(void);

signals:
    void appData_onekey_progress_num(int coun,int over);

private:
    QComboBox *outlookFileCombox;
    QComboBox *foxmailFileCombox;
    QComboBox  *IEcombox;
    QComboBox  *firfoxCombox;
    QComboBox  *chromeCombox;
//    QComboBox  *CDOSBrowserCombox;
    QPushButton *outlookBtn;
    QPushButton *foxmailBtn;
    QPushButton *ieBtn;
    QPushButton *firfoxBtn;
    QPushButton *chromeBtn;
//    QPushButton *CDOSBrowserBtn;
    QCheckBox *IESel;
    QCheckBox *firefoxSel;
    QCheckBox *chromeSel;
//    QCheckBox *CDOSBrowserSel;
    QCheckBox *browserAllchecked;

    QList < QString > IEFileList;
    QList < QString > chromeFileList;
//    QList < QString > CDOSBrowserFileList;
    QList < QString > firfoxFileList;

    QString dstFilePath;
    QTreeView          *emailTreeView;
    QStandardItemModel *emailModel;
    CustomDelegate     *customDelegate;
    QStandardItem      *outlookItem;
    QStandardItem      *foxmailItem;

    QStringList IECopyFileList;
    QStringList ChromeCopyFileList;
//    QStringList CDOSBrowserCopyFileList;
    QStringList FireFoxCopyFileList;

    QStringList outlookFileList;
    QStringList foxmailFileList;
    QStringList emailFileList;

    BrowserFavorites *favorites;
    EmailDataMigration *emailMigration;

    BrowserFavorites *favorites_one;
    EmailDataMigration *emailMigration_one;
    QPushButton *emailExportToPath;
    QPushButton *browserExportToPath;


    int appover;
    /**/
};

#endif // APPDETAILWIDGET_H


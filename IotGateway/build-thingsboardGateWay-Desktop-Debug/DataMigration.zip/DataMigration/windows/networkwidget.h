#ifndef NETWORKWIDGET_H
#define NETWORKWIDGET_H
#include <QDialog>
#include "windows/messagebox.h"
#include "networkserver/reciveFile.h"
#include "windows/filedialog.h"
class QLabel;
class QPushButton;
class QLineEdit;
class QMouseEvent;
class QCheckBox;
class QStatusBar;

class NetworkWidget : public QDialog
{
    Q_OBJECT
public:
    explicit NetworkWidget(QWidget *parent = 0);
    ~NetworkWidget();
private:
    QLabel *titleLabel;
    QLabel *titleIcon;
    QPushButton *closeButton;
    QPushButton *ensureButton;
    QPoint move_point;
    bool   mouse_press;

    QLabel *userName;
    QLabel *passwd;
    QLabel *netPort;
    QLabel *netPath;
    QPushButton *browser;
    QPushButton *restartServer;
    QLineEdit *usernameEdit;
    QLineEdit *passwdEdit;
    QLineEdit *portEdit;
    QLineEdit *pathEdit;
//    QCheckBox *anonymous;
    QCheckBox *readOnly;
    QCheckBox *onlyIpAllowed;
    QStatusBar *statusBar;
    CustomMessageBox *msgInfo;

    ReciveFile *server;
    void loadSettings();
    void saveSettings();
    void startServer();
    QString lanIp();

private slots:
    void on_pushButtonRestartServer_clicked();
    void on_toolButtonBrowse_clicked();
    void onPeerIpChanged(const QString &peerIp);
    //void on_pushButtonShowDebugLog_clicked();
    void on_pushButtonExit_clicked();

protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *);
    void mouseMoveEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *);


};

#endif // NETWORKWIDGET_H

#include "emailusernameselect.h"

EmailUserNameSelect::EmailUserNameSelect(QWidget *parent)
    :QDialog(parent)
{
    resize(520, 280);
    setWindowTitle(tr("全版本更新和数据迁移工具-用户名选择"));
    setWindowFlags(Qt::FramelessWindowHint | Qt::Dialog);
    setWindowIcon(QPixmap(":/title/logo"));

    titleIcon = new QLabel();
    titleLabel = new QLabel();
    signalLabel = new QLabel();
    closeButton = new QPushButton();
    ensureButton = new QPushButton();
    cancelButton = new QPushButton();
    addButton = new QPushButton();
    addsureButton = new QPushButton();

    titleLabel->setStyleSheet("QLabel{color:white;}");
    signalLabel->setStyleSheet("QLabel{color:gray;}");
    titleIcon->setPixmap(QPixmap(":/title/logo"));
    titleIcon->setFixedSize(16, 16);
    titleIcon->setScaledContents(true);
    closeButton->setFixedSize(18, 18);
    closeButton->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/title/close);}"
                                 "QPushButton:hover{border-radius:5px; border-image:url(:/title/dclose);}"
                                 "QPushButton:pressed{border-radius:5px; border-image:url(:/title/dclose);}");
    closeButton->setContentsMargins(0, 0, 0, 5);
    ensureButton->setFixedSize(75, 25);
    ensureButton->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                           "QPushButton:hover{border-color:green; background:transparent;}");
    cancelButton->setFixedSize(75, 25);
    cancelButton->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                           "QPushButton:hover{border-color:green; background:transparent;}");
    addButton->setFixedSize(75, 25);
    addButton->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                           "QPushButton:hover{border-color:green; background:transparent;}");
    addsureButton->setFixedSize(75, 25);
    addsureButton->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                           "QPushButton:hover{border-color:green; background:transparent;}");
    QHBoxLayout *titleLayout = new QHBoxLayout();
    titleLayout->addWidget(titleIcon, 0, Qt::AlignVCenter);
    titleLayout->addWidget(titleLabel, 0, Qt::AlignVCenter);
    titleLayout->addStretch();
    titleLayout->addWidget(closeButton, 0, Qt::AlignVCenter);
    titleLayout->setSpacing(5);
    titleLayout->setContentsMargins(2, 0, 2, 0);

    listItemModel = new QStandardItemModel(this);
    listItemModel->setColumnCount(2);
    listItemModel->setHeaderData(0,Qt::Horizontal,tr("用户名"));
    listItemModel->setHeaderData(1,Qt::Horizontal,tr("密码"));
    leftPathView = new QTableView();
    leftPathView->setContentsMargins(0, 0, 0, 0);
    leftPathView->setStyleSheet("QListView{border:none; background:rgb(230,240,230);}");

    QVBoxLayout *sho = new QVBoxLayout();
    sho->addWidget(leftPathView);

    QHBoxLayout *bottomLayout = new QHBoxLayout();
    bottomLayout->addStretch();
    bottomLayout->addWidget(signalLabel);
    bottomLayout->addSpacing(20);
    bottomLayout->addWidget(addsureButton);
    bottomLayout->addSpacing(20);
    bottomLayout->addWidget(addButton);
    bottomLayout->addSpacing(20);
    bottomLayout->addWidget(ensureButton);
    bottomLayout->addSpacing(20);
    bottomLayout->addWidget(cancelButton);
    bottomLayout->setSpacing(0);
    bottomLayout->setContentsMargins(0, 0, 30, 20);

    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(titleLayout);
    mainLayout->addStretch();
    mainLayout->addLayout(sho);
    mainLayout->addStretch();
    mainLayout->addLayout(bottomLayout);
    mainLayout->setSpacing(0);
    mainLayout->setContentsMargins(8, 8, 8, 0);
    setLayout(mainLayout);

    connect(ensureButton, SIGNAL(clicked()), this, SLOT(ensureButton_Slot()));
    connect(closeButton, SIGNAL(clicked()), this, SLOT(hide()));
    connect(cancelButton,SIGNAL(clicked()),this,SLOT(hide()));
    connect(addButton,SIGNAL(clicked()),this,SLOT(UserAdd()));
    connect(addsureButton,SIGNAL(clicked()),this,SLOT(UserAddSure()));
    connect(leftPathView,SIGNAL(clicked(QModelIndex)),this,SLOT(TableView_Select(QModelIndex)));
    translateLanguage();
}

EmailUserNameSelect::~EmailUserNameSelect()
{

}
void EmailUserNameSelect::translateLanguage()
{
    titleLabel->setText(tr("数据迁移-邮件"));
    ensureButton->setText(tr("确定"));
    cancelButton->setText(tr("取消"));
    addButton->setText(tr("添加"));
    addsureButton->setText(tr("确定添加"));
}

void EmailUserNameSelect::setsignal(QString name)
{
    signalLabel->setText(name);
}

void EmailUserNameSelect::setUserName(QStringList name)
{
    listItemModel->clear();
    leftPathView->setModel(listItemModel);
    sqlusername=name;
    for(int i=0;i<name.count();i++)
    {
        QList<QStandardItem *>item;
        QStandardItem *userItem = new QStandardItem(name.at(i));
        QStandardItem *nameItem = new QStandardItem(tr("*******"));
        item.append(userItem);
        item.append(nameItem);
//        int f=0;
//        for(int i=0;i<listItemModel->rowCount();i++)
//        {
//            QModelIndex index=listItemModel->index(i,0);
//            qDebug()<<index.data().toString();
//            if(index.data().toString()==name.at(i))
//            {
//                f=1;
//                break;
//            }
//        }
//        if(!f)
//        {
            listItemModel->appendRow(item);
//        }
    }
    leftPathView->setModel(listItemModel);
}

void EmailUserNameSelect::TableView_Select(QModelIndex buf)
{
    currentindex=buf;
}

void EmailUserNameSelect::ensureButton_Slot()
{
    QString username=listItemModel->data(currentindex).toString();
    emit SelectUserName(username);
    hide();
}

void EmailUserNameSelect::UserAdd()
{
    QStandardItem *userItem = new QStandardItem(tr("请在此输入用户名"));
    QStandardItem *nameItem = new QStandardItem(tr("请在此输入密码"));
    QList<QStandardItem *>item;
    item.append(userItem);
    item.append(nameItem);
    listItemModel->appendRow(item);
    leftPathView->setModel(listItemModel);
}

void EmailUserNameSelect::UserAddSure()
{
    QStringList name,pass;
    for(int i=0;i<listItemModel->rowCount();i++)
    {
        QModelIndex b=listItemModel->index(i,0);
        QString n=listItemModel->data(b).toString();
        b=listItemModel->index(i,1);
        QString p=listItemModel->data(b).toString();
        int f=0;
        for(int j=0;j<sqlusername.count();j++)
        {
            if(sqlusername.at(j)==n)
            {
                f=1;
                break;
            }
        }
        if(f==0)
        {
            name.append(n);
            pass.append(p);

        }
    }
    if(name.count()!=0)
        emit AddUserName(name,pass);
}

void EmailUserNameSelect::mousePressEvent(QMouseEvent *event)
{
    if(event->buttons() == Qt::LeftButton)
    {
        mouse_press = true;
    }
    move_point = event->globalPos() - pos();
}

void EmailUserNameSelect::mouseReleaseEvent(QMouseEvent *)
{
    mouse_press = false;
}

void EmailUserNameSelect::mouseMoveEvent(QMouseEvent *event)
{
    if(mouse_press)
    {
        QPoint move_pos = event->globalPos();
        move(move_pos - move_point);
    }
}

void EmailUserNameSelect::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), QPixmap(":/background/back"));
    QPainter painterWidget(this);
    QLinearGradient linearWidget(rect().topLeft(), rect().bottomLeft());
    linearWidget.setColorAt(0, Qt::white);
    linearWidget.setColorAt(0.5, Qt::white);
    linearWidget.setColorAt(1, Qt::white);
    painterWidget.setPen(Qt::white);
    painterWidget.setBrush(linearWidget);
    painterWidget.drawRect(QRect(0, 30, this->width(), this->height()-30));
    QPainter painterFrame(this);
    painterFrame.setPen(Qt::gray);
    static const QPointF points[4] = {QPointF(0, 30), QPointF(0, this->height()-1), QPointF(this->width()-1, this->height()-1), QPointF(this->width()-1, 30)};
    painterFrame.drawPolyline(points, 4);
}


#include "windows/networkwidget.h"
#include <QPushButton>
#include <QLabel>
#include <QMouseEvent>
#include <QPainter>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QCheckBox>
#include <QLineEdit>
#include <QCoreApplication>
#include <QSettings>
#include <QNetworkInterface>
#include <QHostAddress>
#include <QFileDialog>
#include <QIntValidator>
#include <QSettings>
#include <QStatusBar>


NetworkWidget::NetworkWidget(QWidget *parent)
    : QDialog(parent)
{
    resize(460, 150);
    setWindowTitle(tr("全版本更新和数据迁移工具-网络传输"));
    setWindowFlags(Qt::FramelessWindowHint | Qt::Dialog);
    setWindowIcon(QPixmap(":/title/logo"));
    titleIcon = new QLabel();
    titleLabel = new QLabel();
    closeButton = new QPushButton();
    closeButton->setFixedSize(18, 18);
    closeButton->setStyleSheet("QPushButton{border-radius:5px; border-image:url(:/title/close);}"
                              "QPushButton:hover{border-radius:5px; border-image:url(:/title/dclose);}"
                              "QPushButton:pressed{border-radius:5px; border-image:url(:/title/dclose);}");
    titleLabel->setStyleSheet("QLabel{color:white;}");
    titleLabel->setText(tr("网络传输服务"));
    titleIcon->setPixmap(QPixmap(":/title/logo"));
    titleIcon->setFixedSize(16, 16);
    titleIcon->setScaledContents(true);
    closeButton->setContentsMargins(0, 0, 0, 5);

    userName = new QLabel();
    passwd = new QLabel();
    netPort = new QLabel();
    netPath = new QLabel();

    userName ->setText(tr("用户名"));
    passwd->setText(tr("密码"));
    netPort->setText(tr("端口"));
    netPath->setText(tr("路径"));


    userName->setStyleSheet("QLabel{color:rgb(43,165,237); font: bold; font-size:12px; font-family:黑体;}");
    passwd->setStyleSheet("QLabel{color:rgb(43,165,237); font: bold; font-size:12px; font-family:黑体;}");
    netPort->setStyleSheet("QLabel{color:rgb(43,165,237); font: bold; font-size:12px; font-family:黑体;}");
    netPath->setStyleSheet("QLabel{color:rgb(43,165,237); font: bold; font-size:12px; font-family:黑体;}");

    browser = new QPushButton();
    restartServer = new QPushButton();

    browser->setText(tr("..."));
    browser->setFixedSize(36, 24);
    browser->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                                 "QPushButton:hover{border-color:green; background:transparent;}");

    restartServer->setText(tr("重启网络服务器"));
    restartServer->setFixedSize(120, 30);
    restartServer->setStyleSheet("QPushButton{border:1px solid lightgray; background:rgb(230,230,230);}"
                                 "QPushButton:hover{border-color:green; background:transparent;}");

//    anonymous = new QCheckBox();
    readOnly = new QCheckBox();
    onlyIpAllowed = new QCheckBox();

//    anonymous->setText(tr("允许匿名登录"));
    readOnly->setText(tr("只读"));
    onlyIpAllowed->setText(tr(""));
    usernameEdit = new QLineEdit();
    passwdEdit = new QLineEdit();
    portEdit = new QLineEdit();
    pathEdit = new QLineEdit();

    statusBar = new QStatusBar();
    statusBar->setSizeGripEnabled(false);
    usernameEdit->setFixedWidth(150);
    QHBoxLayout *userLayout = new QHBoxLayout();
    userLayout->addWidget(userName);
    userLayout->addWidget(usernameEdit);
    userLayout->addSpacing(12);
    userLayout->addWidget(passwd);
    userLayout->addWidget(passwdEdit);
    userLayout->setContentsMargins(15, 0, 15, 0);

    portEdit->setFixedWidth(150);
    QHBoxLayout *portLayout = new QHBoxLayout();
    portLayout->addWidget(netPort);
    portLayout->addSpacing(12);
    portLayout->addWidget(portEdit);
    portLayout->addSpacing(12);
    portLayout->addWidget(netPath);
    portLayout->addWidget(pathEdit);
    portLayout->addWidget(browser);
    portLayout->setContentsMargins(15, 0, 15, 0);


    QHBoxLayout *checkLayout2 = new QHBoxLayout();
    //checkLayout2->addWidget(readOnly);
    checkLayout2->setContentsMargins(15, 0, 15, 0);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->addWidget(statusBar);
    buttonLayout->addWidget(restartServer);
    buttonLayout->setContentsMargins(15, 0, 15, 0);

    QHBoxLayout *titleLayout = new QHBoxLayout();
    titleLayout->addWidget(titleIcon, 0, Qt::AlignVCenter);
    titleLayout->addWidget(titleLabel, 0, Qt::AlignVCenter);
    titleLayout->addStretch();
    titleLayout->addWidget(closeButton, 0, Qt::AlignVCenter);
    titleLayout->setSpacing(5);
    titleLayout->setContentsMargins(4, 3, 4, 0);

    QVBoxLayout *mainLayout = new QVBoxLayout();
    mainLayout->addLayout(titleLayout);
    mainLayout->addSpacing(25);
//    mainLayout->addLayout(userLayout);
    mainLayout->addLayout(portLayout);
    mainLayout->addLayout(checkLayout2);
    mainLayout->addSpacing(20);
    mainLayout->addLayout(buttonLayout);
    mainLayout->addStretch();
    mainLayout->setMargin(2);
    setLayout(mainLayout);
    connect(closeButton, SIGNAL(clicked()), this, SLOT(on_pushButtonExit_clicked()));
    connect(browser, SIGNAL(clicked()), this, SLOT(on_toolButtonBrowse_clicked()));
    connect(restartServer, SIGNAL(clicked()), this, SLOT(on_pushButtonRestartServer_clicked()));
    msgInfo = new CustomMessageBox(this);

    portEdit->setValidator(new QIntValidator(1, 65535, this));
    pathEdit->setFocusPolicy(Qt::NoFocus);
    loadSettings();
    server = 0;
    startServer();
}

NetworkWidget::~NetworkWidget()
{
    saveSettings();
}

void NetworkWidget::mousePressEvent(QMouseEvent *event)
{
    if(event->buttons() == Qt::LeftButton)
    {
        mouse_press = true;
    }
    move_point = event->globalPos() - pos();
}


void NetworkWidget::mouseReleaseEvent(QMouseEvent *)
{
    mouse_press = false;
}

void NetworkWidget::mouseMoveEvent(QMouseEvent *event)
{
    if(mouse_press)
    {
        QPoint move_pos = event->globalPos();
        move(move_pos - move_point);
    }
}

void NetworkWidget::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), QPixmap(":/background/back"));
    QPainter painterWidget(this);
    QLinearGradient linearWidget(rect().topLeft(), rect().bottomLeft());
    linearWidget.setColorAt(0, Qt::white);
    linearWidget.setColorAt(0.5, Qt::white);
    linearWidget.setColorAt(1, Qt::white);
    painterWidget.setPen(Qt::white);
    painterWidget.setBrush(linearWidget);
    painterWidget.drawRect(QRect(0, 30, this->width(), this->height()-30));


    QPainter painterFrame(this);
    painterFrame.setPen(Qt::gray);
    static const QPointF points[4] = {QPointF(0, 30), QPointF(0, this->height()-1), QPointF(this->width()-1, this->height()-1), QPointF(this->width()-1, 30)};
    painterFrame.drawPolyline(points, 4);
}


void NetworkWidget::loadSettings()
{
    QString defaultPort;
    defaultPort = "2121";

    QSettings settings;
    portEdit->setText(settings.value("settings/port", defaultPort).toString());
//    usernameEdit->setText(settings.value("settings/username", "dataMigration").toString());
//    passwdEdit->setText(settings.value("settings/password", "nfschina").toString());
    pathEdit->setText(settings.value("settings/rootpath", QDir::rootPath()).toString());
    if(pathEdit->text().isEmpty())
    {
        pathEdit->setText(QString(getenv("HOME")));
    }
}

void NetworkWidget::saveSettings()
{
    QSettings settings;
    settings.setValue("settings/port", portEdit->text());
    settings.setValue("settings/username", usernameEdit->text());
    settings.setValue("settings/password", passwdEdit->text());
    settings.setValue("settings/rootpath", pathEdit->text());
}

void NetworkWidget::startServer()
{
    delete server;
    server = new ReciveFile();
    server->hostaAddress=lanIp();
    server->port=portEdit->text().toInt();
    server->fileSavePath=pathEdit->text();
    if(!server->start())
    {
        statusBar->showMessage(tr("监听: ") + lanIp());
    }
    else
    {
        statusBar->showMessage(tr("未监听"));
    }
}

QString NetworkWidget::lanIp()
{
    foreach (const QHostAddress &address, QNetworkInterface::allAddresses()) {
        if (address.protocol() == QAbstractSocket::IPv4Protocol && address != QHostAddress(QHostAddress::LocalHost)) {
            return address.toString();
        }
    }
    return "";
}

void NetworkWidget::on_pushButtonRestartServer_clicked()
{
    if(portEdit->text().isEmpty()||pathEdit->text().isEmpty())
    {
        msgInfo->setInfo(tr("网络传输"), tr("网络参数设置错误，请重新设置"), QPixmap(":/Message/error"), true, true);
        msgInfo->exec();
        return ;
    }
    saveSettings();
    loadSettings();
    startServer();
    msgInfo->setInfo(tr("网络传输"), tr("网络服务器重启成功"), QPixmap(":/Message/yes"), true, true);
    msgInfo->exec();
}

void NetworkWidget::on_toolButtonBrowse_clicked()
{
    QString rootPath;
//    rootPath = QFileDialog::getExistingDirectory(this, QString(), pathEdit->text());
    rootPath = FileDialog::getExistingDirectory(this, QString(), pathEdit->text());
    if (rootPath.isEmpty())
    {
            return;
    }
    pathEdit->setText(rootPath);

    saveSettings();
    loadSettings();
}

void NetworkWidget::onPeerIpChanged(const QString &peerIp)
{
    //qDebug() << peerIp;
}

void NetworkWidget::on_pushButtonExit_clicked()
{
    usernameEdit->clear();
    passwdEdit->clear();
    close();
}

#include "windows/datamigration.h"
#include <QApplication>
#include <QFontDatabase>
#include <QDebug>
#include <QTextCodec>
#include <QDir>
#include <QMessageBox>
#include <QDebug>
#include <QDesktopWidget>
#include <QCoreApplication>
#include <QtCore/QCoreApplication>
#include "functions/createconfigure.h"
/*unCompress add this include file   */
//#include "JlCompress.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);    
    QTranslator qtTranslator;

    ConfigureDirTool sysConf("NFSChina_IN", "DataMigration");
    if(!sysConf.check())
    {
        sysConf.createIniFile(CONFIG_INI);
    }
    else
    {
        sysConf.createIniFile(CONFIG_SET);
    }
    sysConf.makeDstDir();

    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(LANGUAGE_DEFAULT);
    QString desPath=appSettings->value(DEFAULT).toString();
    if(desPath.isEmpty()||desPath.contains("CN"))
    {
        qtTranslator.load(":/Language/zh_CN");
    }
    else
    {
        qtTranslator.load(":/Language/DataMigration_EN");
    }
    a.installTranslator(&qtTranslator);

    DataMigration w;
    w.setTranslator(&qtTranslator);

    w.move(
                (QApplication::desktop()->width()-w.width())/2,
                (QApplication::desktop()->height()-w.height())/2
                );
    w.show();


    return a.exec();
}

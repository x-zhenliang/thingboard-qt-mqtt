#ifndef SSLSERVER_H
#define SSLSERVER_H

#include <QTcpServer>

class QSslSocket;


class SslServer : public QTcpServer
{
    Q_OBJECT
public:
    explicit SslServer(QObject *parent);  
    static void setLocalCertificateAndPrivateKey(QSslSocket *socket);

signals:

private:
    typedef qintptr PortableSocketDescriptorType;
    void incomingConnection(PortableSocketDescriptorType socketDescriptor);
};

#endif // SSLSERVER_H

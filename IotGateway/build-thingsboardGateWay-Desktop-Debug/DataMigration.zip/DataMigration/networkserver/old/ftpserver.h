#ifndef FTPSERVER_H
#define FTPSERVER_H

#include <QObject>
#include <QSet>

class SslServer;


class FtpServer : public QObject
{
    Q_OBJECT
public:
    explicit FtpServer(QObject *parent, const QString &rootPath, int port = 21,
                       const QString &userName = QString(), const QString &password = QString(),
                       bool readOnly = false, bool onlyOneIpAllowed = false);

    bool isListening();

signals:
    void newPeerIp(const QString &ip);

private slots:
    void startNewControlConnection();

private:

    QString userName;
    QString password;
    QString rootPath;
    SslServer *server;
    QSet<QString> encounteredIps;
    bool readOnly;
    bool onlyOneIpAllowed;
};

#endif // FTPSERVER_H

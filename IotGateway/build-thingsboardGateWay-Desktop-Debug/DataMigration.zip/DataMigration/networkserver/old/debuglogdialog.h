#ifndef DEBUGLOGDIALOG_H
#define DEBUGLOGDIALOG_H
#include <QDialog>


#endif

#include "debuglogdialog.h"

<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>AboutUsDialog</name>
    <message>
        <location filename="../windows/aboutus.cpp" line="17"/>
        <source>全版本更新和数据迁移工具-关于</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="105"/>
        <source>数据迁移-关于</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="106"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="107"/>
        <source>数据迁移</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="108"/>
        <source>Windows系统数据迁移CDOS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="109"/>
        <source>主程序版本: 0.0.1_Alpha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="110"/>
        <source>作者</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="111"/>
        <source>Copyright(c) nfschina.com Inc. All Rights Reserved</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AppDetailWidget</name>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="76"/>
        <source>邮件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="77"/>
        <source>收藏夹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="191"/>
        <source>邮件客户端数据</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="206"/>
        <location filename="../windows/appdetailwidget.cpp" line="281"/>
        <source>检测到以下数据可以选择导入:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="234"/>
        <location filename="../windows/appdetailwidget.cpp" line="306"/>
        <source>全选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="240"/>
        <location filename="../windows/appdetailwidget.cpp" line="314"/>
        <source>源路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="335"/>
        <source>IE浏览器收藏夹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="366"/>
        <source>火狐浏览器收藏夹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="397"/>
        <source>谷歌浏览器收藏夹</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="610"/>
        <source>添加PST文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="626"/>
        <source>添加EML文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="752"/>
        <location filename="../windows/appdetailwidget.cpp" line="761"/>
        <location filename="../windows/appdetailwidget.cpp" line="770"/>
        <source>添加浏览器收藏夹文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="897"/>
        <location filename="../windows/appdetailwidget.cpp" line="942"/>
        <location filename="../windows/appdetailwidget.cpp" line="950"/>
        <location filename="../windows/appdetailwidget.cpp" line="974"/>
        <location filename="../windows/appdetailwidget.cpp" line="1021"/>
        <location filename="../windows/appdetailwidget.cpp" line="1027"/>
        <location filename="../windows/appdetailwidget.cpp" line="1034"/>
        <location filename="../windows/appdetailwidget.cpp" line="1042"/>
        <location filename="../windows/appdetailwidget.cpp" line="1101"/>
        <location filename="../windows/appdetailwidget.cpp" line="1108"/>
        <location filename="../windows/appdetailwidget.cpp" line="1136"/>
        <location filename="../windows/appdetailwidget.cpp" line="1145"/>
        <source>数据迁移</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="897"/>
        <source>尚未选择浏览器收藏夹文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="942"/>
        <source>未检测到浏览器客户端</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="959"/>
        <source>Firefox失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="965"/>
        <source>、CDOSBrowser2失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="970"/>
        <source>部分数据失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="974"/>
        <source>收藏夹数据导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1021"/>
        <source>尚未选择邮件文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1027"/>
        <source>未检测到邮件客户端</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1034"/>
        <source>初始化失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1042"/>
        <location filename="../windows/appdetailwidget.cpp" line="1145"/>
        <source>用户名检测失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1101"/>
        <source>邮件数据导入失败:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1108"/>
        <source>邮件数据导入成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1136"/>
        <source>应用数据导入初始化失败,获取本地路径错误，请确认邮件客户端和浏览器客户端的本地文件是否存在。</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ComputerWidget</name>
    <message>
        <location filename="../windows/computerwidget.cpp" line="104"/>
        <source>未识别的系统</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CustomMessageBox</name>
    <message>
        <location filename="../windows/messagebox.cpp" line="12"/>
        <source>全版本更新和数据迁移工具-提示</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/messagebox.cpp" line="65"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/messagebox.cpp" line="66"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DataMigration</name>
    <message>
        <location filename="../windows/datamigration.cpp" line="20"/>
        <source>全版本更新和数据迁移工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/datamigration.cpp" line="291"/>
        <location filename="../windows/datamigration.cpp" line="316"/>
        <source>数据迁移</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/datamigration.cpp" line="291"/>
        <source>请设置源文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/datamigration.cpp" line="316"/>
        <source>一键导入完成</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DirectoryDlg</name>
    <message>
        <location filename="../windows/directorydlg.cpp" line="37"/>
        <source>源路径列表</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="48"/>
        <source>增加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="49"/>
        <source>移除</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="50"/>
        <source>返回</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="57"/>
        <source>数据迁移-源路径设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="178"/>
        <source>选择源路径</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EmailUserNameSelect</name>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="7"/>
        <source>全版本更新和数据迁移工具-用户名选择</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="52"/>
        <source>用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="53"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="100"/>
        <source>数据迁移-邮件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="101"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="102"/>
        <source>取消</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="103"/>
        <source>添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="104"/>
        <source>确定添加</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="121"/>
        <source>*******</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="157"/>
        <source>请在此输入用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="158"/>
        <source>请在此输入密码</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="../windows/mainmenu.cpp" line="26"/>
        <source>设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/mainmenu.cpp" line="27"/>
        <source>关于</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkWidget</name>
    <message>
        <location filename="../windows/networkwidget.cpp" line="24"/>
        <source>全版本更新和数据迁移工具-网络传输</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="35"/>
        <source>网络传输服务</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="46"/>
        <source>用户名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="47"/>
        <source>密码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="48"/>
        <source>端口</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="49"/>
        <source>路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="60"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="65"/>
        <source>重启网络服务器</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="75"/>
        <source>只读</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="224"/>
        <source>监听: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="228"/>
        <source>未监听</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="246"/>
        <location filename="../windows/networkwidget.cpp" line="252"/>
        <source>网络传输</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="246"/>
        <source>网络参数设置错误，请重新设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="252"/>
        <source>网络服务器重启成功</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="269"/>
        <source>01月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="273"/>
        <source>02月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="277"/>
        <source>03月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="281"/>
        <source>04月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="285"/>
        <source>05月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="289"/>
        <source>06月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="293"/>
        <source>07月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="297"/>
        <source>08月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="301"/>
        <source>09月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="305"/>
        <source>10月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="309"/>
        <source>11月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="313"/>
        <source>12月</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="315"/>
        <source>年</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="315"/>
        <source>日</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QRoundProgressBar</name>
    <message>
        <location filename="../windows/QRoundProgressBar.cpp" line="38"/>
        <source>幼圆</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../windows/settingdialog.cpp" line="27"/>
        <source>全版本更新和数据迁移工具-设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="46"/>
        <source>源路径设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="47"/>
        <source>目标路径设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="48"/>
        <source>语言设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="176"/>
        <source>数据迁移-设置</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="177"/>
        <source>返回</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="178"/>
        <source>确定</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="188"/>
        <source>图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="189"/>
        <source>音乐</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="190"/>
        <source>视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="191"/>
        <source>文档</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="231"/>
        <location filename="../windows/settingdialog.cpp" line="314"/>
        <source>恢复默认路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="307"/>
        <source>源路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="346"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="347"/>
        <source>英文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="351"/>
        <source>当前语言</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="378"/>
        <source>数据迁移</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="378"/>
        <source>语言切换完成，请重启软件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="422"/>
        <source>请选择压缩包</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="423"/>
        <source>选择源文件路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="426"/>
        <source>选择为空</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="432"/>
        <source>压缩包:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="433"/>
        <source>解压到</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="447"/>
        <source>解压开始...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="455"/>
        <source>解压完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="477"/>
        <location filename="../windows/settingdialog.cpp" line="499"/>
        <location filename="../windows/settingdialog.cpp" line="521"/>
        <location filename="../windows/settingdialog.cpp" line="543"/>
        <source>选择目标路径</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemTray</name>
    <message>
        <location filename="../windows/systemtray.cpp" line="29"/>
        <source>全版本更新和数据迁移工具</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemtray.cpp" line="30"/>
        <source>打开</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemtray.cpp" line="31"/>
        <source>退出</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SystemWidget</name>
    <message>
        <location filename="../windows/systemwidget.cpp" line="52"/>
        <source>联网方式</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="61"/>
        <source>IP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="70"/>
        <source>子网掩码</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="79"/>
        <source>网关</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="88"/>
        <source>DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="346"/>
        <location filename="../windows/systemwidget.cpp" line="351"/>
        <source>数据迁移-网络导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="346"/>
        <source>网络设置数据导入完成，下次开机时配置生效</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="351"/>
        <source>网络设置数据导入失败</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TableModel</name>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="164"/>
        <source>状态</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="167"/>
        <source>文件名</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="170"/>
        <source>修改日期</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="172"/>
        <source>大小(KB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="174"/>
        <source>存储路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="176"/>
        <source>当前状态</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../windows/titlewidget.cpp" line="151"/>
        <source>欢迎使用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="152"/>
        <source>我的电脑</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="153"/>
        <source>用户</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="154"/>
        <source>应用</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="155"/>
        <source>系统</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="156"/>
        <source>数据迁移</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserDetailWidget</name>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="90"/>
        <location filename="../windows/userdetailwidget.cpp" line="1313"/>
        <source>图片</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="91"/>
        <location filename="../windows/userdetailwidget.cpp" line="1331"/>
        <source>视频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="92"/>
        <source>音乐</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="93"/>
        <location filename="../windows/userdetailwidget.cpp" line="1325"/>
        <source>文档</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="204"/>
        <location filename="../windows/userdetailwidget.cpp" line="311"/>
        <location filename="../windows/userdetailwidget.cpp" line="418"/>
        <location filename="../windows/userdetailwidget.cpp" line="522"/>
        <source>检测到以下数据可以选择导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="229"/>
        <location filename="../windows/userdetailwidget.cpp" line="337"/>
        <location filename="../windows/userdetailwidget.cpp" line="442"/>
        <location filename="../windows/userdetailwidget.cpp" line="547"/>
        <source>全选</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="235"/>
        <location filename="../windows/userdetailwidget.cpp" line="343"/>
        <location filename="../windows/userdetailwidget.cpp" line="447"/>
        <location filename="../windows/userdetailwidget.cpp" line="553"/>
        <source>导入路径</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="781"/>
        <source>等待</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1177"/>
        <location filename="../windows/userdetailwidget.cpp" line="1183"/>
        <location filename="../windows/userdetailwidget.cpp" line="1189"/>
        <location filename="../windows/userdetailwidget.cpp" line="1209"/>
        <location filename="../windows/userdetailwidget.cpp" line="1215"/>
        <location filename="../windows/userdetailwidget.cpp" line="1221"/>
        <location filename="../windows/userdetailwidget.cpp" line="1242"/>
        <location filename="../windows/userdetailwidget.cpp" line="1248"/>
        <location filename="../windows/userdetailwidget.cpp" line="1254"/>
        <location filename="../windows/userdetailwidget.cpp" line="1275"/>
        <location filename="../windows/userdetailwidget.cpp" line="1281"/>
        <location filename="../windows/userdetailwidget.cpp" line="1287"/>
        <location filename="../windows/userdetailwidget.cpp" line="1338"/>
        <location filename="../windows/userdetailwidget.cpp" line="1343"/>
        <source>数据迁移</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1177"/>
        <source>尚未选择任何图像文件，请勾选要迁移的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1183"/>
        <location filename="../windows/userdetailwidget.cpp" line="1215"/>
        <location filename="../windows/userdetailwidget.cpp" line="1248"/>
        <location filename="../windows/userdetailwidget.cpp" line="1281"/>
        <source>尚未设置导入目录，请设置导入目录</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1189"/>
        <source>正在进行图片导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1209"/>
        <source>尚未选择任何视频文件，请勾选要迁移的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1221"/>
        <source>正在进行视频导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1242"/>
        <source>尚未选择任何音频文件，请勾选要迁移的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1254"/>
        <source>正在进行音频导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1275"/>
        <source>尚未选择任何文档，请勾选要迁移的文件</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1287"/>
        <source>正在进行文档导入</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1319"/>
        <source>音频</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1338"/>
        <source>数据导入成功</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1343"/>
        <source>数据导入失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1392"/>
        <source>导入完成</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1396"/>
        <source>导入失败</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1402"/>
        <source>正在导入</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>

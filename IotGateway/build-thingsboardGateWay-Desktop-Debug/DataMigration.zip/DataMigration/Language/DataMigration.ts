<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_AS" sourcelanguage="zh_CN">
<context>
    <name>AboutUsDialog</name>
    <message>
        <location filename="../windows/aboutus.cpp" line="17"/>
        <source>全版本更新和数据迁移工具-关于</source>
        <translation>SystemMigrationTool-About</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="105"/>
        <source>数据迁移-关于</source>
        <translation>SystemMigrationTool-About</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="106"/>
        <source>确定</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="107"/>
        <source>数据迁移</source>
        <translation>SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="108"/>
        <source>Windows系统数据迁移CDOS</source>
        <translation>Windows system data migration CDOS</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="109"/>
        <source>主程序版本: 1.0-11_Alpha</source>
        <translation>Main program version: 1.0-11_Alpha</translation>
    </message>
    <message>
        <source>主程序版本: 1.0-9_Alpha</source>
        <translation type="vanished">Main program version: 1.0-9_Alpha</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="110"/>
        <source>作者</source>
        <translation>Author</translation>
    </message>
    <message>
        <location filename="../windows/aboutus.cpp" line="111"/>
        <source>Copyright(c) nfschina.com Inc. All Rights Reserved</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>AppDetailWidget</name>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="81"/>
        <source>邮件</source>
        <translation>Email</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="82"/>
        <source>收藏夹</source>
        <translation>Bookmarks</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="202"/>
        <source>邮件客户端数据</source>
        <translation>Mail client data</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="217"/>
        <location filename="../windows/appdetailwidget.cpp" line="292"/>
        <source>检测到以下数据可以选择导入:</source>
        <translation>The following data is detected and imports can be selected:</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="245"/>
        <location filename="../windows/appdetailwidget.cpp" line="317"/>
        <source>全选</source>
        <translation>Select all</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="251"/>
        <location filename="../windows/appdetailwidget.cpp" line="325"/>
        <source>源路径</source>
        <translation>From path</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="346"/>
        <source>IE浏览器收藏夹</source>
        <translation>IE browser favorites</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="377"/>
        <source>火狐浏览器收藏夹</source>
        <translation>Firefox favorites</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="408"/>
        <source>谷歌浏览器收藏夹</source>
        <translation>Google browser favorites</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="660"/>
        <source>添加PST文件</source>
        <translation>Add PST file</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="677"/>
        <source>添加EML文件</source>
        <translation>Add EML file</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="804"/>
        <location filename="../windows/appdetailwidget.cpp" line="814"/>
        <location filename="../windows/appdetailwidget.cpp" line="824"/>
        <source>添加浏览器收藏夹文件</source>
        <translation>Add browser favorites file</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="988"/>
        <location filename="../windows/appdetailwidget.cpp" line="1044"/>
        <location filename="../windows/appdetailwidget.cpp" line="1052"/>
        <location filename="../windows/appdetailwidget.cpp" line="1076"/>
        <location filename="../windows/appdetailwidget.cpp" line="1123"/>
        <location filename="../windows/appdetailwidget.cpp" line="1129"/>
        <location filename="../windows/appdetailwidget.cpp" line="1136"/>
        <location filename="../windows/appdetailwidget.cpp" line="1144"/>
        <location filename="../windows/appdetailwidget.cpp" line="1203"/>
        <location filename="../windows/appdetailwidget.cpp" line="1210"/>
        <location filename="../windows/appdetailwidget.cpp" line="1239"/>
        <location filename="../windows/appdetailwidget.cpp" line="1248"/>
        <source>数据迁移</source>
        <translation>SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="988"/>
        <source>尚未选择浏览器收藏夹文件</source>
        <translation>The browser favorites file has not been selected</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1044"/>
        <source>未检测到浏览器客户端</source>
        <translation>Browser client was not detected</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1052"/>
        <source>收藏夹数据导入完成</source>
        <translation>The favorites data import is complete</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1061"/>
        <source>Firefox失败</source>
        <translation>Firefox fail</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1067"/>
        <source>、CDOSBrowser2失败</source>
        <translation>、CDOSBrowser2 fail</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1072"/>
        <source>部分数据失败</source>
        <translation>Partial data failure</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1076"/>
        <source>收藏夹数据导入</source>
        <translation>Favorites data import</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1123"/>
        <source>尚未选择邮件文件</source>
        <translation>The mail file has not been selected</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1129"/>
        <source>未检测到邮件客户端</source>
        <translation>The mail client was not detected</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1136"/>
        <source>初始化失败</source>
        <translation>initialization failed</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1144"/>
        <location filename="../windows/appdetailwidget.cpp" line="1248"/>
        <source>用户名检测失败</source>
        <translation>User name test failed</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1203"/>
        <source>邮件数据导入失败:</source>
        <translation>Mail data import failed:</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1210"/>
        <source>邮件数据导入成功</source>
        <translation>Mail data import successfully</translation>
    </message>
    <message>
        <location filename="../windows/appdetailwidget.cpp" line="1239"/>
        <source>应用数据导入初始化失败,获取本地路径错误，请确认邮件客户端和浏览器客户端的本地文件是否存在。</source>
        <translation>Failed to apply data import initialization. Get local path error. Verify that the local file of the mail client and browser client exists.</translation>
    </message>
</context>
<context>
    <name>ComputerWidget</name>
    <message>
        <location filename="../windows/computerwidget.cpp" line="104"/>
        <source>未识别的系统</source>
        <translation>Unrecognized system</translation>
    </message>
</context>
<context>
    <name>CustomMessageBox</name>
    <message>
        <location filename="../windows/messagebox.cpp" line="12"/>
        <source>全版本更新和数据迁移工具-提示</source>
        <translation>SystemMigrationTool-Tips</translation>
    </message>
    <message>
        <location filename="../windows/messagebox.cpp" line="65"/>
        <source>确定</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../windows/messagebox.cpp" line="66"/>
        <source>取消</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>DataMigration</name>
    <message>
        <location filename="../windows/datamigration.cpp" line="20"/>
        <source>全版本更新和数据迁移工具</source>
        <translation>SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/datamigration.cpp" line="291"/>
        <location filename="../windows/datamigration.cpp" line="316"/>
        <source>数据迁移</source>
        <translation>SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/datamigration.cpp" line="291"/>
        <source>请设置源文件路径</source>
        <translation>Please set the source file path</translation>
    </message>
    <message>
        <location filename="../windows/datamigration.cpp" line="316"/>
        <source>一键导入完成</source>
        <translation>One click import complete</translation>
    </message>
</context>
<context>
    <name>DirectoryDlg</name>
    <message>
        <location filename="../windows/directorydlg.cpp" line="37"/>
        <source>源路径列表</source>
        <translation>Source path list</translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="48"/>
        <source>增加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="49"/>
        <source>移除</source>
        <translation>Remove</translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="50"/>
        <source>返回</source>
        <translation>Back</translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="57"/>
        <source>数据迁移-源路径设置</source>
        <translation>SystemMigration-Source path setting</translation>
    </message>
    <message>
        <location filename="../windows/directorydlg.cpp" line="178"/>
        <source>选择源路径</source>
        <translation>Select source path</translation>
    </message>
</context>
<context>
    <name>EmailUserNameSelect</name>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="7"/>
        <source>全版本更新和数据迁移工具-用户名选择</source>
        <translation>SystemMigrationTool-user name selection</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="52"/>
        <source>用户名</source>
        <translation>UserName</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="53"/>
        <source>密码</source>
        <translation>PassWord</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="100"/>
        <source>数据迁移-邮件</source>
        <translation>SystemMigrationTool-Mail</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="101"/>
        <source>确定</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="102"/>
        <source>取消</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="103"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="104"/>
        <source>确定添加</source>
        <translation>Confirm add</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="121"/>
        <source>*******</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="157"/>
        <source>请在此输入用户名</source>
        <translation>Enter user name here</translation>
    </message>
    <message>
        <location filename="../windows/emailusernameselect.cpp" line="158"/>
        <source>请在此输入密码</source>
        <translation>Please enter your password here</translation>
    </message>
</context>
<context>
    <name>FileDialog</name>
    <message>
        <location filename="../windows/filedialog.cpp" line="19"/>
        <location filename="../windows/filedialog.cpp" line="62"/>
        <source>取消(&amp;C)</source>
        <translation>Cancel(&amp;C)</translation>
    </message>
    <message>
        <location filename="../windows/filedialog.cpp" line="21"/>
        <location filename="../windows/filedialog.cpp" line="64"/>
        <source>打开(&amp;O)</source>
        <translation>Open(&amp;O)</translation>
    </message>
    <message>
        <location filename="../windows/filedialog.cpp" line="26"/>
        <location filename="../windows/filedialog.cpp" line="69"/>
        <source>查看：</source>
        <translation>Look up:</translation>
    </message>
    <message>
        <location filename="../windows/filedialog.cpp" line="31"/>
        <source>文件名称：</source>
        <translation>File Name:</translation>
    </message>
    <message>
        <location filename="../windows/filedialog.cpp" line="36"/>
        <location filename="../windows/filedialog.cpp" line="79"/>
        <source>文件类型：</source>
        <translation>File Type:</translation>
    </message>
    <message>
        <location filename="../windows/filedialog.cpp" line="74"/>
        <source>目录：</source>
        <translation>Directory:</translation>
    </message>
</context>
<context>
    <name>MainMenu</name>
    <message>
        <location filename="../windows/mainmenu.cpp" line="26"/>
        <source>设置</source>
        <translation>Set up</translation>
    </message>
    <message>
        <location filename="../windows/mainmenu.cpp" line="27"/>
        <source>关于</source>
        <translation>about</translation>
    </message>
</context>
<context>
    <name>NetworkWidget</name>
    <message>
        <location filename="../windows/networkwidget.cpp" line="24"/>
        <source>全版本更新和数据迁移工具-网络传输</source>
        <translation>SystemMigrationTool-network transport</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="35"/>
        <source>网络传输服务</source>
        <translation>Network transmission service</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="46"/>
        <source>用户名</source>
        <translation>UserName</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="47"/>
        <source>密码</source>
        <translation>PassWord</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="48"/>
        <source>端口</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="49"/>
        <source>路径</source>
        <translation>Path</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="60"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="65"/>
        <source>重启网络服务器</source>
        <translation>Restart</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="75"/>
        <source>只读</source>
        <translation>ReadOnly</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="229"/>
        <source>监听: </source>
        <translation>Listen:</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="233"/>
        <source>未监听</source>
        <translation>Not listening</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="251"/>
        <location filename="../windows/networkwidget.cpp" line="258"/>
        <source>网络传输</source>
        <translation>network transmission</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="251"/>
        <source>网络参数设置错误，请重新设置</source>
        <translation>Network parameter setting error, please reset</translation>
    </message>
    <message>
        <location filename="../windows/networkwidget.cpp" line="258"/>
        <source>网络服务器重启成功</source>
        <translation>Successful restart of network server</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="269"/>
        <source>01月</source>
        <translation>Jan</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="273"/>
        <source>02月</source>
        <translation>Feb</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="277"/>
        <source>03月</source>
        <translation>Mar</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="281"/>
        <source>04月</source>
        <translation>Apr</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="285"/>
        <source>05月</source>
        <translation>May</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="289"/>
        <source>06月</source>
        <translation>Jun</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="293"/>
        <source>07月</source>
        <translation>Jul</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="297"/>
        <source>08月</source>
        <translation>Aug</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="301"/>
        <source>09月</source>
        <translation>Sep</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="305"/>
        <source>10月</source>
        <translation>Oct</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="309"/>
        <source>11月</source>
        <translation>Nov</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="313"/>
        <source>12月</source>
        <translation>Dec</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="315"/>
        <source>年</source>
        <translation>Year</translation>
    </message>
    <message>
        <location filename="../functions/importtocdosmail.cpp" line="315"/>
        <source>日</source>
        <translation>Day</translation>
    </message>
</context>
<context>
    <name>QRoundProgressBar</name>
    <message>
        <location filename="../windows/QRoundProgressBar.cpp" line="38"/>
        <source>幼圆</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../windows/settingdialog.cpp" line="27"/>
        <source>全版本更新和数据迁移工具-设置</source>
        <translation>SystemMigrationTool-Set up</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="46"/>
        <source>源路径设置</source>
        <translation>Source path</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="47"/>
        <source>目标路径设置</source>
        <translation>Target path</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="48"/>
        <source>语言设置</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="176"/>
        <source>数据迁移-设置</source>
        <translation>SystemMigrationTool-Set up</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="177"/>
        <source>返回</source>
        <translation>Back</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="178"/>
        <source>确定</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="188"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="189"/>
        <source>音乐</source>
        <translation>Music</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="190"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="191"/>
        <source>文档</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="231"/>
        <location filename="../windows/settingdialog.cpp" line="314"/>
        <source>恢复默认路径</source>
        <translation>Default</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="307"/>
        <source>源路径</source>
        <translation>From path</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="346"/>
        <source>中文</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="347"/>
        <source>英文</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="351"/>
        <source>当前语言</source>
        <translation>Current language</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="378"/>
        <source>数据迁移</source>
        <translation>SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="378"/>
        <source>语言切换完成，请重启软件</source>
        <translation>The language switch is complete. Please restart the software</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="422"/>
        <source>请选择压缩包</source>
        <translation>请选择压缩包</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="424"/>
        <source>选择源文件路径</source>
        <translation>Select the source file path</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="427"/>
        <source>选择为空</source>
        <translation>Select empty</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="433"/>
        <source>压缩包:</source>
        <translation>Compression pack:</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="434"/>
        <source>解压到</source>
        <translation>Unzip to</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="448"/>
        <source>解压开始...</source>
        <translation>Decompression begins...</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="456"/>
        <source>解压完成</source>
        <translation>Decompression complete</translation>
    </message>
    <message>
        <location filename="../windows/settingdialog.cpp" line="479"/>
        <location filename="../windows/settingdialog.cpp" line="502"/>
        <location filename="../windows/settingdialog.cpp" line="525"/>
        <location filename="../windows/settingdialog.cpp" line="548"/>
        <source>选择目标路径</source>
        <translation>Select destination path</translation>
    </message>
</context>
<context>
    <name>SystemTray</name>
    <message>
        <source>全版本更新和数据迁移工具</source>
        <translation type="vanished">SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/systemtray.cpp" line="30"/>
        <source>打开</source>
        <translation>Open</translation>
    </message>
    <message>
        <location filename="../windows/systemtray.cpp" line="31"/>
        <source>退出</source>
        <translation>Quit</translation>
    </message>
</context>
<context>
    <name>SystemWidget</name>
    <message>
        <location filename="../windows/systemwidget.cpp" line="52"/>
        <source>联网方式</source>
        <translation>Networking mode</translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="61"/>
        <source>IP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="70"/>
        <source>子网掩码</source>
        <translation>Subnet mask</translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="79"/>
        <source>网关</source>
        <translation>Gateway</translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="88"/>
        <source>DNS</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="346"/>
        <location filename="../windows/systemwidget.cpp" line="351"/>
        <source>数据迁移-网络导入</source>
        <translation>SystemMigrationTool-Network import</translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="346"/>
        <source>网络设置数据导入完成，下次开机时配置生效</source>
        <translation>The network settings were successful.Restart the computer configuration and enter into force</translation>
    </message>
    <message>
        <location filename="../windows/systemwidget.cpp" line="351"/>
        <source>网络设置数据导入失败</source>
        <translation>Network settings failed to import data</translation>
    </message>
</context>
<context>
    <name>TableModel</name>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="164"/>
        <source>状态</source>
        <translation>State</translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="167"/>
        <source>文件名</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="170"/>
        <source>修改日期</source>
        <translation>Date Modified</translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="172"/>
        <source>大小(KB)</source>
        <translation>Size(KB)</translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="174"/>
        <source>存储路径</source>
        <translation>Path</translation>
    </message>
    <message>
        <location filename="../windows/userdatamodel.cpp" line="176"/>
        <source>当前状态</source>
        <translation>Current State</translation>
    </message>
</context>
<context>
    <name>TitleWidget</name>
    <message>
        <location filename="../windows/titlewidget.cpp" line="151"/>
        <source>欢迎使用</source>
        <translation>Welcome to use</translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="152"/>
        <source>我的电脑</source>
        <translation>My computer</translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="153"/>
        <source>用户</source>
        <translation>User</translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="154"/>
        <source>应用</source>
        <translation>Application</translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="155"/>
        <source>系统</source>
        <translation>System</translation>
    </message>
    <message>
        <location filename="../windows/titlewidget.cpp" line="156"/>
        <source>数据迁移</source>
        <translation>SystemMigrationTool</translation>
    </message>
</context>
<context>
    <name>UserDetailWidget</name>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="90"/>
        <location filename="../windows/userdetailwidget.cpp" line="1363"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="91"/>
        <location filename="../windows/userdetailwidget.cpp" line="1381"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="92"/>
        <source>音乐</source>
        <translation>Music</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="93"/>
        <location filename="../windows/userdetailwidget.cpp" line="1375"/>
        <source>文档</source>
        <translation>Document</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="204"/>
        <location filename="../windows/userdetailwidget.cpp" line="312"/>
        <location filename="../windows/userdetailwidget.cpp" line="420"/>
        <location filename="../windows/userdetailwidget.cpp" line="525"/>
        <source>检测到以下数据可以选择导入</source>
        <translation>The following data is detected and imports can be selected</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="229"/>
        <location filename="../windows/userdetailwidget.cpp" line="338"/>
        <location filename="../windows/userdetailwidget.cpp" line="444"/>
        <location filename="../windows/userdetailwidget.cpp" line="550"/>
        <source>全选</source>
        <translation>Select all</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="235"/>
        <location filename="../windows/userdetailwidget.cpp" line="344"/>
        <location filename="../windows/userdetailwidget.cpp" line="449"/>
        <location filename="../windows/userdetailwidget.cpp" line="556"/>
        <source>导入路径</source>
        <translation>import path</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="785"/>
        <source>等待</source>
        <translation>Wait</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1227"/>
        <location filename="../windows/userdetailwidget.cpp" line="1233"/>
        <location filename="../windows/userdetailwidget.cpp" line="1239"/>
        <location filename="../windows/userdetailwidget.cpp" line="1259"/>
        <location filename="../windows/userdetailwidget.cpp" line="1265"/>
        <location filename="../windows/userdetailwidget.cpp" line="1271"/>
        <location filename="../windows/userdetailwidget.cpp" line="1292"/>
        <location filename="../windows/userdetailwidget.cpp" line="1298"/>
        <location filename="../windows/userdetailwidget.cpp" line="1304"/>
        <location filename="../windows/userdetailwidget.cpp" line="1325"/>
        <location filename="../windows/userdetailwidget.cpp" line="1331"/>
        <location filename="../windows/userdetailwidget.cpp" line="1337"/>
        <location filename="../windows/userdetailwidget.cpp" line="1388"/>
        <location filename="../windows/userdetailwidget.cpp" line="1393"/>
        <source>数据迁移</source>
        <translation>SystemMigrationTool</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1227"/>
        <source>尚未选择任何图像文件，请勾选要迁移的文件</source>
        <translation>Any image files have not been selected. Please check the files you want to migrate</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1233"/>
        <location filename="../windows/userdetailwidget.cpp" line="1265"/>
        <location filename="../windows/userdetailwidget.cpp" line="1298"/>
        <location filename="../windows/userdetailwidget.cpp" line="1331"/>
        <source>尚未设置导入目录，请设置导入目录</source>
        <translation>The import directory has not been set. Please set the Import Directory</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1239"/>
        <source>正在进行图片导入</source>
        <translation>Picture import in progress</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1259"/>
        <source>尚未选择任何视频文件，请勾选要迁移的文件</source>
        <translation>No video files have been selected. Please check the files you want to migrate</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1271"/>
        <source>正在进行视频导入</source>
        <translation>Video import in progress</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1292"/>
        <source>尚未选择任何音频文件，请勾选要迁移的文件</source>
        <translation>No audio files have been selected. Please check the files you want to migrate</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1304"/>
        <source>正在进行音频导入</source>
        <translation>Audio import in progress</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1325"/>
        <source>尚未选择任何文档，请勾选要迁移的文件</source>
        <translation>Any document has not been selected. Please check the file you want to migrate</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1337"/>
        <source>正在进行文档导入</source>
        <translation>Document import in progress</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1369"/>
        <source>音频</source>
        <translation>Music</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1388"/>
        <source>数据导入成功</source>
        <translation>Data import successfully</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1393"/>
        <source>数据导入失败</source>
        <translation>Data import failed</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1442"/>
        <source>导入完成</source>
        <translation>Import complete</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1446"/>
        <source>导入失败</source>
        <translation>Import failure</translation>
    </message>
    <message>
        <location filename="../windows/userdetailwidget.cpp" line="1452"/>
        <source>正在导入</source>
        <translation>Importing</translation>
    </message>
</context>
</TS>

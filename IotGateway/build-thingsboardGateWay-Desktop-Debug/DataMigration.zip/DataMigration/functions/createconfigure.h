#ifndef CREATECONFIGURE
#define CREATECONFIGURE
/*该文件依赖windows平台*/
#include "functions/common.h"
#include <QString>
#define CONFIG_INI 1
#define CONFIG_SET 0
class ConfigureDirTool
{
public:
    ConfigureDirTool(QString organName, QString appName );
    ~ConfigureDirTool();
    void createIniFile(int s);
    bool makeDstDir();
    bool check();
private:
    QString organization;
    QString application;
};

#endif // CREATECONFIGURE


#include "exportfoxmail.h"

ExportFoxmail::ExportFoxmail()
{
}

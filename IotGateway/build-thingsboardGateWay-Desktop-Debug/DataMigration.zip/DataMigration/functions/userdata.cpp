#include "userdata.h"

UserData::UserData(QObject *parent) :
    QObject(parent)
{
}

void UserData::CopyFileToPath()
{
    QStringList name;
    QString singleMusFile;
    int i=0;
    int cou=CopyList.count();
    emit UserData_progress_onekey_num(cou,i);
    foreach (singleMusFile, CopyList)
    {
        QFileInfo *info=new QFileInfo(singleMusFile);
        QString path=CopytoDst[CopyList.at(i)];
        path.append("/"+info->fileName());
        emit UserData_currentCopy_name(current_index,info->fileName());
        int f=0;
        if(!Util::copyFileTo(singleMusFile, path, true))
        {
            name.append(singleMusFile);
            f=1;
        }
        i++;
        emit UserData_Copyover_name(current_index,info->fileName(),f);
        emit UserData_progress_num(current_index,i);
        emit UserData_progress_onekey_num(cou,i);
        delete info;
    }
    emit UserData_progress_onekey_num(cou,cou);
    emit UserDataCopy_Error_name(current_index,name);
}

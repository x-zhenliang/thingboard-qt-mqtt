#ifndef IMPORTTOFIREFOX_H
#define IMPORTTOFIREFOX_H

#include "functions/common.h"
#include <QString>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <stdlib.h>
#include <QFile>
#include <QMap>
#include <QDateTime>
#include <QThread>
#include <QProcess>
#include "tools/utils.h"

class ImportToFirefox
{
public:
    ImportToFirefox();
    int check_firefox(void);
    int ImportFirefox_init(void);
    int importFirefox(void);
    void SetImportBuf(QMap<int,Bookmarks> &bbuf,QList<int> pbuf)
    {
        bookmarks=bbuf;
        places_id=pbuf;
    }
private:
    QString localsqlite_path;
    int firefoxflag=0;
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
};

#endif // IMPORTTOFIREFOX_H

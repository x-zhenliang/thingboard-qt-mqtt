#ifndef EXPORTOUTLOOK_H
#define EXPORTOUTLOOK_H
#include <QStringList>
#include <QProcess>
#include <QDebug>
#include "tools/utils.h"
class ExportOutlook
{
public:
    ExportOutlook();
    int PstToEml(QString pstpath,QString emlpath);
};

#endif // EXPORTOUTLOOK_H

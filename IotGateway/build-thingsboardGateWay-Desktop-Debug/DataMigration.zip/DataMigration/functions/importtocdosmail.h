#ifndef IMPORTTOCDOSMAIL_H
#define IMPORTTOCDOSMAIL_H

#include <QThread>
#include <QFileInfoList>
#include <QDir>
#include <QDebug>
#include <QProcess>
#include "tools/utils.h"
#include <QDateTime>
#include <QSqlDatabase>
#include <QObject>
#include <QSqlQuery>
#include <QTextCodec>
#include "functions/common.h"
#include "tools/utils.h"
#define ENCRYPT 0
#define DECRYPT 1
class ImportToCDOSMail
{
public:
    ImportToCDOSMail();
    int check_CDOSMail(void);
    int ImportCDOSMail_init(void);
    int ImportCDOSMail(QString path);
    int check_CDOSMail_username(QStringList &namelist);
    int EmailMsg_AddUserName(QStringList name, QStringList pass);
    QString EmailMsg_SelectUserName;
private:
    int importeml(QString htmldirpath,QString emlpath);
    int emltohtml(QString emldirpath,QString htmldirpath);
    int psttoeml(QString pstpath,QString emlpath);
    int Email_AES_Crypto(QString name,QString &pass,QString &passaes,int flag);

private:
    int CDOSMail_flag;
    QString CDOSMail_path;
};

#endif // IMPORTTOCDOSMAIL_H

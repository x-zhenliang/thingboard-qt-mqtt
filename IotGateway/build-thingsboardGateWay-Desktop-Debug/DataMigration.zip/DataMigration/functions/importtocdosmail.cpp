#include "importtocdosmail.h"

ImportToCDOSMail::ImportToCDOSMail()
{
}

int ImportToCDOSMail::check_CDOSMail()
{
    CDOSMail_flag=1;
    QString envpath=QString(getenv("PATH"));
    if(envpath=="")
    {
        return -2;
    }
    int i=0;
    while(1)
    {
        QString path=envpath.section(":",i,i);
        i++;
        if(path=="")
            break;
        QDir *fd=new QDir(path);
        QFileInfoList infolist=fd->entryInfoList();
        for(int j=0;j<infolist.count();j++)
        {
            if(infolist.at(j).fileName()=="cdos-mailclient")
            {
                CDOSMail_flag=1;
                return 0;
            }
        }
    }
    return -1;
}

int ImportToCDOSMail::ImportCDOSMail_init()
{
    CDOSMail_path.clear();
    CDOSMail_path=QString(getenv("HOME"));
    if(CDOSMail_path==NULL)
    {
        qDebug()<<"Thunderbird_init get HOME";
        return -1;
    }
    CDOSMail_path.append("/.config/CDOSMail");
    QDir d(CDOSMail_path);
    if(!d.exists())
    {
        CDOSMail_path.remove("/.config/CDOSMail");
        CDOSMail_path.append("/.config/cdos-mailclient2");
        d.setPath(CDOSMail_path);
        if(!d.exists())
            return -2;
    }
    return 0;
}

int ImportToCDOSMail::ImportCDOSMail(QString path)
{
    QFileInfo info(path);
    if(info.suffix().contains("eml"))
    {
        QString p=info.path()+"/"+info.completeBaseName();
        QDir d(p);
        if(d.exists())
        {
            d.rmdir(p);
        }
        d.mkdir(p);
        if(emltohtml(path,p)<0)
        {
            qDebug()<<path<<"eml to html error";
            return -1;
        }
        if(importeml(p,path))
        {
            qDebug()<<path<<"importeml error";
            return -1;
        }
        return 0;
    }
    else if(info.suffix().contains("pst"))
    {
        QFileInfo info(path);
        QString p=info.path()+"/"+info.completeBaseName();
        QDir d(p);
        if(d.exists())
        {
            if(Util::DelDir(p))
            {
                qDebug()<<"rmdir"<<p<<"error";
            }
        }
        d.mkdir(p);
        if(psttoeml(path,p)<0)
        {
            qDebug()<<path<<"pst to eml error";
            return -1;
        }
        p+=("/"+info.completeBaseName());
        d.setPath(p);







        qDebug()<<Util::findDirPath("收件箱",p);







        QFileInfoList list=d.entryInfoList();
        QStringList emldirlist;
        for(int i=0;i<list.count();i++)
        {
            if(list.at(i).fileName()=="收件箱")
            {
                QFileInfoList list=Util::convenienceDir(p+"/收件箱");
                int listc=list.count();
                for(int i=0;i<listc;i++)
                {
                    emldirlist.append(list.at(i).filePath());
                }
                break;
            }
        }
        for(int i=0;i<emldirlist.count();i++)
        {
            QFileInfo info(emldirlist.at(i));
            QString p=info.path()+"/"+info.completeBaseName();
            QDir d(p);
            if(d.exists())
            {
                d.rmdir(p);
            }
            d.mkdir(p);
            if(emltohtml(emldirlist.at(i),p)<0)
            {
                qDebug()<<path<<"pst eml to html error";
                return -1;
            }
            if(importeml(p,emldirlist.at(i)))
            {
                qDebug()<<path<<"pst importeml error";
                return -1;
            }
        }
        return 0;
    }
    return -1;
}
int ImportToCDOSMail::importeml(QString htmldirpath,QString emlpath)
{
    QString importUserpath=CDOSMail_path+"/"+EmailMsg_SelectUserName;
    QString importFloderpath=importUserpath+"/DataMigration"+QDateTime::currentDateTime().toString("yyyyMMdd");
    QDir d(importFloderpath);
    if(!d.exists())
    {
        d.mkpath(importFloderpath);
    }
    QFileInfo fi(emlpath);
    QFile::copy(emlpath,importFloderpath+"/"+fi.fileName());
    QSqlDatabase localdatabase;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
        localdatabase= QSqlDatabase::database("qt_sql_default_connection");
    else
        localdatabase = QSqlDatabase::addDatabase("QSQLITE");
    localdatabase.setDatabaseName(importUserpath+"/mail.db");
    if(!localdatabase.open())
    {
        qDebug()<<"数据库打开失败";
        return -1;
    }
    QSqlQuery query;
    //检查添加新文件夹
    QString sqlstr="select name from folders where name='"+d.dirName()+"';";
    query.prepare(sqlstr);
    if(!query.exec())
    {
        qDebug()<<"importToCDOSMail exec"<<sqlstr<<"error";
        return -1;
    }
    int f=0;
    while(query.next())
    {
        f=1;
    }
    if(!f)
    {
        sqlstr="insert into folders(name) values('"+d.dirName()+"')";
        query.prepare(sqlstr);
        if(!query.exec())
        {
            qDebug()<<"importToCDOSMail exec"<<sqlstr<<"error";
            return -1;
        }
    }
    //获取mail表格uid
    sqlstr="select uid from mail where uid LIKE 'DataMigrationImport%';";
    int importid=0;
    query.prepare(sqlstr);
    if(!query.exec())
    {
        qDebug()<<"importToCDOSMail exec"<<sqlstr<<"error";
        return -1;
    }
    while(query.next())
    {
        QString s=query.value(0).toString();
        int sl=s.size();
        int id=s.right(sl-19).toInt();
        if(id>importid)
        {
            importid=id;
        }
    }
    importid++;
    //向mail添加数据
    sqlstr="insert into mail(uid,subject,date,mailFrom,mailTo,mailCc,mailBcc,hasAttach,attachments,isRead,size,isStar,category,path) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
    query.prepare(sqlstr);
    QString uid="DataMigrationImport"+QString::number(importid);
    query.bindValue(0,uid);//uid
    QFile readmefd(htmldirpath+"/readme");
    if(!readmefd.open(QIODevice::ReadOnly))
    {
        qDebug()<<"importToCDOSMail open"<<htmldirpath+"/readme"<<"open error";
        return -1;
    }
    int strlist_index=0;
    QTextStream stream(&readmefd);
    QStringList strlist=stream.readAll().split('\n');
    if(!strlist.at(strlist_index).contains(","))
    {
        uid=strlist.at(strlist_index).section("$$$:",1,1);
    }
    else
    {
        uid=strlist.at(strlist_index).section(",",1,1);
    }
    QChar uidc=uid.at(0);
    if(uidc!=QChar(' '))
    {
        QString b=' '+uid;
        uid=b;
    }
    int fu=0;
    QString uidb=" ";
    for(int i=0;i<uid.count();i++)
    {
        QChar buf=uid.at(i);
        if(buf==QChar(' ')&&fu==0)
        {
            continue;
        }
        fu=1;
        uidb.append(buf);
    }
    QString da=uidb.section(" ",1,1);
    QString m=uidb.section(" ",2,2);
    QString y=uidb.section(" ",3,3);
    QString h=uidb.section(" ",4,4);
    if(m.contains("Jan",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("01月");
    }
    else if(m.contains("Feb",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("02月");
    }
    else if(m.contains("Mar",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("03月");
    }
    else if(m.contains("Apr",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("04月");
    }
    else if(m.contains("May",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("05月");
    }
    else if(m.contains("Jun",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("06月");
    }
    else if(m.contains("Jul",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("07月");
    }
    else if(m.contains("Aug",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("08月");
    }
    else if(m.contains("Sep",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("09月");
    }
    else if(m.contains("Oct",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("10月");
    }
    else if(m.contains("Nov",Qt::CaseSensitivity(false)))
    {
        m=QObject::tr("11月");
    }
    else
    {
        m=QObject::tr("12月");
    }
    uid=y+QObject::tr("年")+m+da+QObject::tr("日")+" "+h;
    query.bindValue(2,uid);//date
    strlist_index++;
    QString al=strlist.at(strlist_index).section("$$$:",1,1);
    if(al.contains("<"))
    {
        al.replace("\"","");
        QString n=al.section(" ",0,0);
        QString address=al.section(" ",1,1);
        uid="[{\"address\":\""+address+"\",\"name\":\""+n+"\"}]";
    }
    else
    {
        uid="[{\"address\":\""+al+"\",\"name\":\"\"}]";
    }
    query.bindValue(3,uid);//mailFrom

    strlist_index++;
    QStringList alist;
    alist.append(strlist.at(strlist_index).section("$$$:",1,1));
    for(int i=strlist_index+1;i<strlist.count();i++)
    {
        if(strlist.at(i).contains("$$$:"))
        {
            break;
        }
        else
        {
            alist.append(strlist.at(i));
        }
        strlist_index++;
    }

    int Tocount=alist.count();
    uid="[";
    for(int i=0;i<Tocount;i++)
    {
        int lineTocount=alist.at(i).contains("@");
        for(int j=0;j<lineTocount;j++)
        {
            QString buf=alist.at(i).section(",",j,j);
            if(buf.contains("<"))
            {//里面有昵称
                buf.replace(QString('\t'),QString(""));
                buf.replace(QString(" "),QString(""));
                buf.replace(QString("\""),QString(""));
                QString n=buf.section("<",0,0);
                QString add=buf.section("<",1,1);
                int al=add.size();
                add=buf.section("<",1,1).left(al-1);
                uid.append("{\"address\":\"");
                uid.append(add);
                uid.append("\",\"name\":\"");
                uid.append(n);
                if(j==lineTocount-1&&i==Tocount-1)
                {
                    uid.append("\"}");
                }
                else
                {
                    uid.append("\"},");
                }
            }
            else
            {//没有昵称
                buf.replace(QString('\t'),QString(""));
                buf.replace(QString(" "),QString(""));
                buf.replace(QString("\""),QString(""));
                QString add=buf;
                uid.append("{\"address\":\"");
                uid.append(add);
                uid.append("\",\"name\":\"");
                if(j==lineTocount-1&&i==Tocount-1)
                {
                    uid.append("\"}");
                }
                else
                {
                    uid.append("\"},");
                }
            }
        }
    }
    uid.append("]");
    query.bindValue(4,uid);//mailTo
    strlist_index++;
    alist.clear();
    alist.append(strlist.at(strlist_index).section("$$$:",1,1));
    for(int i=strlist_index+1;i<strlist.count();i++)
    {
        if(strlist.at(i).contains("$$$:"))
        {
            break;
        }
        else
        {
            alist.append(strlist.at(i));
        }
        strlist_index++;
    }
    int Cccount=alist.count();
    uid="[";
    for(int i=0;i<Cccount;i++)
    {
        int lineTocount=alist.at(i).contains("@");
        for(int j=0;j<lineTocount;j++)
        {
            QString buf=alist.at(i).section(",",j,j);
            if(buf.contains("<"))
            {//里面有昵称
                buf.replace(QString('\t'),QString(""));
                buf.replace(QString(" "),QString(""));
                buf.replace(QString("\""),QString(""));
                QString n=buf.section("<",0,0);
                QString add=buf.section("<",1,1);
                int al=add.size();
                add=buf.section("<",1,1).left(al-1);
                uid.append("{\"address\":\"");
                uid.append(add);
                uid.append("\",\"name\":\"");
                uid.append(n);
                if(j==lineTocount-1&&i==Cccount-1)
                {
                    uid.append("\"}");
                }
                else
                {
                    uid.append("\"},");
                }
            }
            else
            {//没有昵称
                buf.replace(QString('\t'),QString(""));
                buf.replace(QString(" "),QString(""));
                buf.replace(QString("\""),QString(""));
                QString add=buf;
                uid.append("{\"address\":\"");
                uid.append(add);
                uid.append("\",\"name\":\"");
                if(j==lineTocount-1&&i==Cccount-1)
                {
                    uid.append("\"}");
                }
                else
                {
                    uid.append("\"},");
                }
            }
        }
    }
    uid.append("]");
    query.bindValue(5,uid);//mailCc
    uid="[]";
    query.bindValue(6,uid);//mailBcc
    strlist_index++;
    uid=strlist.at(strlist_index).section("$$$:",1,1);
    query.bindValue(1,uid);//subject
    uid="1";
    query.bindValue(7,uid);//hasAttach
    uid="0";
    query.bindValue(9,uid);//isRead
    uid="0";
    query.bindValue(10,uid);//size
    uid="0";
    query.bindValue(11,uid);//isStar
    uid=d.dirName();
    query.bindValue(12,uid);//category
    QFileInfo e(emlpath);
    uid=importFloderpath+"/"+e.fileName();
    query.bindValue(13,uid);//path

    QStringList attachmentscount;
    for(int i=strlist_index+1;i<strlist.count();i++)
    {
        if(strlist.at(i).contains("---START---"))
        {
            if(i+5<strlist.count())
            {
                if(!strlist.at(i+5).contains("NONE"))
                {
                    attachmentscount.append(QString::number(i));
                }
            }
        }
    }
    uid="[";
    for(int i=0;i<attachmentscount.count();i++)
    {
        uid.append("{");
        uid.append("\"filename\":\"");
        QString fn=strlist.at(attachmentscount.at(i).toInt()+1).section("$$$:",1,1);
        QFileInfo info(htmldirpath+"/"+fn);
        qint64 size=info.size();
        QString d=strlist.at(attachmentscount.at(i).toInt()+5).section("$$$:",1,1);
        QString dis=d.section(";",0,0);
        uid.append(fn);
        uid.append("\",\"size\":");
        uid.append(QString::number(size));
        uid.append(",\"download\":true,\"contentDisposition\":\"");
        uid.append(dis);
        uid.append("\"");
        if(i==attachmentscount.count()-1)
        {
            uid.append("}");
        }
        else
        {
            uid.append("},");
        }
    }
    uid.append("]");
    query.bindValue(8,uid);//attachments
    if(!query.exec())
    {
        qDebug()<<"importToCDOSMail"<<sqlstr<<"error";
        return -1;
    }
    readmefd.close();
    //向mailcontents添加数据
    sqlstr="insert into mailcontents(uid,category,content,attachments) values(?,?,?,?);";
    query.prepare(sqlstr);
    query.bindValue(0,QString("DataMigrationImport"+QString::number(importid)));
    query.bindValue(1,d.dirName());
    QFileInfoList infolist=Util::convenienceDir(htmldirpath);
    QFile fd;
    for(int i=0;i<infolist.count();i++)
    {
        if(infolist.at(i).suffix().contains("html"))
        {
            fd.setFileName(infolist.at(i).filePath());
            break;
        }
    }
    if(!fd.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        qDebug()<<"open file error";
        localdatabase.close();
        return -2;
    }
    QByteArray by=fd.readAll();
    int s=QString(by.data()).indexOf("charset");
    QString bu=QString(by).mid(s,20);
    if(bu.contains("gb2312",Qt::CaseSensitivity(false) ))
    {
        QTextCodec* utf8Codec= QTextCodec::codecForName("utf-8");
        QTextCodec* gb2312Codec = QTextCodec::codecForName("gb2312");

        QString strUnicode= gb2312Codec->toUnicode(by);
        QByteArray ByteUtf8= utf8Codec->fromUnicode(strUnicode);
        by=ByteUtf8;
        by.replace(s+8,6,"UTF-8");
    }
    query.bindValue(2,QString(by));
    attachmentscount.clear();
    for(int i=0;i<strlist.count();i++)
    {
        if(strlist.at(i).contains("---START---"))
        {
            attachmentscount.append(QString::number(i));
        }
    }
    uid="[";
    for(int i=0;i<attachmentscount.count();i++)
    {
        uid.append("{\"contentType\":\"");
        uid.append(strlist.at(attachmentscount.at(i).toInt()+3).section("$$$:",1,1));
        uid.append("\",\"fileName\":\"");
        uid.append(strlist.at(attachmentscount.at(i).toInt()+1).section("$$$:",1,1));
        uid.append("\",\"transferEncoding\":\"");
        uid.append(strlist.at(attachmentscount.at(i).toInt()+4).section("$$$:",1,1));
        if(!strlist.at(attachmentscount.at(i).toInt()+2).section("$$$:",1,1).contains("NONE"))
        {
            uid.append("\",\"contentId\":\"");
            QString s=strlist.at(attachmentscount.at(i).toInt()+2).section("$$$:",1,1);
            int sl=s.size();
            uid.append(s.left(sl-1).right(sl-2));
        }
        if(!strlist.at(attachmentscount.at(i).toInt()+5).section("$$$:",1,1).contains("NONE"))
        {
            uid.append("\",\"contentDisposition\":\"");
            QString s=strlist.at(attachmentscount.at(i).toInt()+5).section("$$$:",1,1);
            uid.append(s.section(";",0,0));
        }
        uid.append("\",\"generatedFileName\":\"");
        uid.append(strlist.at(attachmentscount.at(i).toInt()+1).section("$$$:",1,1));
        uid.append("\",\"length\":");
        QFileInfo in(htmldirpath+"/"+strlist.at(attachmentscount.at(i).toInt()+1).section("$$$:",1,1));
        uid.append(QString::number(in.size()));
        if(i==attachmentscount.count()-1)
        {
            uid.append("}");
        }
        else
        {
            uid.append("},");
        }
    }
    uid.append("]");
    query.bindValue(3,uid);
    if(!query.exec())
    {
        qDebug()<<"exec error";
        localdatabase.close();
        return -3;
    }
    fd.close();
    localdatabase.close();
    QString attpath=importUserpath+"/Attachments/"+QString("DataMigrationImport"+QString::number(importid));
    d.setPath(attpath);
    if(!d.exists())
    {
        d.mkpath(attpath);
    }
    for(int i=0;i<infolist.count();i++)
    {
        if(!infolist.at(i).suffix().contains("html"))
        {
            QFile::copy(infolist.at(i).filePath(),attpath+"/"+infolist.at(i).fileName());
        }
    }
    return 0;

}

int ImportToCDOSMail::check_CDOSMail_username(QStringList &namelist)
{
    QDir d(CDOSMail_path);
    if(!d.exists())
    {
        return -3;
    }
    QString sqlpath=CDOSMail_path+"/user.db";
    QSqlDatabase database;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
        database= QSqlDatabase::database("qt_sql_default_connection");
    else
        database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName(sqlpath);
    if(!database.open())
    {
        qDebug()<<"check_CDOSMail_username"<<sqlpath<<"数据库打开失败";
        return -1;
    }
    QString sql="select username from users;";
    QSqlQuery query;
    query.prepare(sql);
    if(!query.exec())
    {
        qDebug()<<"check_CDOSMail_username"<<sql<<"数据库执行失败";
        return -2;
    }
    while(query.next())
    {
        namelist.append(query.value(0).toString());
    }
    database.close();
    return 0;
}

int ImportToCDOSMail::EmailMsg_AddUserName(QStringList name, QStringList pass)
{
    QDir d(CDOSMail_path);
    if(!d.exists())
    {
        return -1;
    }
    QString sqlpath=CDOSMail_path+"/user.db";
    QSqlDatabase database;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
        database= QSqlDatabase::database("qt_sql_default_connection");
    else
        database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName(sqlpath);
    if(!database.open())
    {
        qDebug()<<"check_CDOSMail_username"<<sqlpath<<"数据库打开失败";
        return -1;
    }
    for(int i=0;i<name.count();i++)
    {
        QString sqlstr="insert into users(username,password,server,provider,smtp,smtpport,smtpssl,send,sendport,sendssl,effect,main,signature) values(?,?,?,?,?,?,?,?,?,?,?,?,?);";
        QSqlQuery query;
        query.prepare(sqlstr);
        query.bindValue(0,name.at(i));//username
        QString passaes;
        QString passa=pass.at(i);
        if(Email_AES_Crypto(name.at(i),passa,passaes,ENCRYPT))
        {
            qDebug()<<"EmailMsg_AddUserName Crypto error";
            return -1;
        }
        qDebug()<<passaes;
        query.bindValue(1,passaes);//password
        int s=name.at(i).indexOf("@");
        int e=name.at(i).indexOf(".com");
        QString server=name.at(i).mid(s+1,e-s-1);
        query.bindValue(2,server);//server
        query.bindValue(3,"imap");//provider
        QString smtp="smtp."+server+".com";
        query.bindValue(4,smtp);//smtp
        QString smtpport="465";
        query.bindValue(5,smtpport);//smtpport
        query.bindValue(6,"1");//smtpssl
        QString send="imap."+server+".com";
        query.bindValue(7,send);//send
        query.bindValue(8,"143");//sendport
        query.bindValue(9,"0");//sendssl
        query.bindValue(10,"1");//effect
        query.bindValue(11,"0");//main
        query.bindValue(12,name.at(i));//signature
        if(!query.exec())
        {
            qDebug()<<query.value(0).toString();
            return -1;
        }
    }
    database.close();
    return 0;
}

int ImportToCDOSMail::Email_AES_Crypto(QString name,QString &pass, QString &passaes, int flag)
{
    QFile fd("/opt/DataMigration/aes-encrypt.js");
    QString strall;
    if(fd.open(QIODevice::ReadOnly))
    {
        QTextStream stream(&fd);
        strall=stream.readAll();
        fd.close();
    }
    else
    {
        qDebug()<<"ImportToCDOSMail Email_AES_Crypto open read error";
        return -1;
    }
    fd.setFileName("/opt/DataMigration/aes-encrypt.js");
    if(!fd.open(QIODevice::WriteOnly))
    {
        qDebug()<<"ImportToCDOSMail Email_AES_Crypto open write error";
        return -1;
    }
    QTextStream stream(&fd);
    QStringList list=strall.split('\n');
    for(int i=0;i<list.count();i++)
    {
        if(list.at(i).contains("inputtext")&&(!list.at(i).contains("test")))
        {
            if(flag==ENCRYPT)
            {
                stream<<"var inputtext="<<"\""<<pass<<"\""<<";"<<'\n';
            }
            else
            {
                stream<<"var inputtext="<<"\""<<passaes<<"\""<<";"<<'\n';
            }
        }
        else if(list.at(i).contains("emailname")&&(!list.at(i).contains("test")))
        {
            stream<<"var emailname=\""+name<<"\";"<<'\n';
        }
        else if(list.at(i).contains("emailflag")&&(!list.at(i).contains("if(")))
        {
            if(flag==ENCRYPT)
            {
                stream<<"var emailflag=0;"<<'\n';
            }
            else
            {
                stream<<"var emailflag=1;"<<'\n';
            }

        }
        else
        {
            stream<<list.at(i)<<'\n';
        }
    }
    fd.close();
    QProcess process;
    process.start("nodejs /opt/DataMigration/aes-encrypt.js");
    if(!process.waitForStarted())
    {
        qDebug()<<"ImportToCDOSMail exec aes start error";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"ImportToCDOSMail exec aes finish error";
        return -1;
    }
    int code=process.exitCode();
    if(code!=0)
    {
        return -1;
    }
    QByteArray by1=process.readAllStandardOutput().trimmed();
    if(flag==ENCRYPT)
    {
        passaes=by1;
    }
    else
    {
        pass=by1;
    }
    return 0;
}

int ImportToCDOSMail::emltohtml(QString emldirpath, QString htmldirpath)
{
    QDir d(htmldirpath);
    d.cdUp();
    QFileInfo info(emldirpath);
    QString cmd="python /opt/DataMigration/emltohtml.py --input-dir=\""+info.filePath()+"\" --output-dir=\""+d.path()+"\"";
    d.cd(htmldirpath);
    QProcess process;
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"Thunderbird emltohtml start error";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"Thunderbird emltohtml finished error";
        return -2;
    }
    int code=process.exitCode();
    if(code==0)
        return 0;
    else
    {
        qDebug()<<cmd;
        return -1;
    }
}

int ImportToCDOSMail::psttoeml(QString pstpath, QString emlpath)
{
    QString cmd="/opt/DataMigration/readpst -e "+pstpath+" -o "+emlpath;
    qDebug()<<cmd;
    QProcess process;
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"Thunderbird psttoeml readpst start error";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"Thunderbird psttoeml readpst finished error";
        return -2;
    }
    return 0;
}

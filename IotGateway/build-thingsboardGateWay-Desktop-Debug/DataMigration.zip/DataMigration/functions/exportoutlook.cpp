#include "exportoutlook.h"

ExportOutlook::ExportOutlook()
{
}

int ExportOutlook::PstToEml(QString pstpath, QString emlpath)
{
    QString cmd="/opt/DataMigration/readpst -e "+pstpath+" -o "+emlpath;
    QProcess process;
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"Thunderbird psttoeml readpst start error";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"Thunderbird psttoeml readpst finished error";
        return -2;
    }
    int code=process.exitCode();
    if(code==0)
        return 0;
    else
    {
        qDebug()<<cmd;
        return -1;
    }
}

#include "exportcdosbrowser.h"

ExportCDOSBrowser::ExportCDOSBrowser()
{

}
int ExportCDOSBrowser::exportCDOSBrowser(QString path)
{
    //decode
    QFile readfd;
    readfd.setFileName("/opt/DataMigration/Bookmarks_de");
    if(readfd.exists())
    {
        readfd.remove();
    }
    QString cmd="/opt/DataMigration/cdos-cryptor --decode --input-file="+path+" --output-file=/opt/DataMigration/Bookmarks_de";
    QString s=Util::GetCmdRes(cmd);
    if(!s.contains("Success"))
    {
        Util::writecoreFile("ExportCDOSBrowser::exportCDOSBrowser success",s);
        return -1;
    }
    QFile *fd=new QFile("/opt/DataMigration/Bookmarks_de");
    QString pre_line;
    int index=places_id.count();
    if(!fd->open(QIODevice::ReadOnly))
    {
        qDebug()<<"extractCDOSBrowser open"<<path<<"error";
        return -1;
    }
    while(!fd->atEnd())
    {
        QString line=QString(fd->readLine().trimmed());
        QString head=line.section(":",0,0).right(5).left(4);
        if(head=="type")
        {
            head=line.section(":",1,1).right(5).left(3);
            if(head=="url")
            {
                int h=pre_line.section(":",0,0).count();
                int l=pre_line.count();
                bookmarks[index].mplaces.title=pre_line.left(l-2).right(l-h-5);
                line=QString(fd->readLine().trimmed());
                h=line.section(":",0,0).count();
                l=line.count();
                places_id.append(0);
                bookmarks[index].mfavicons.id=0;
                bookmarks[index].mplaces.favicon_id=0;
                bookmarks[index].mplaces.url=line.left(l-1).right(l-h-4);
                index++;
            }
        }
        else
        {
            pre_line=line;
        }
    }
    fd->close();
    delete fd;
    return 0;
}

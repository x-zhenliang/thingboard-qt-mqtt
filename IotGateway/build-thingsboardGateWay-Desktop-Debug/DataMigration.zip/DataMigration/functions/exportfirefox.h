#ifndef EXPORTFIREFOX_H
#define EXPORTFIREFOX_H
#include "functions/common.h"
#include <QString>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <stdlib.h>
#include <QFile>
#include <QMap>
#include <QDateTime>
#include <QThread>
#include <QProcess>
#include "tools/utils.h"
class ExportFirefox
{
public:
    ExportFirefox();
    int exportFirefox(QString path);
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
};

#endif // EXPORTFIREFOX_H

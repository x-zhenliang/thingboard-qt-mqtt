#include "firefox.h"

Firefox::Firefox()
{
}
Firefox::~Firefox()
{
}
void Firefox::_init()
{
    list_clean();
}

int Firefox::extrac_ie(QString path)
{
    QFileInfo *info=new QFileInfo(path);
    int index=places_id.count();
    places_id.append(0);
    bookmarks[index].mplaces.title=info->completeBaseName();
    bookmarks[index].mfavicons.id=0;
    bookmarks[index].mplaces.favicon_id=0;
    delete info;
    QFile *fd=new QFile(path);
    if(!fd->open(QIODevice::ReadOnly))
    {
        return -1;
    }
    while(!fd->atEnd())
    {
        QString line=QString(fd->readLine().trimmed());
        if(line.section("=",0,0)=="URL")
        {
            int l=line.count();
            int h=line.section("=",0,0).count();
            bookmarks[index].mplaces.url=line.right(l-h-1);
            break;
        }
    }
    fd->close();
    delete fd;
    return 0;
}

int Firefox::extract_bookmarks(QString path)
{
    QFile *fd=new QFile(path);
    QString pre_line;
    int index=places_id.count();
    if(!fd->open(QIODevice::ReadOnly))
    {
        qDebug()<<"extract_bookmarks open"<<path<<"error";
        return -1;
    }
    while(!fd->atEnd())
    {
        QString line=QString(fd->readLine().trimmed());
        QString head=line.section(":",0,0).right(5).left(4);
        if(head=="type")
        {
            head=line.section(":",1,1).right(5).left(3);
            if(head=="url")
            {
                int h=pre_line.section(":",0,0).count();
                int l=pre_line.count();
                bookmarks[index].mplaces.title=pre_line.left(l-2).right(l-h-5);
                line=QString(fd->readLine().trimmed());
                h=line.section(":",0,0).count();
                l=line.count();
                places_id.append(0);
                bookmarks[index].mfavicons.id=0;
                bookmarks[index].mplaces.favicon_id=0;
                bookmarks[index].mplaces.url=line.left(l-1).right(l-h-4);
                index++;
            }
        }
        else
        {
            pre_line=line;
        }
    }
    fd->close();
    delete fd;
    return 0;
}

int Firefox::extract_sqlite(QString path)
{
    //提取firefox
    int pre=places_id.count();
    QSqlDatabase database;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
      database= QSqlDatabase::database("qt_sql_default_connection");
    else
      database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName(path);
    if(!database.open())
    {
        qDebug()<<"import_firefox"<<path<<"数据库打开失败";
        return -1;
    }
    //获取所有书签ID
    QString select="select id,url from moz_places where id in (select fk from moz_bookmarks);";
    QSqlQuery query;
    query.prepare(select);
    if(!query.exec())
    {
        qDebug()<<select<<"执行错误";
        database.close();
        return -1;
    }
    while(query.next())
    {
        int id=query.value(0).toInt();
        QString url=query.value(1).toString();
        if(url.section(":",0,0)=="http"||url.section(":",0,0)=="https")
        {
            places_id.append(id);
        }
    }
    //根据ID，从moz_places中提取相应列内容
    for(int i=pre;i<places_id.count();i++)
    {
        select="select id,url,title,rev_host,visit_count,hidden,typed,favicon_id,frecency from moz_places where id="+QString::number(places_id[i])+";";
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"extract_places"<<select<<"执行失败";
            database.close();
            return -2;
        }
        while(query.next())
        {
            bookmarks[i].mplaces.id=query.value(0).toInt();
            bookmarks[i].mplaces.url=query.value(1).toString();
            bookmarks[i].mplaces.title=query.value(2).toString();
            bookmarks[i].mplaces.rev_host=query.value(3).toString();
            bookmarks[i].mplaces.visit_count=query.value(4).toInt();
            bookmarks[i].mplaces.hidden=query.value(5).toInt();
            bookmarks[i].mplaces.typed=query.value(6).toInt();
            bookmarks[i].mplaces.favicon_id=query.value(7).toInt();
            bookmarks[i].mplaces.frecency=query.value(8).toInt();
        }
    }
    //根据id，从moz_favicons中提取LOGO
    for(int i=pre;i<places_id.count();i++)
    {
        if(bookmarks[i].mplaces.favicon_id==0)
        {
            bookmarks[i].mfavicons.id=0;
            continue;
        }
        select="select id,url,data,mime_type from moz_favicons where id="+QString::number(bookmarks[i].mplaces.favicon_id)+";";
        query;
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"extract_favicons"<<select<<"执行失败";
            database.close();
            return -3;
        }
        while(query.next())
        {
            bookmarks[i].mfavicons.id=query.value(0).toInt();
            bookmarks[i].mfavicons.url=query.value(1).toString();
            bookmarks[i].mfavicons.data=query.value(2).toByteArray();
            bookmarks[i].mfavicons.mime_type=query.value(3).toString();
        }
    }
    database.removeDatabase("QSQLITE");
    database.close();
    return 0;
}

int Firefox::get_localsqlite(void)
{
    localsqlite_path.append(QString(getenv("HOME")));
    localsqlite_path.append("/.mozilla/firefox");
    QFile *fd=new QFile(localsqlite_path+"/profiles.ini");
    if(!fd->open(QIODevice::ReadOnly))
    {
        qDebug()<<"get_localsqlite_path"<<"open profiles.ini error"<<localsqlite_path;
        return -1;
    }
    while(!fd->atEnd())
    {
        QString line(fd->readLine().trimmed());
        if(line.section("=",0,0)=="Path")
        {
            localsqlite_path.append("/"+line.section("=",1,1));
            break;
        }
    }
    fd->close();
    localsqlite_path.append("/places.sqlite");
    return 0;
}

int Firefox::import_firefox()
{
    //获取本地sqlite
    if(get_localsqlite())
    {
        qDebug()<<"import_firefox get_localsqlite open error";
        return -3;
    }
    //开始导入
    QSqlDatabase localdatabase;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
      localdatabase= QSqlDatabase::database("qt_sql_default_connection");
    else
      localdatabase = QSqlDatabase::addDatabase("QSQLITE");
    localdatabase.setDatabaseName(localsqlite_path);
    if(!localdatabase.open())
    {
        qDebug()<<"import_firefox"<<localsqlite_path<<"数据库打开失败";
        return -4;
    }
    //将favicons中的LOGO添加到数据库中，并更新places.favicons_id项
    for(int i=0;i<places_id.count();i++)
    {
        if(bookmarks[i].mfavicons.id==0)
        {
            continue;
        }
        QString select="select id from moz_favicons where url='"+bookmarks[i].mfavicons.url+"';";
        QSqlQuery query;
        int id=-1;
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"import_firefox"<<select<<"执行失败";
            localdatabase.close();
            return -5;
        }
        while(query.next())
        {
            id=query.value(0).toInt();
        }
        if(id==-1)
        {//不存在相同LOGO
            select="select max(id) from moz_favicons;";
            query.prepare(select);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行失败";
                localdatabase.close();
                return -6;
            }
            while(query.next())
            {
                id=query.value(0).toInt();
            }
            id++;
            select="insert into moz_favicons(id,url,data,mime_type) values("+
                    QString::number(id)
                    +",'"+bookmarks[i].mfavicons.url+"',?,'"
                    +bookmarks[i].mfavicons.mime_type+"');";
            query.prepare(select);
            query.bindValue(0,bookmarks[i].mfavicons.data,QSql::Binary);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行失败";
                localdatabase.close();
                return -7;
            }
            qDebug()<<select<<QString::number(id);
            bookmarks[i].mplaces.favicon_id=id;
        }
        else
        {//存在相同LOGO
            bookmarks[i].mplaces.favicon_id=id;
        }
    }
    //将places添加到数据库中，并将id项更新
    for(int i=0;i<places_id.count();i++)
    {
        QString select="select id from moz_places where url='"+bookmarks[i].mplaces.url+"';";
        QSqlQuery query;
        int id=-1;
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"import_firefox"<<select<<"执行错误";
            localdatabase.close();
            return -8;
        }
        while(query.next())
        {
            id=query.value(0).toInt();
        }
        if(id==-1)
        {//不存在相同URL
            select="select max(id) from moz_places;";
            query.prepare(select);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行错误";
                localdatabase.close();
                return -9;
            }
            while(query.next())
            {
                id=query.value(0).toInt();
            }
            id++;
            select="insert into moz_places(id,url,title,rev_host,visit_count,hidden,typed,favicon_id,frecency) values("
                    +QString::number(id)+",'"
                    +bookmarks[i].mplaces.url+"','"
                    +bookmarks[i].mplaces.title+"','"
                    +bookmarks[i].mplaces.rev_host+"',"
                    +QString::number(bookmarks[i].mplaces.visit_count)+","
                    +QString::number(bookmarks[i].mplaces.hidden)+","
                    +QString::number(bookmarks[i].mplaces.typed)+","
                    +QString::number(bookmarks[i].mplaces.favicon_id)+","
                    +QString::number(bookmarks[i].mplaces.frecency)
                    +");";
            query.prepare(select);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行错误";
                localdatabase.close();
                return -10;
            }
            bookmarks[i].mplaces.id=id;
        }
        else
        {//存在相同URL
            if(bookmarks[i].mplaces.favicon_id!=0)
            {
                select="update moz_places set favicon_id="+QString::number(bookmarks[i].mplaces.favicon_id)+" where id="+QString::number(id)+";";
                query.prepare(select);
                if(!query.exec())
                {
                    qDebug()<<"import_firefox"<<select<<"执行错误";
                    localdatabase.close();
                    return -11;
                }
            }
            bookmarks[i].mplaces.id=id;
        }
    }
    //添加Datamigration****文件夹
    QString select="select max(id) from moz_bookmarks;";
    QSqlQuery query;
    int id=-1;
    query.prepare(select);
    if(!query.exec())
    {
        qDebug()<<"import_firefox"<<select<<"执行错误";
        localdatabase.close();
        return -12;
    }
    while(query.next())
    {
        id=query.value(0).toInt();
    }
    id++;
    select="insert into moz_bookmarks(id,type,fk,parent,position,title) values("
            +QString::number(id)+","
            +"2,"
            +"NULL,2,2,"
            +"'DataMigration"+QDateTime::currentDateTime().toString("yyyyMMdd")
            +"');";
    query.prepare(select);
    if(!query.exec())
    {
        qDebug()<<"import_firefox"<<select<<"执行错误";
        localdatabase.close();
        return -13;
    }
    //添加bookmarks
    for(int i=0;i<places_id.count();i++)
    {
        select="insert into moz_bookmarks(id,type,fk,parent,position,title) values("
                +QString::number(id+i+1)+",1,"
                +QString::number(bookmarks[i].mplaces.id)+","
                +QString::number(id)+",2,'"
                +bookmarks[i].mplaces.title+"'"
                +");";
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"import_firefox"<<select<<"执行错误";
            localdatabase.close();
            return -14;
        }
    }
    localdatabase.close();
    return 0;
}

int Firefox::check_firefox()
{
    sqlitepath.clear();
    Bookmarkspath.clear();
    firefox_flag=0;
    QString envpath=QString(getenv("PATH"));
    if(envpath=="")
    {
        return -2;
    }
    int i=0;
    while(1)
    {
        QString path=envpath.section(":",i,i);
        i++;
        if(path=="")
            break;
        QDir *fd=new QDir(path);
        QFileInfoList infolist=fd->entryInfoList();
        for(int j=0;j<infolist.count();j++)
        {
            if(infolist.at(j).fileName()=="firefox")
            {
                firefox_flag=1;
                return 0;
            }
        }
    }
    return -1;
}

int Firefox::check_cdosbrowser2()
{
    sqlitepath.clear();
    Bookmarkspath.clear();
    cdos_flag=0;
    QString envpath=QString(getenv("PATH"));
    if(envpath=="")
    {
        return -2;
    }
    int i=0;
    while(1)
    {
        QString path=envpath.section(":",i,i);
        i++;
        if(path=="")
            break;
        QDir *fd=new QDir(path);
        QFileInfoList infolist=fd->entryInfoList();
        for(int j=0;j<infolist.count();j++)
        {
            if(infolist.at(j).fileName()=="cdos-browser2")
            {
                cdos_flag=1;
                return 0;
            }
        }
    }
    return -1;
}

void Firefox::import_cdosbrowser2_book(QString &all,QTextStream &stream,int maxid)
{
    int id=maxid;
    maxid++;
//    stream<<" {"<<'\n';
//    stream<<"\"children\": [ "<<'\n';
    int f=0;
    for(int i=0;i<places_id.count();i++)
    {
        if(all.contains(bookmarks[i].mplaces.url))
        {
            continue;
        }
        if(f!=0)
        {
            stream<<", {"<<'\n';
        }
        else
        {
            f=1;
            stream<<"{"<<'\n';
        }
        stream<<"\"date_added\": \"\","<<'\n';
        stream<<"\"id\": \""<<maxid<<"\","<<'\n';
        maxid++;
        QString b=bookmarks[i].mplaces.title;
        stream<<"\"name\": \""<<b<<"\","<<'\n';
        stream<<"\"type\": \"url\","<<'\n';
        b=bookmarks[i].mplaces.url;
        stream<<"\"url\": \""<<b<<"\""<<'\n';
        stream<<"}";
    }
//    stream <<"],"<<'\n';
//    stream<<"\"date_added\": \"\","<<'\n';
//    stream<<"\"date_modified\": \"\","<<'\n';
//    stream<<"\"id\": \""<<id<<"\","<<'\n';
//    stream<<"\"name\": \"mytest\","<<'\n';
//    stream<<"\"type\": \"folder\""<<'\n';
//    stream<<"} "<<'\n';

}

int Firefox::import_cdosbrowser2()
{
    qDebug()<<"import_cdosbrowser2";
    //获取本地收藏夹所在位置
    QString localBookmarks_path=QString(getenv("HOME"))+"/.config/cdos-browser2/Default/Bookmarks";
    QFile readfd(localBookmarks_path);
    if(!readfd.exists())
    {
        qDebug()<<localBookmarks_path<<"not file";
        return -1;
    }
    //解密
    QProcess process;
    readfd.setFileName("./Bookmarks_de");
    if(readfd.exists())
    {
        readfd.remove();
    }
    QString cmd="./cdos-cryptor --decode --input-file="+localBookmarks_path+" --output-file=./Bookmarks_de";
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"解密失败 start";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"解密失败 finished";
        return -1;
    }
    readfd.setFileName("./Bookmarks_de");
    //导入
    QString strall;
    if(readfd.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        QTextStream stream(&readfd);
        strall=stream.readAll();
    }
    else
    {
        qDebug()<<"import_cdosbrowser2 open Bookmarks error";
        return -1;
    }
    readfd.close();
    QFile writefd("./Bookmarks_de");
    if(writefd.open(QIODevice::WriteOnly|QIODevice::Text))
    {
        QTextStream stream(&writefd);
        QStringList strlist=strall.split('\n');
        int maxid=0;
        for(int i=0;i<strlist.count();i++)
        {
            if(strlist.at(i).contains("\"id\":"))
            {
                QString l=strlist.at(i).section(":",1,1);
                int len=l.size();
                if(l.mid(2,len-4).toInt()>maxid)
                {
                    maxid=l.mid(2,len-4).toInt();
                }
            }
        }
        maxid++;
        int flag=0;
        for(int i=0;i<strlist.count();i++)
        {
            if(strlist.at(i).contains("\"children\": [")&&(flag==0))
            {
                flag=1;

                if(strlist.at(i).contains("]"))
                {//[,]在同一行
                    stream<<"\"children\": ["<<'\n';
                    import_cdosbrowser2_book(strall,stream,maxid);
                    stream<<"],"<<'\n';
                }
                else
                {
                    stream<<strlist.at(i)<<'\n';
                    if(strlist.at(i).contains("{"))
                    {
                        int cou=1;
                        i++;
                        QString line;
                        while(i<strlist.count())
                        {
                            line=strlist.at(i);
                            if(line.contains("\"children\": ["))
                            {
                                cou++;
                            }
                            if(line.contains("]"))
                            {
                                cou--;
                                if(cou==0)
                                {
                                    stream<<"},"<<'\n';
                                    import_cdosbrowser2_book(strall,stream,maxid);
                                    stream<<"],"<<'\n';
                                    break;
                                }
                            }
                            stream<<line<<'\n';
                            i++;
                        }
                    }
                    else
                    {
                        import_cdosbrowser2_book(strall,stream,maxid);
                    }
                }

            }
            else
            {
                stream<<strlist.at(i)<<'\n';
            }
        }
    }
    writefd.close();
    //加密
    readfd.setFileName(localBookmarks_path);
    if(readfd.exists())
    {
        readfd.remove();
    }
    cmd="./cdos-cryptor --encode --input-file=./Bookmarks_de --output-file="+localBookmarks_path;
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"解密失败 start";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"解密失败 finished";
        return -1;
    }
    return 0;
}

void Firefox::run()
{
    int ret=0,ieret=0,sqliteret=0,bookret=0;
    int cou=Iepath.count()+sqlitepath.count()+Bookmarkspath.count()+2;
    int ov=0;
    emit Firefox_progress_num(cou,ov);
    emit Firefox_one_progressBar_num(cou,ov);
    for(int i=0;i<Iepath.count();i++)
    {
        if(!Iepath[i].isEmpty())
        {
            if(extrac_ie(Iepath[i]))
            {
                qDebug()<<"extract_ie error";
                ieret=-3;
                break;
            }
        }
        ov++;
        emit Firefox_progress_num(cou,ov);
        emit Firefox_one_progressBar_num(cou,ov);
    }
    for(int i=0;i<sqlitepath.count();i++)
    {
        if(!sqlitepath[i].isEmpty())
        {
            if(extract_sqlite(sqlitepath[i]))
            {
                qDebug()<<"extract_sqlite error";
                sqliteret=-2;
                break;
            }
        }
        ov++;
        emit Firefox_progress_num(cou,ov);
        emit Firefox_one_progressBar_num(cou,ov);
    }
    for(int i=0;i<Bookmarkspath.count();i++)
    {
        if(!Bookmarkspath[i].isEmpty())
        {
            if(extract_bookmarks(Bookmarkspath[i]))
            {
                qDebug()<<"extract_bookmarks error";
                bookret=-3;
                break;
            }
        }
        ov++;
        emit Firefox_progress_num(cou,ov);
        emit Firefox_one_progressBar_num(cou,ov);
    }
    if(sqliteret==0&&bookret==0&&ieret==0)
    {
        if(firefox_flag==1)
        {
            if(import_firefox())
            {
                qDebug()<<"import_firefox error";
                ret=-4;
            }
            ov++;
            emit Firefox_progress_num(cou,ov);
            emit Firefox_one_progressBar_num(cou,ov);
        }
        if(cdos_flag==1)
        {
            if(import_cdosbrowser2())
            {
                qDebug()<<"import_cdosbrowser2 error";
                ret=-5;
            }
            ov++;
            emit Firefox_progress_num(cou,ov);
            emit Firefox_one_progressBar_num(cou,ov);
        }
    }
    emit Firefox_progress_num(cou,cou);
    emit Firefox_one_progressBar_num(cou,cou);
    emit Firefox_error_num(ieret,sqliteret,bookret,ret);
}

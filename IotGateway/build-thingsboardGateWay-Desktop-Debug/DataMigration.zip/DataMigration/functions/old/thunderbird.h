#ifndef THUNDERBIRD_H
#define THUNDERBIRD_H
#include <QString>
#include <QFile>
#include <QProcess>
#include <QDir>
#include <QFileDialog>
#include <QDebug>
#include <QThread>
#include <QMap>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QFileInfo>
#include <QFileInfoList>
#include <QTextCodec>
#include "tools/utils.h"
#define ENCRYPT 0
#define DECRYPT 1
class Thunderbird :public QThread
{
    Q_OBJECT
public:
    explicit Thunderbird(QObject *parent=0);
    ~Thunderbird();
    void setPstPath(QStringList path)
    {
        pstfilepath=path;
    }
    void setEmlPath(QStringList path)
    {
        emlfilepath=path;
    }
    virtual void run(void);
    int check_thunderbird(void);
    int check_CDOSMail(void);
    int check_CDOSMail_username(QStringList &namelist);
    int ImportThunderbird_init(void);
    int ImportCDOSmail_init(void);
signals:
    void Thread_error_num(int pst,int eml);
    void thunderbird_progressBar_num(int count,int over);
    void thunderbird_one_progressBar_num(int count,int over);
    void CDOSMail_AddUserName_Error();
    void CDOSMail_AddUserName_Ok();
    void CDOSMail_SelectUserName();
public slots:
    void EmailMsg_SelectUserName_Slot(QString name);
    void EmailMsg_AddUserName_Slot(QStringList name,QStringList pass);
private:
    QStringList pstfilepath;
    QStringList emlfilepath;
    QString thunderbird_path;
    QString CDOSMail_path;
    QString EmailMsg_SelectUserName;
    QStringList EmailMsg_AddUserName_Listname;
    QStringList EmailMsg_AddUserName_Listpass;

    int importeml(QString path);
    int importpst(QString path);
    int psttoeml(QString pstpath,QString emlpath);
    int emltohtml(QString emldirpath,QString htmldirpath);
    int importToCDOSMail(QString htmldirpath,QString emlpath);
    void Email_AES_Crypto(QString name,QString &pass,QString &passaes,int flag);
    int thunderbird_flag;
    int CDOSMail_flag;
};

#endif // THUNDERBIRD_H

#ifndef FIREFOX_H
#define FIREFOX_H
#include "functions/common.h"
#include <QString>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <stdlib.h>
#include <QFile>
#include <QMap>
#include <QDateTime>
#include <QThread>
#include <QProcess>
class Firefox : public QThread
{
    Q_OBJECT
public:
    Firefox();
    ~Firefox();
    void set_sqlite_path(QMap <int,QString> &path)
    {
        sqlitepath=path;
    }
    void set_Bookmarks_path(QMap <int,QString> &path)
    {
        Bookmarkspath=path;
    }
    void set_IE_path(QMap <int,QString> &path)
    {
        Iepath=path;
    }
    QMap <int,QString> get_sqlite_path(void)
    {
        return sqlitepath;
    }
    void list_clean(void)
    {
        places_id.clear();
        localsqlite_path.clear();
        bookmarks.clear();
        sqlitepath.clear();
        Bookmarkspath.clear();
        Iepath.clear();
    }
    void places_id_clean(void)
    {
        places_id.clear();
    }
    QString get_localsqlite_path(void)
    {
        return localsqlite_path;
    }

    int check_firefox(void);
    int check_cdosbrowser2(void);
    void _init(void);
    virtual void run(void);
protected:
    int import_firefox();
    int import_cdosbrowser2();
    int get_localsqlite(void);
    int extract_bookmarks(QString path);
    int extract_sqlite(QString path);
    int extrac_ie(QString path);
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
signals:
    void Firefox_error_num(int ieret,int sqliteret,int bookret,int ret);
    void Firefox_progress_num(int count,int over);

    void Firefox_one_progressBar_num(int count,int over);
private:
    QString localsqlite_path;
    QMap<int,QString> sqlitepath;
    QMap<int,QString> Bookmarkspath;
    QMap<int,QString> Iepath;
    int firefox_flag,cdos_flag;
    void import_cdosbrowser2_book(QString &all,QTextStream &stream,int maxid);
};

#endif // Firefox_H

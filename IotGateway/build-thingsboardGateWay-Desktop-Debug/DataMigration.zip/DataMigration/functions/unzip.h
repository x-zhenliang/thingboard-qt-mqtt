#ifndef UNZIP_H
#define UNZIP_H

#include <QThread>
//#include "JlCompress.h"
#include <QProcess>
#include <QDebug>
#include <QDir>
#include "tools/utils.h"
class Unzip : public QThread
{
    Q_OBJECT
public:
    explicit Unzip(QObject *parent = 0);
    QString zippath;
    QString topath;
    virtual void run();
signals:
    void unzip_start();
    void unzip_end();
    void unzip_error(QString name);
    void unzip_current_stat(QString cu);
public slots:
    void unzip_read();
    void unzip_finished(int code);
private:
    QProcess *process;
    int unzip_exit;
};

#endif // UNZIP_H

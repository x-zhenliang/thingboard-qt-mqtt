#ifndef IMPORTTOCDOSBROWSER2_H
#define IMPORTTOCDOSBROWSER2_H

#include "functions/common.h"
#include <QString>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <stdlib.h>
#include <QFile>
#include <QMap>
#include <QDateTime>
#include <QThread>
#include <QProcess>
#include "tools/utils.h"

class ImportToCDOSBrowser2
{
public:
    ImportToCDOSBrowser2();
    int check_cdosbrowser2(void);
    int ImportCDOSBrowser2_init(void);
    int importCDOSBrowser2(void);
    void SetImportBuf(QMap<int,Bookmarks> &bbuf,QList<int> pbuf)
    {
        bookmarks=bbuf;
        places_id=pbuf;
    }
private:
    void import_cdosbrowser2_book(QString &all,QTextStream &stream,int maxid);
    QString localBookmarks_path;
    int CDOSBrowser2flag;
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
};

#endif // IMPORTTOCDOSBROWSER2_H

#include "importtofirefox.h"

ImportToFirefox::ImportToFirefox()
{
}

int ImportToFirefox::ImportFirefox_init()
{
    localsqlite_path.clear();
    localsqlite_path.append(QString(getenv("HOME")));
    localsqlite_path.append("/.mozilla/firefox");
    QFile *fd=new QFile(localsqlite_path+"/profiles.ini");
    if(!fd->open(QIODevice::ReadOnly))
    {
        qDebug()<<"get_localsqlite_path"<<"open profiles.ini error"<<localsqlite_path;
        return -1;
    }
    while(!fd->atEnd())
    {
        QString line(fd->readLine().trimmed());
        if(line.section("=",0,0)=="Path")
        {
            localsqlite_path.append("/"+line.section("=",1,1));
            break;
        }
    }
    fd->close();
    localsqlite_path.append("/places.sqlite");
    return 0;
}

int ImportToFirefox::check_firefox()
{
    firefoxflag=0;
    QString envpath=QString(getenv("PATH"));
    if(envpath=="")
    {
        return -2;
    }
    int i=0;
    while(1)
    {
        QString path=envpath.section(":",i,i);
        i++;
        if(path=="")
            break;
        QDir *fd=new QDir(path);
        QFileInfoList infolist=fd->entryInfoList();
        for(int j=0;j<infolist.count();j++)
        {
            if(infolist.at(j).fileName()=="firefox")
            {
                firefoxflag=1;
                return 0;
            }
        }
    }
    return -1;
}

int ImportToFirefox::importFirefox()
{
    //开始导入
    QSqlDatabase localdatabase;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
      localdatabase= QSqlDatabase::database("qt_sql_default_connection");
    else
      localdatabase = QSqlDatabase::addDatabase("QSQLITE");
    localdatabase.setDatabaseName(localsqlite_path);
    if(!localdatabase.open())
    {
        qDebug()<<"import_firefox"<<localsqlite_path<<"数据库打开失败";
        return -4;
    }
    //将favicons中的LOGO添加到数据库中，并更新places.favicons_id项
    for(int i=0;i<places_id.count();i++)
    {
        if(bookmarks[i].mfavicons.id==0)
        {
            continue;
        }
        QString select="select id from moz_favicons where url='"+bookmarks[i].mfavicons.url+"';";
        QSqlQuery query;
        int id=-1;
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"import_firefox"<<select<<"执行失败";
            localdatabase.close();
            return -5;
        }
        while(query.next())
        {
            id=query.value(0).toInt();
        }
        if(id==-1)
        {//不存在相同LOGO
            select="select max(id) from moz_favicons;";
            query.prepare(select);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行失败";
                localdatabase.close();
                return -6;
            }
            while(query.next())
            {
                id=query.value(0).toInt();
            }
            id++;
            select="insert into moz_favicons(id,url,data,mime_type) values("+
                    QString::number(id)
                    +",'"+bookmarks[i].mfavicons.url+"',?,'"
                    +bookmarks[i].mfavicons.mime_type+"');";
            query.prepare(select);
            query.bindValue(0,bookmarks[i].mfavicons.data,QSql::Binary);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行失败";
                localdatabase.close();
                return -7;
            }
            qDebug()<<select<<QString::number(id);
            bookmarks[i].mplaces.favicon_id=id;
        }
        else
        {//存在相同LOGO
            bookmarks[i].mplaces.favicon_id=id;
        }
    }
    //将places添加到数据库中，并将id项更新
    for(int i=0;i<places_id.count();i++)
    {
        QString select="select id from moz_places where url='"+bookmarks[i].mplaces.url+"';";
        QSqlQuery query;
        int id=-1;
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"import_firefox"<<select<<"执行错误";
            localdatabase.close();
            return -8;
        }
        while(query.next())
        {
            id=query.value(0).toInt();
        }
        if(id==-1)
        {//不存在相同URL
            select="select max(id) from moz_places;";
            query.prepare(select);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行错误";
                localdatabase.close();
                return -9;
            }
            while(query.next())
            {
                id=query.value(0).toInt();
            }
            id++;
            select="insert into moz_places(id,url,title,rev_host,visit_count,hidden,typed,favicon_id,frecency) values("
                    +QString::number(id)+",'"
                    +bookmarks[i].mplaces.url+"','"
                    +bookmarks[i].mplaces.title+"','"
                    +bookmarks[i].mplaces.rev_host+"',"
                    +QString::number(bookmarks[i].mplaces.visit_count)+","
                    +QString::number(bookmarks[i].mplaces.hidden)+","
                    +QString::number(bookmarks[i].mplaces.typed)+","
                    +QString::number(bookmarks[i].mplaces.favicon_id)+","
                    +QString::number(bookmarks[i].mplaces.frecency)
                    +");";
            query.prepare(select);
            if(!query.exec())
            {
                qDebug()<<"import_firefox"<<select<<"执行错误";
                localdatabase.close();
                return -10;
            }
            bookmarks[i].mplaces.id=id;
        }
        else
        {//存在相同URL
            if(bookmarks[i].mplaces.favicon_id!=0)
            {
                select="update moz_places set favicon_id="+QString::number(bookmarks[i].mplaces.favicon_id)+" where id="+QString::number(id)+";";
                query.prepare(select);
                if(!query.exec())
                {
                    qDebug()<<"import_firefox"<<select<<"执行错误";
                    localdatabase.close();
                    return -11;
                }
            }
            bookmarks[i].mplaces.id=id;
        }
    }
    //添加Datamigration****文件夹
    QString select="select max(id) from moz_bookmarks;";
    QSqlQuery query;
    int id=-1;
    query.prepare(select);
    if(!query.exec())
    {
        qDebug()<<"import_firefox"<<select<<"执行错误";
        localdatabase.close();
        return -12;
    }
    while(query.next())
    {
        id=query.value(0).toInt();
    }
    id++;
    select="insert into moz_bookmarks(id,type,fk,parent,position,title) values("
            +QString::number(id)+","
            +"2,"
            +"NULL,2,2,"
            +"'DataMigration"+QDateTime::currentDateTime().toString("yyyyMMdd")
            +"');";
    query.prepare(select);
    if(!query.exec())
    {
        qDebug()<<"import_firefox"<<select<<"执行错误";
        localdatabase.close();
        return -13;
    }
    //添加bookmarks
    for(int i=0;i<places_id.count();i++)
    {
        select="insert into moz_bookmarks(id,type,fk,parent,position,title) values("
                +QString::number(id+i+1)+",1,"
                +QString::number(bookmarks[i].mplaces.id)+","
                +QString::number(id)+",2,'"
                +bookmarks[i].mplaces.title+"'"
                +");";
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"import_firefox"<<select<<"执行错误";
            localdatabase.close();
            return -14;
        }
    }
    localdatabase.close();
    return 0;
}

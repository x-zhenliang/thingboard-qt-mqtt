#include "functions/createconfigure.h"
#include "tools/utils.h"
#include <QSettings>
#include <QCoreApplication>
#include <QDir>
#include <QDebug>


ConfigureDirTool::ConfigureDirTool(QString organName, QString appName )
{
    this->organization = organName;
    this->application = appName;
    QCoreApplication::setOrganizationName(organization);
    QCoreApplication::setApplicationName(application);
}

ConfigureDirTool::~ConfigureDirTool()
{

}

void ConfigureDirTool::createIniFile(int s)
{
    QCoreApplication::setOrganizationName(organization);
    QCoreApplication::setApplicationName(application);
    if(!s)
    {
        return ;
    }
    Util::writeInitFile(HOME,DEFAULT,QString(getenv("HOME")));
    Util::writeInitFile(DOCUMENT_GROUNP,DEFAULT,Util::getUserDocDir());
    Util::writeInitFile(PICTURE_GROUNP,DEFAULT, Util::getSysPictureDir());
    Util::writeInitFile(VIDEO_GROUNP,DEFAULT, Util::getSysVideoDir());
    Util::writeInitFile(MUSIC_GROUNP,DEFAULT, Util::getSysMusicDir());
    Util::writeInitFile(DESTINATION_GROUNP,DEFAULT, Util::readDstFileFromIni());
    Util::writeInitFile(LANGUAGE_DEFAULT,DEFAULT,"CN");
}

bool ConfigureDirTool::makeDstDir()
{
    QString readDstDir;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());

    appSetting->beginGroup(DESTINATION_GROUNP);
    readDstDir = appSetting->value("DEFAULT").toString();
    appSetting->endGroup();
    delete appSetting;
    bool   mkDstDirFlag;
    QDir *dstDir = new QDir();
    bool dstExist = dstDir->exists(readDstDir);
    if (dstExist)
    {
        return true;
    }
    else
    {
        mkDstDirFlag = dstDir->mkdir(readDstDir);
        if (mkDstDirFlag)
            return true;
        else
            return false;
    }
}

bool ConfigureDirTool::check()
{
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    QString path=appSetting->fileName();
    return QFileInfo(path).exists();
}



#ifndef IMPORTTOTHUNDERBIRD_H
#define IMPORTTOTHUNDERBIRD_H

#include <QThread>
#include <QFileInfo>
#include <QFileInfoList>
#include <QDir>
#include <QDebug>
#include <QProcess>
#include "tools/utils.h"
class ImportToThunderbird
{
public:
    ImportToThunderbird();
    int check_thunderbird(void);
    int ImportThunderbird_init(void);
    int ImportThunderbird(QString path);
private:
    int importeml(QString path);
    int importpst(QString path);
    int thunderbird_flag;
    QString thunderbird_path;
};

#endif // IMPORTTOTHUNDERBIRD_H

#ifndef EXPORTCDOSBROWSER_H
#define EXPORTCDOSBROWSER_H
#include "functions/common.h"
#include <QString>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <stdlib.h>
#include <QFile>
#include <QMap>
#include <QDateTime>
#include <QThread>
#include <QProcess>
#include "tools/utils.h"

class ExportCDOSBrowser
{
public:
    ExportCDOSBrowser();
    int exportCDOSBrowser(QString path);
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
};

#endif // EXPORTCDOSBROWSER_H

#include "exportie.h"

ExportIE::ExportIE()
{
}

int ExportIE::exportIE(QString path)
{
    QFileInfo *info=new QFileInfo(path);
    int index=places_id.count();
    places_id.append(0);
    bookmarks[index].mplaces.title=info->completeBaseName();
    bookmarks[index].mfavicons.id=0;
    bookmarks[index].mplaces.favicon_id=0;
    delete info;
    QFile *fd=new QFile(path);
    if(!fd->open(QIODevice::ReadOnly))
    {
        qDebug()<<"exportIE open"<<path<<"error";
        return -1;
    }
    while(!fd->atEnd())
    {
        QString line=QString(fd->readLine().trimmed());
        if(line.section("=",0,0)=="URL")
        {
            int l=line.count();
            int h=line.section("=",0,0).count();
            bookmarks[index].mplaces.url=line.right(l-h-1);
            break;
        }
    }
    fd->close();
    delete fd;
    return 0;
}

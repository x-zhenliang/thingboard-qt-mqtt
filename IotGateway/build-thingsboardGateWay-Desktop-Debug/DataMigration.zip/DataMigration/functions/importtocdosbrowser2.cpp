#include "importtocdosbrowser2.h"

ImportToCDOSBrowser2::ImportToCDOSBrowser2()
{
}

int ImportToCDOSBrowser2::check_cdosbrowser2()
{
    CDOSBrowser2flag=0;
    QString envpath=QString(getenv("PATH"));
    if(envpath=="")
    {
        return -2;
    }
    int i=0;
    while(1)
    {
        QString path=envpath.section(":",i,i);
        i++;
        if(path=="")
            break;
        QDir *fd=new QDir(path);
        QFileInfoList infolist=fd->entryInfoList();
        for(int j=0;j<infolist.count();j++)
        {
            if(infolist.at(j).fileName()=="cdos-browser2")
            {
                CDOSBrowser2flag=1;
                return 0;
            }
        }
    }
    return -1;
}

int ImportToCDOSBrowser2::ImportCDOSBrowser2_init()
{
    localBookmarks_path=QString(getenv("HOME"))+"/.config/cdos-browser2/Default/Bookmarks";
    QFile readfd(localBookmarks_path);
    if(!readfd.exists())
    {
        Util::copyFileTo("/opt/DataMigration/Bookmarks",localBookmarks_path,true);
        Util::writecoreFile("CDOSBrowser2Init",localBookmarks_path+" not file");
        QString ss=QString(getenv("HOME"))+"/.config/cdos-browser2";
        Util::checkDirown(ss);
    }
    return 0;
}

void ImportToCDOSBrowser2::import_cdosbrowser2_book(QString &all,QTextStream &stream,int maxid)
{
    int id=maxid;
    maxid++;
//    stream<<" {"<<'\n';
//    stream<<"\"children\": [ "<<'\n';
    int f=0;
    for(int i=0;i<places_id.count();i++)
    {
        if(all.contains(bookmarks[i].mplaces.url))
        {
            continue;
        }
        if(f!=0)
        {
            stream<<", {"<<'\n';
        }
        else
        {
            f=1;
            stream<<"{"<<'\n';
        }
        stream<<"\"date_added\": \"\","<<'\n';
        stream<<"\"id\": \""<<maxid<<"\","<<'\n';
        maxid++;
        QString b=bookmarks[i].mplaces.title;
        stream<<"\"name\": \""<<b<<"\","<<'\n';
        stream<<"\"type\": \"url\","<<'\n';
        b=bookmarks[i].mplaces.url;
        stream<<"\"url\": \""<<b<<"\""<<'\n';
        stream<<"}";
    }
//    stream <<"],"<<'\n';
//    stream<<"\"date_added\": \"\","<<'\n';
//    stream<<"\"date_modified\": \"\","<<'\n';
//    stream<<"\"id\": \""<<id<<"\","<<'\n';
//    stream<<"\"name\": \"mytest\","<<'\n';
//    stream<<"\"type\": \"folder\""<<'\n';
//    stream<<"} "<<'\n';

}

int ImportToCDOSBrowser2::importCDOSBrowser2()
{
    QFile readfd;
    //解密
    QProcess process;
    readfd.setFileName("/opt/DataMigration/Bookmarks_de");
    if(readfd.exists())
    {
        readfd.remove();
    }
    QString cmd="/opt/DataMigration/cdos-cryptor --decode --input-file="+localBookmarks_path+" --output-file=/opt/DataMigration/Bookmarks_de";
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"解密失败 start";
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"解密失败 finished";
        return -1;
    }
    readfd.setFileName("/opt/DataMigration/Bookmarks_de");
    //导入
    QString strall;
    if(readfd.open(QIODevice::ReadOnly|QIODevice::Text))
    {
        QTextStream stream(&readfd);
        strall=stream.readAll();
    }
    else
    {
        qDebug()<<"import_cdosbrowser2 open Bookmarks error";
        return -1;
    }
    readfd.close();
    QFile writefd("/opt/DataMigration/Bookmarks_de");
    if(writefd.open(QIODevice::WriteOnly|QIODevice::Text))
    {
        QTextStream stream(&writefd);
        QStringList strlist=strall.split('\n');
        int maxid=0;
        for(int i=0;i<strlist.count();i++)
        {
            if(strlist.at(i).contains("\"id\":"))
            {
                QString l=strlist.at(i).section(":",1,1);
                int len=l.size();
                if(l.mid(2,len-4).toInt()>maxid)
                {
                    maxid=l.mid(2,len-4).toInt();
                }
            }
        }
        maxid++;
        int flag=0;
        for(int i=0;i<strlist.count();i++)
        {
            if(strlist.at(i).contains("\"children\": [")&&(flag==0))
            {
                flag=1;

                if(strlist.at(i).contains("]"))
                {//[,]在同一行
                    stream<<"\"children\": ["<<'\n';
                    import_cdosbrowser2_book(strall,stream,maxid);
                    stream<<"],"<<'\n';
                }
                else
                {
                    stream<<strlist.at(i)<<'\n';
                    if(strlist.at(i).contains("{"))
                    {
                        int cou=1;
                        i++;
                        QString line;
                        while(i<strlist.count())
                        {
                            line=strlist.at(i);
                            if(line.contains("\"children\": ["))
                            {
                                cou++;
                            }
                            if(line.contains("]"))
                            {
                                cou--;
                                if(cou==0)
                                {
                                    stream<<"},"<<'\n';
                                    import_cdosbrowser2_book(strall,stream,maxid);
                                    stream<<"],"<<'\n';
                                    break;
                                }
                            }
                            stream<<line<<'\n';
                            i++;
                        }
                    }
                    else
                    {
                        import_cdosbrowser2_book(strall,stream,maxid);
                    }
                }

            }
            else
            {
                stream<<strlist.at(i)<<'\n';
            }
        }
    }
    //加密
    readfd.setFileName(localBookmarks_path);
    if(readfd.exists())
    {
        readfd.remove();
    }
    cmd="/opt/DataMigration/cdos-cryptor --encode --input-file=/opt/DataMigration/Bookmarks_de --output-file="+localBookmarks_path;
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"解密失败 start";
        writefd.remove();
        writefd.close();
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"解密失败 finished";
        writefd.remove();
        writefd.close();
        return -1;
    }
    writefd.remove();
    writefd.close();
    return 0;
}

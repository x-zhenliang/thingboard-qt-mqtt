#include "browserfavorites.h"

BrowserFavorites::BrowserFavorites(QObject *parent) :
    QThread(parent)
{
}

int BrowserFavorites::BrowserFavorites_Init()
{
    imFirefox_flag=imFirefox.check_firefox();
    imCDOSBrowser2_flag=imCDOSBrowser2.check_cdosbrowser2();
    if(!imFirefox_flag||!imCDOSBrowser2_flag)
    {
        return 0;
    }
    else
    {
        qDebug()<<"BrowserFavorites check error";
        return -1;
    }
}

void BrowserFavorites::run()
{
    places_id.clear();
    bookmarks.clear();
    exIe.places_id.clear();
    exIe.bookmarks.clear();
    exFirefox.places_id.clear();
    exFirefox.bookmarks.clear();
    exChrome.places_id.clear();
    exChrome.bookmarks.clear();
//    exCDOSBrowser.places_id.clear();
//    exCDOSBrowser.bookmarks.clear();
    QList<int> ret;
    QList<QString> retname;
    int currentover=0;
    int allcount=IEFavoritesPath.count()+FirefoxFavoritesPath.count()+ChromeFavoritesPath.count();//+CDOSBrowserFavoritesPath.count();
    if(!imFirefox_flag)
    {
        allcount++;
    }
    if(!imCDOSBrowser2_flag)
    {
        allcount++;
    }
    for(int i=0;i<IEFavoritesPath.count();i++)
    {
        if(!IEFavoritesPath.at(i).isEmpty())
        {
            int r=exIe.exportIE(IEFavoritesPath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(IEFavoritesPath.at(i));
            }
            currentover++;
            emit BrowserFavorites_progress_num(allcount,currentover);
        }
    }
    for(int i=0;i<FirefoxFavoritesPath.count();i++)
    {
        if(!FirefoxFavoritesPath.at(i).isEmpty())
        {
            int r=exFirefox.exportFirefox(FirefoxFavoritesPath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(FirefoxFavoritesPath.at(i));
            }
            currentover++;
            emit BrowserFavorites_progress_num(allcount,currentover);
        }
    }
    for(int i=0;i<ChromeFavoritesPath.count();i++)
    {
        if(!ChromeFavoritesPath.at(i).isEmpty())
        {
            int r=exChrome.exportChrome(ChromeFavoritesPath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(ChromeFavoritesPath.at(i));
            }
            currentover++;
            emit BrowserFavorites_progress_num(allcount,currentover);
        }
    }
//    for(int i=0;i<CDOSBrowserFavoritesPath.count();i++)
//    {
//        if(!CDOSBrowserFavoritesPath.at(i).isEmpty())
//        {
//            int r=exCDOSBrowser.exportCDOSBrowser(CDOSBrowserFavoritesPath.at(i));
//            if(r)
//            {
//                ret.append(r);
//                retname.append(CDOSBrowserFavoritesPath.at(i));
//            }
//            currentover++;
//            emit BrowserFavorites_progress_num(allcount,currentover);
//        }
//    }
    places_id.append(exIe.places_id);
    places_id.append(exFirefox.places_id);
    places_id.append(exChrome.places_id);
//    places_id.append(exCDOSBrowser.places_id);
//    Util::writecoreFile("e",QString::number(exCDOSBrowser.places_id.count()));
    QList<int> k=exIe.bookmarks.keys();
    for(int i=0;i<k.count();i++)
    {
        bookmarks[k.at(i)]=exIe.bookmarks[k.at(i)];
    }
    k=exFirefox.bookmarks.keys();
    for(int i=0;i<k.count();i++)
    {
        int index=k.at(i)+exIe.places_id.count();
        bookmarks[index]=exFirefox.bookmarks[k.at(i)];
    }
    k=exChrome.bookmarks.keys();
    for(int i=0;i<k.count();i++)
    {
        int index=k.at(i)+exFirefox.places_id.count()+exIe.places_id.count();
        bookmarks[index]=exChrome.bookmarks[k.at(i)];
    }
//    k=exCDOSBrowser.bookmarks.keys();
//    for(int i=0;i<k.count();i++)
//    {
//        int index=k.at(i)+exFirefox.places_id.count()+exIe.places_id.count()+exChrome.places_id.count();
//        bookmarks[index]=exCDOSBrowser.bookmarks[k.at(i)];
//    }
    if(!imFirefox_flag)
    {
        int r=imFirefox.ImportFirefox_init();
        if(r)
        {
            ret.append(r);
            retname.append("ImportFirefox_init error");
        }
        else
        {
            imFirefox.SetImportBuf(bookmarks,places_id);
            r=imFirefox.importFirefox();
            if(r)
            {
                ret.append(r);
                retname.append("ImportFirefox error");
            }
        }
        currentover++;
        emit BrowserFavorites_progress_num(allcount,currentover);
    }
    if(!imCDOSBrowser2_flag)
    {
        int r=imCDOSBrowser2.ImportCDOSBrowser2_init();
        if(r)
        {
            ret.append(r);
            retname.append("ImportCDOSBrowser2_init error");
        }
        else
        {
            imCDOSBrowser2.SetImportBuf(bookmarks,places_id);
            r=imCDOSBrowser2.importCDOSBrowser2();
            if(r)
            {
                ret.append(r);
                retname.append("ImportCDOSBrowser2 error");
            }
        }
        currentover++;
        emit BrowserFavorites_progress_num(allcount,currentover);
    }
    emit BrowserFavorites_progress_num(allcount,allcount);
    if(!ret.isEmpty())
    {
        emit BrowserFavorites_error_num(ret,retname);
    }
    else
    {
        emit BrowserFavorites_success();
    }
}

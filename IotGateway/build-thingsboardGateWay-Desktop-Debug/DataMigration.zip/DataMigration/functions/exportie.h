#ifndef EXPORTIE_H
#define EXPORTIE_H
#include "functions/common.h"
#include <QString>
#include <QFileDialog>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>
#include <QList>
#include <stdlib.h>
#include <QFile>
#include <QMap>
#include <QDateTime>
#include <QThread>
#include "tools/utils.h"
#include <QProcess>
class ExportIE
{
public:
    ExportIE();
    int exportIE(QString path);
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
};

#endif // EXPORTIE_H

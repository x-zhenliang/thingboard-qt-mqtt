#include "exportfirefox.h"

ExportFirefox::ExportFirefox()
{
}

int ExportFirefox::exportFirefox(QString path)
{
    //提取firefox
    int pre=places_id.count();
    QSqlDatabase database;
    if(QSqlDatabase::contains("qt_sql_default_connection"))
        database= QSqlDatabase::database("qt_sql_default_connection");
    else
        database = QSqlDatabase::addDatabase("QSQLITE");
    database.setDatabaseName(path);
    if(!database.open())
    {
        qDebug()<<"exportFirefox"<<path<<"数据库打开失败";
        return -1;
    }
    //获取所有书签ID
    QString select="select id,url from moz_places where id in (select fk from moz_bookmarks);";
    QSqlQuery query;
    query.prepare(select);
    if(!query.exec())
    {
        qDebug()<<select<<"执行错误";
        database.close();
        return -1;
    }
    while(query.next())
    {
        int id=query.value(0).toInt();
        QString url=query.value(1).toString();
        if(url.section(":",0,0)=="http"||url.section(":",0,0)=="https")
        {
            places_id.append(id);
        }
    }
    //根据ID，从moz_places中提取相应列内容
    for(int i=pre;i<places_id.count();i++)
    {
        select="select id,url,title,rev_host,visit_count,hidden,typed,favicon_id,frecency from moz_places where id="+QString::number(places_id[i])+";";
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"exportFirefox"<<select<<"执行失败";
            database.close();
            return -2;
        }
        while(query.next())
        {
            bookmarks[i].mplaces.id=query.value(0).toInt();
            bookmarks[i].mplaces.url=query.value(1).toString();
            bookmarks[i].mplaces.title=query.value(2).toString();
            bookmarks[i].mplaces.rev_host=query.value(3).toString();
            bookmarks[i].mplaces.visit_count=query.value(4).toInt();
            bookmarks[i].mplaces.hidden=query.value(5).toInt();
            bookmarks[i].mplaces.typed=query.value(6).toInt();
            bookmarks[i].mplaces.favicon_id=query.value(7).toInt();
            bookmarks[i].mplaces.frecency=query.value(8).toInt();
        }
    }
    //根据id，从moz_favicons中提取LOGO
    for(int i=pre;i<places_id.count();i++)
    {
        if(bookmarks[i].mplaces.favicon_id==0)
        {
            bookmarks[i].mfavicons.id=0;
            continue;
        }
        select="select id,url,data,mime_type from moz_favicons where id="+QString::number(bookmarks[i].mplaces.favicon_id)+";";
        query;
        query.prepare(select);
        if(!query.exec())
        {
            qDebug()<<"exportFirefox"<<select<<"执行失败";
            database.close();
            return -3;
        }
        while(query.next())
        {
            bookmarks[i].mfavicons.id=query.value(0).toInt();
            bookmarks[i].mfavicons.url=query.value(1).toString();
            bookmarks[i].mfavicons.data=query.value(2).toByteArray();
            bookmarks[i].mfavicons.mime_type=query.value(3).toString();
        }
    }
    database.removeDatabase("QSQLITE");
    database.close();
    return 0;
}

#include "emaildatamigration.h"

EmailDataMigration::EmailDataMigration(QObject *parent) :
    QThread(parent)
{
}

int EmailDataMigration::EmailDataMigration_init()
{
    if(!thunderbird_flag)
    {
        if(imThunderbird.ImportThunderbird_init())
        {
            qDebug()<<"EmailDataMigration_init Thunderbird error";
            return -1;
        }
    }
    if(!CDOSMail_flag)
    {
        if(imCDOSMail.ImportCDOSMail_init())
        {
            qDebug()<<"EmailDataMigration_init CDOSMail error";
            return -1;
        }
    }
    return 0;
}

int EmailDataMigration::EmailDataMigration_Check_Client()
{
    thunderbird_flag=imThunderbird.check_thunderbird();
//    CDOSMail_flag=imCDOSMail.check_CDOSMail();
    CDOSMail_flag=-1;
    if(thunderbird_flag)
    {
        if(CDOSMail_flag)
        {//0
            qDebug()<<"not find";
            return -1;
        }
        else
        {
            qDebug()<<"CDOSMail";
            return -2;
        }
    }
    else
    {
        if(CDOSMail_flag)
        {
            qDebug()<<"Thunderbird";
            return -3;
        }
        else
        {
            qDebug()<<"CDOSMail Thunderbird";
            return 0;
        }
    }
}

void EmailDataMigration::EmailMsg_SelectUserName_Slot(QString name)
{
    imCDOSMail.EmailMsg_SelectUserName=name;
    emit CDOSMail_SelectUserName();
    return ;
}

void EmailDataMigration::EmailMsg_AddUserName_Slot(QStringList name, QStringList pass)
{
    if(imCDOSMail.EmailMsg_AddUserName(name,pass))
    {
        emit CDOSMail_AddUserName_Error();
    }
    else
    {
        emit CDOSMail_AddUserName_Ok();
    }
}

void EmailDataMigration::run()
{
    int filecount=pstfilepath.count()+emlfilepath.count();
    if(thunderbird_flag==1&&CDOSMail_flag==1)
    {
        filecount*=2;
    }
    filecount+=1;
    qDebug()<<filecount;
    int cur=0;
    emit EmailDataMigtation_progressBar_num(filecount,cur);
    cur++;
    QList<int> ret;
    QList<QString> retname;
    if(thunderbird_flag==0)
    {
        qDebug()<<"import thunderbird";
        for(int i=0;i<pstfilepath.count();i++)
        {
            int r=imThunderbird.ImportThunderbird(pstfilepath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(pstfilepath.at(i));
            }
            emit EmailDataMigtation_progressBar_num(filecount,cur);
            cur++;
        }
        for(int i=0;i<emlfilepath.count();i++)
        {
            int r=imThunderbird.ImportThunderbird(emlfilepath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(emlfilepath.at(i));
            }
            emit EmailDataMigtation_progressBar_num(filecount,cur);
            cur++;
        }
    }
    if(CDOSMail_flag==0)
    {
        qDebug()<<"import CDOSMail";
        for(int i=0;i<pstfilepath.count();i++)
        {
            int r=imCDOSMail.ImportCDOSMail(pstfilepath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(pstfilepath.at(i));
            }
            emit EmailDataMigtation_progressBar_num(filecount,cur);
            cur++;
        }
        for(int i=0;i<emlfilepath.count();i++)
        {
            int r=imCDOSMail.ImportCDOSMail(emlfilepath.at(i));
            if(r)
            {
                ret.append(r);
                retname.append(emlfilepath.at(i));
            }
            emit EmailDataMigtation_progressBar_num(filecount,cur);
            cur++;
        }
    }
    emit EmailDataMigtation_progressBar_num(filecount,filecount);
    if(ret.isEmpty())
    {
        emit EmailDataMigration_success();
    }
    else
    {
        emit EmailDataMigtation_error_num(ret,retname);
    }
}

int EmailDataMigration::EmailDataMigration_check_CDOSMail_username(QStringList &namelist)
{
    return imCDOSMail.check_CDOSMail_username(namelist);
}




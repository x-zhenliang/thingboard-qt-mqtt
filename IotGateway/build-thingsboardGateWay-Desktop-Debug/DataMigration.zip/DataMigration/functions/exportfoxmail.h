#ifndef EXPORTFOXMAIL_H
#define EXPORTFOXMAIL_H

#include <QStringList>
#include <QString>
#include "tools/utils.h"
class ExportFoxmail
{
public:
    ExportFoxmail();
    QStringList emlFilePath;
};

#endif // EXPORTFOXMAIL_H

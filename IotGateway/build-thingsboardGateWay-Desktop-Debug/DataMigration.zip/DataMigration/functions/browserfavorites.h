#ifndef BROWSERFAVORITES_H
#define BROWSERFAVORITES_H

#include <QThread>
#include <QStringList>
#include "functions/exportchrome.h"
#include "functions/exportfirefox.h"
#include "functions/exportie.h"
#include "functions/importtofirefox.h"
#include "tools/utils.h"
#include "functions/importtocdosbrowser2.h"
#include "functions/exportcdosbrowser.h"
class BrowserFavorites : public QThread
{
    Q_OBJECT
public:
    explicit BrowserFavorites(QObject *parent = 0);
    int BrowserFavorites_Init(void);
    virtual void run(void);
    //邮件源文件路径
    QStringList ChromeFavoritesPath;
    QStringList CDOSBrowserFavoritesPath;
    QStringList FirefoxFavoritesPath;
    QStringList IEFavoritesPath;
signals:
    void BrowserFavorites_error_num(QList<int> ret,QList<QString> retname);
    void BrowserFavorites_progress_num(int count,int over);
    void BrowserFavorites_success(void);
private:
    ExportChrome exChrome;
    ExportFirefox exFirefox;
    ExportIE exIe;
//    ExportCDOSBrowser exCDOSBrowser;
    //邮件提取内容缓存
    ImportToCDOSBrowser2 imCDOSBrowser2;
    ImportToFirefox imFirefox;
    QMap<int,Bookmarks> bookmarks;
    QList<int> places_id;
    int imFirefox_flag;
    int imCDOSBrowser2_flag;
};

#endif // BROWSERFAVORITES_H

#ifndef EMAILDATAMIGRATION_H
#define EMAILDATAMIGRATION_H

#include <QThread>
#include <QStringList>
#include "functions/exportoutlook.h"
#include "functions/exportfoxmail.h"
#include "functions/importtocdosmail.h"
#include "tools/utils.h"
#include "functions/importtothunderbird.h"
class EmailDataMigration : public QThread
{
    Q_OBJECT
public:
    explicit EmailDataMigration (QObject *parent = 0);
    int EmailDataMigration_init(void);
    int EmailDataMigration_Check_Client(void);
    int EmailDataMigration_check_CDOSMail_username(QStringList &namelist);
    virtual void run(void);
    int thunderbird_flag;
    int CDOSMail_flag;
    QStringList pstfilepath;
    QStringList emlfilepath;
signals:
    void EmailDataMigtation_error_num(QList<int> ret,QList<QString> retname);
    void EmailDataMigtation_progressBar_num(int count,int over);
    void EmailDataMigration_success(void);
    void CDOSMail_AddUserName_Error();
    void CDOSMail_AddUserName_Ok();
    void CDOSMail_SelectUserName();
public slots:
    void EmailMsg_SelectUserName_Slot(QString name);
    void EmailMsg_AddUserName_Slot(QStringList name,QStringList pass);
private:
    ExportOutlook exOutlook;
    ExportFoxmail exFoxmail;
    ImportToThunderbird imThunderbird;
    ImportToCDOSMail imCDOSMail;
};

#endif // EMAILDATAMIGRATION_H

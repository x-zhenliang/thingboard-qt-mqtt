#include "importtothunderbird.h"

ImportToThunderbird::ImportToThunderbird()
{
}

int ImportToThunderbird::check_thunderbird()
{
    thunderbird_flag=0;
    QString envpath=QString(getenv("PATH"));
    if(envpath.isEmpty())
    {
        return -2;
    }
    int i=0;
    while(1)
    {
        QString path=envpath.section(":",i,i);
        i++;
        if(path=="")
            break;
        QDir *fd=new QDir(path);
        QFileInfoList infolist=fd->entryInfoList();
        for(int j=0;j<infolist.count();j++)
        {
            if(infolist.at(j).fileName()=="thunderbird")
            {
                thunderbird_flag=1;
                return 0;
            }
        }
    }
    return -1;
}

int ImportToThunderbird::ImportThunderbird_init()
{
    thunderbird_path=QString(getenv("HOME"));
    if(thunderbird_path.isEmpty())
    {
        qDebug()<<"ImportToThunderbird_init get HOME";
        return -1;
    }
    thunderbird_path.append("/.thunderbird");
    QFile *fd=new QFile(thunderbird_path+"/profiles.ini");
    if(!fd->exists())
    {
        qDebug()<<"ImportToThunderbird_init profiles.ini not find";
        return -2;
    }
    if(!fd->open(QIODevice::ReadOnly))
    {
        qDebug()<<"ImportToThunderbird_init open .ini";
        return -3;
    }
    while(!fd->atEnd())
    {
        QByteArray by=fd->readLine().trimmed();
        QString line(by);
        if(line.section("=",0,0)=="Path")
        {
            thunderbird_path.append("/"+line.section("=",1,1)+"/Mail");
            break;
        }
    }
    if(fd->atEnd())
    {
        qDebug()<<"ImportToThunderbird_init read .ini at end";
        return -4;
    }
    fd->close();
    QDir *dir=new QDir(thunderbird_path);
    QFileInfoList list=dir->entryInfoList();
    int i;
    for(i=0;i<list.size();i++)
    {
        QFileInfo info=list.at(i);
        if(info.isDir()&&(info.fileName().indexOf("Local\ Folders")>=0))
        {
            thunderbird_path.append("/"+info.fileName());
            break;
        }
    }
    return 0;
}

int ImportToThunderbird::importeml(QString path)
{
    QFile *fd=new QFile(path);
    if(!(fd->open(QIODevice::ReadOnly)))
    {
        qDebug()<<"ImportToThunderbird Importeml"<<path<<"error";
        return -1;
    }
    QByteArray by=fd->readAll();
    time_t t;
    time(&t);
    char *c_time=asctime(gmtime(&t));
    QString topath;
    QString scanpath;
    fd->seek(0);
    while(!fd->atEnd())
    {
        QString buf=QString(fd->readLine().trimmed());
        if(buf.section(":",0,0)=="X-Original-To")
        {
            topath=buf;
        }
        if(buf.section(":",0,0)=="Return-Path")
        {
            scanpath=buf;
        }
        if((!scanpath.isEmpty())&&(!topath.isEmpty()))
        {
            break;
        }
    }
    fd->close();
    QString b;
    if(!topath.isEmpty())
    {
        int l=topath.section(":",1,1).size();
        b=topath.section(":",1,1).right(l-1)+QString("INBOX");
    }
    else
    {
        b="INBOX";
    }
    fd->setFileName(thunderbird_path+"/"+b);
    if(!(fd->exists()))
    {//Inbox不存在
        fd->open(QIODevice::ReadWrite);
        fd->close();
    }
    if(!(fd->open(QIODevice::ReadWrite)))
    {
        qDebug()<<"ImportToThunderbird Importeml open"<<thunderbird_path+"/Inbox"<<"error";
        return -2;
    }
    fd->seek(fd->size());
    QByteArray From("From ");
    if(!scanpath.isEmpty())
    {
        From.append("\"");
        int l=scanpath.section(":",1,1).size();
        From.append(scanpath.section(":",1,1).left(l-1).right(l-2));
        From.append("\" ");
    }
    else
    {
        From.append("-");
    }
    From.append(c_time);
    fd->write(From);
    fd->write(by);
    fd->close();
    return 0;
}

int ImportToThunderbird::importpst(QString path)
{
    QFileInfo *fileinfo=new QFileInfo(path);
    QString fileinfopath=fileinfo->path()+"/readpstbuf";
    QDir *m=new QDir(fileinfo->path());
    m->mkdir(fileinfopath);
    QString cmd="/opt/DataMigration/readpst -u "+path+" -o "+fileinfopath;
    QProcess process;
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"ImportToThunderbird Importpst readpst start error";
        Util::writecoreFile("importpststart","ImportToThunderbird Importpst readpst start error");
        return -1;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"ImportToThunderbird Importpst readpst finished error";
        Util::writecoreFile("importpstfinished","ImportToThunderbird Importpst readpst finished error");
        return -2;
    }
    int code=process.exitCode();
    if(code!=0)
    {
        qDebug()<<cmd;
        Util::writecoreFile("importcmd",cmd);
        return -3;
    }
    QDir *d=new QDir(fileinfopath);
    QFileInfoList l=d->entryInfoList();
    QString pstdirname;
    for(int i=0;i<l.size();i++)
    {
        QFileInfo info=l.at(i);
        if(info.isDir()&&info.fileName()!="."&&info.fileName()!="..")
        {
            pstdirname=info.fileName();
            break;
        }
    }

    QString pstdir=QString(fileinfopath+"/"+pstdirname);
    QDir *dir= new QDir(pstdir);
    QFileInfoList list=dir->entryInfoList();
    for(int i=0;i<list.size();i++)
    {
        QFileInfo info=list.at(i);
        if(info.isDir()&&info.fileName()!="."&&info.fileName()!="..")
        {
            QString path=thunderbird_path+"/"+fileinfo->completeBaseName()+info.fileName();
            QFile *fd=new QFile(path);
            if(!fd->open(QIODevice::ReadWrite))
            {
                qDebug()<<"ImportToThunderbird Importpst open"<<path<<"error";
                Util::writecoreFile("importpstopen1","ImportToThunderbird Importpst open "+path+" error");
                return -4;
            }
            path=info.filePath()+"/mbox";
            QFile *fdy=new QFile(info.filePath()+"/mbox");
            if(!fdy->open(QIODevice::ReadWrite))
            {
                qDebug()<<"ImportToThunderbird Importpst open"<<path<<"error";
                Util::writecoreFile("importpstopen2","ImportToThunderbird Importpst open "+path+" error");
                return -5;
            }
            fd->write(fdy->readAll());
            fdy->close();
            fd->close();
        }
    }
    cmd="rm "+fileinfopath+" -r";
    process.start(cmd);
    if(!process.waitForStarted())
    {
        qDebug()<<"ImportToThunderbird Importpst rm start error";
        Util::writecoreFile("importpstrmstart","ImportToThunderbird Importpst rm start error");
        return -6;
    }
    if(!process.waitForFinished())
    {
        qDebug()<<"ImportToThunderbird Importpst rm finish error";
        Util::writecoreFile("importpstrmfinished","ImportToThunderbird Importpst rm finish error");
        return -7;
    }
    return 0;
}

int ImportToThunderbird::ImportThunderbird(QString path)
{
    QFileInfo info(path);
    if(!info.exists())
    {
        qDebug()<<path<<"not find";
        Util::writecoreFile("ImportThunderbirdpath",path+" not find");
        return -1;
    }
    if(info.suffix().contains("pst"))
    {
        int pstret=importpst(path);
        if(pstret)
        {
            qDebug()<<path<<"Import error";
            Util::writecoreFile("ImportThunderbirdpst",path+" import error");
            return -3;
        }
    }
    else if(info.suffix().contains("eml"))
    {
        int ret=importeml(path);
        if(ret)
        {
            qDebug()<<path<<"Import error";
            Util::writecoreFile("ImportThunderbirdeml",path+" import error");
            return -4;
        }
    }
    else
    {
        qDebug()<<path<<"格式不正确";
        Util::writecoreFile("ImportThunderbirdstat",path+" GeShi");
        return -2;
    }
    return 0;
}

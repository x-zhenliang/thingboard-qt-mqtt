#ifndef USERDATA_H
#define USERDATA_H

#include <QObject>
#include <QThread>
#include <QDir>
#include <QFileInfo>
#include <QFileInfoList>
#include "tools/utils.h"
#include <QDebug>
#define USERDATA_DOC 3
#define USERDATA_MUS 2
#define USERDATA_VID 1
#define USERDATA_PIC 0
#define USERDATA_ONE 4
class UserData : public QObject
{
    Q_OBJECT
public:
    explicit UserData(QObject *parent = 0);
    QStringList CopyList;
    QMap<QString,QString> CopytoDst;
    int current_index;
signals:
    void UserDataCopy_Error_name(int c,QStringList path);
    void UserData_progress_num(int c,int over);
    void UserData_Copyover_name(int c,QString name,int f);
    void UserData_currentCopy_name(int c,QString name);

    void UserData_progress_onekey_num(int count,int over);
public slots:
    void CopyFileToPath(void);
};

#endif // USERDATA_H

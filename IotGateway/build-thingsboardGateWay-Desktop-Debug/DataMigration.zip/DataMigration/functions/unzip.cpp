#include "unzip.h"

Unzip::Unzip(QObject *parent) :
    QThread(parent)
{

}

void Unzip::run()
{
    process=new QProcess();
    unzip_exit=1;
    connect(process,SIGNAL(readyRead()),this,SLOT(unzip_read()));
    connect(process,SIGNAL(finished(int)),this,SLOT(unzip_finished(int)));
    emit unzip_start();
    QDir d;
    d.setPath(topath+"/DataMigration");
    if(d.exists())
    {
        Util::DelDir(topath+"/DataMigration");
    }
    d.mkdir(topath+"/DataMigration");
    QString cmd="/opt/DataMigration/7zr X "+zippath+" -o"+topath;
    process->start(cmd);
    if(!process->waitForStarted())
    {
        QString e=zippath+" unzip start error";
        emit unzip_error(e);
        qDebug()<<e;
        return ;
    }
    if(!process->waitForFinished(60000*100000))
    {
        QString e=zippath+" unzip finish error";
        emit unzip_error(e);
        qDebug()<<e;
        return ;
    }
    Util::checkDirown(topath+"/DataMigration");
    emit unzip_end();
}

void Unzip::unzip_read()
{
    QString cu=QString(process->read(1024*1024).trimmed());
    if(!cu.isEmpty())
    {
        emit unzip_current_stat(cu);
    }
}

void Unzip::unzip_finished(int code)
{
    qDebug()<<code;
}

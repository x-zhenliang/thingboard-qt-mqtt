#ifndef UTIL_H
#define UTIL_H

#include <QMap>
#include <QSettings>
#include <QCoreApplication>
#include <QFileInfoList>
#include "functions/common.h"
#include <QProcess>
class QString;

class Util
{
public:
    static bool copyFileTo(QString src_file, QString dst_path, bool coverFileIfExist);
    static bool copyDirTo(const QString &src_dir, const QString &dst_dir, bool coverFileIfExist);
    static QMap<QString, QString> findFiles(QString filename, QString path);
    static QMap<QString, QString> findDirs(QString dirname, QString path);
    static QStringList findDirPath(QString dirname,QString path);
    static QList< QString > findFileList(QString filename, QString path);
    static QString DestinationPath(void);
    static QFileInfoList convenienceDir(QString dirPath);
    static bool writecoreFile(QString userKey, QString userValue);
    static bool readInitFile( QString userGroup, QString userKey, QString &userValue);
    static bool writeInitFile(QString userGroup, QString userKey, QString userValue);
    static bool DelDir(const QString &path);
    static QString getSysMusicDir();
    static QString getSysPictureDir();
    static QString getSysVideoDir();
    static QString getUserDocDir();
    static QString readDstFileFromIni();
    static int checkDirown(QString path);
    static QString getcurrentlanguage();
    static QString GetCmdRes(QString cmd);
};

#endif // UTIL_H

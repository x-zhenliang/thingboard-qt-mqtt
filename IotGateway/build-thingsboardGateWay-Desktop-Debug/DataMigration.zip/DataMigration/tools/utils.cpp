#include "utils.h"
#include <QString>
#include <QDir>
#include <QDebug>
#include <QFile>
#include <QFileInfo>
#include <QMap>



bool Util::copyFileTo(QString src_file, QString dst_path, bool coverFileIfExist)
{
    if(src_file == dst_path)
        return true;
    if (!QFile::exists(src_file))
        return false;

    QDir *targetfile =  new QDir;
    QFileInfo *info = new QFileInfo(dst_path);
    bool file_exist = targetfile->exists(dst_path);
    if (file_exist)
    {
        if(coverFileIfExist)
        {
            targetfile->remove(dst_path);
        }
    }
    else
    {
        if(!(targetfile->exists(info->path())))
        {
            targetfile->mkpath(info->path());
        }
    }
    if(!QFile::copy(src_file, dst_path))
    {
        qDebug()<<"Copy Failed...";
        return false;
    }
    return true;
}

bool Util::copyDirTo(const QString &src_dir, const QString &dst_dir, bool coverFileIfExist)
{
    QDir source(src_dir);
    QDir target(dst_dir);
    if(!target.exists())  /*如果目标不存在，就进行创建*/
    {
        if(!target.mkdir(target.absolutePath()))  /*如果目标路径创建不成功，返回false*/
            return false;
    }
    QFileInfoList srcFileInfoList = source.entryInfoList();
    foreach (QFileInfo fileInfo, srcFileInfoList)
    {
        if(fileInfo.fileName() == "." || fileInfo.fileName() == "..")
            continue;
        if(fileInfo.isDir()) /*子目录的情况，递归进行复制*/
        {
            if( !copyDirTo(fileInfo.filePath(), target.filePath(fileInfo.fileName()), coverFileIfExist))
                return false;
        }
        else
        {
            if(coverFileIfExist && target.exists(fileInfo.fileName()))
                target.remove(fileInfo.fileName());

            if( !QFile::copy(fileInfo.filePath(), target.filePath(fileInfo.fileName())))
                return false;
        }
    }
    return true;
}


QMap<QString, QString> Util::findFiles(QString filename, QString path)
{
    QDir currentDir;
    QMap<QString, QString> FilePath;
    currentDir = QDir(path);
    QStringList files;
    QString     file_path;
    if (filename.isEmpty())
        filename = "*.pst";

    files = currentDir.entryList(QStringList(filename),QDir::Files | QDir::NoSymLinks);
    if(!files.isEmpty())
    {
        for(int i = 0; i < files.size(); ++i)
        {
            file_path = currentDir.absoluteFilePath(files[i]);
            FilePath.insert(files[i], file_path);
        }
        return FilePath;
    }
}

QMap<QString, QString> Util::findDirs(QString dirName, QString path)
{
    QMap<QString, QString> dirPath;
    QDir    searchDir;
    QString file_path;
    QStringList dirList;
    QStringList resultList;

    searchDir = QDir(path);
    dirList = searchDir.entryList(QDir::Dirs, QDir::Name);
    resultList = dirList.filter(dirName);
    if (!resultList.isEmpty())
    {
        for(int i = 0; i < resultList.size(); ++i)
        {
            file_path = searchDir.absoluteFilePath(resultList[i]);
            dirPath.insert(resultList[i],file_path);
        }
        return dirPath;
    }
}

QString Util::DestinationPath()
{
    QSettings *appSettings=new QSettings(QSettings::IniFormat,QSettings::UserScope,QCoreApplication::organizationName(),QCoreApplication::applicationName());
    appSettings->beginGroup(DESTINATION_GROUNP);
    QString desPath=appSettings->value(DEFAULT).toString();
    return desPath;
}

QList< QString > Util::findFileList(QString filename, QString path)
{
    QDir scanDir(path);
    QString filesPath;
    QStringList filesName;
    QList < QString > totalFilesList;
    filesName = scanDir.entryList(QStringList(filename), QDir::Files | QDir::NoSymLinks);
    if(!filesName.isEmpty())
    {
        for (int i=0; i < filesName.size(); ++i)
        {
            filesPath = scanDir.absoluteFilePath(filesName[i]);
            totalFilesList.append(filesPath);
        }
    }
    return totalFilesList;
}


QFileInfoList Util::convenienceDir(QString dirPath)
{
    QFileInfoList relist;
    QDir *dir=new QDir();
    dir->setPath(dirPath);
    QFileInfoList infolist=dir->entryInfoList();
    for(int i=0;i<infolist.count();i++)
    {
        QFileInfo info=infolist.at(i);
        if(info.fileName()=="."||info.fileName()=="..")
        {
            continue;
        }
        if(info.isDir())
        {
            QFileInfoList inl=convenienceDir(info.filePath());
            for(int j=0;j<inl.count();j++)
            {
                relist.append(inl.at(j));
            }
        }
        else
        {
            relist.append(info);
        }
    }
    delete dir;
    return relist;
}
bool Util::writeInitFile(QString userGroup, QString userKey, QString userValue)
{
     QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
     if(userGroup.isEmpty() || userKey.isEmpty() || userKey.isEmpty())
     {
         delete appSetting;
         return false;
     }
     else
     {
         appSetting->beginGroup(userGroup);
         appSetting->setValue(userKey, userValue);
         appSetting->endGroup();
         delete appSetting;
         return true;
     }
}

 bool Util::readInitFile( QString userGroup, QString userKey, QString &userValue)
 {
      QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
      userValue = QString("");
      if(userGroup.isEmpty() || userKey.isEmpty() )
      {
          return false;
          delete appSetting;
      }
      else
      {
          appSetting->beginGroup(userGroup);
          userValue = appSetting->value(userKey).toString();
          appSetting->endGroup();
          delete appSetting;
          return true;
      }
 }
bool Util::writecoreFile(QString userKey, QString userValue)
 {
     QString userGroup=QDateTime::currentDateTime().toString("yyyyMMddhhmmss");
     QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), "core");
     if(userGroup.isEmpty() || userKey.isEmpty() || userKey.isEmpty())
     {
         delete appSetting;
         return false;
     }
     else
     {
         appSetting->beginGroup(userGroup);
         appSetting->setValue(userKey, userValue);
         appSetting->endGroup();
         delete appSetting;
         return true;
     }
 }

bool Util::DelDir(const QString &path)
{
    if (path.isEmpty()){
        return false;
    }
    QDir dir(path);
    if(!dir.exists()){
        return true;
    }
    dir.setFilter(QDir::AllEntries | QDir::NoDotAndDotDot); //设置过滤
    QFileInfoList fileList = dir.entryInfoList(); // 获取所有的文件信息
    foreach (QFileInfo file, fileList){ //遍历文件信息
        if (file.isFile()){ // 是文件，删除
            file.dir().remove(file.fileName());
        }else{ // 递归删除
            DelDir(file.absoluteFilePath());
        }
    }
    return dir.rmpath(dir.absolutePath()); // 删除文件夹
}

QString Util::getUserDocDir()
{
    QString dstPath;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(DOCUMENT_GROUNP);
    dstPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
    if(dstPath.isEmpty())
    {
        QString def=QString(getenv("HOME"))+"/DataMigrationOut/Documents";
        return def;
    }
    return dstPath;
}

QString Util::getSysPictureDir()
{
    QString dstPath;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(PICTURE_GROUNP);
    dstPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
    if(dstPath.isEmpty())
    {
        QString def=QString(getenv("HOME"))+"/DataMigrationOut/Pictures";
        return def;
    }
    return dstPath;
}

QString Util::getSysVideoDir()
{
    QString dstPath;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(VIDEO_GROUNP);
    dstPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
    if(dstPath.isEmpty())
    {
        QString def=QString(getenv("HOME"))+"/DataMigrationOut/Videos";
        return def;
    }
    return dstPath;
}

QString Util::getSysMusicDir()
{
    QString dstPath;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(MUSIC_GROUNP);
    dstPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
    if(dstPath.isEmpty())
    {
        QString def=QString(getenv("HOME"))+"/DataMigrationOut/Musics";
        return def;
    }
    return dstPath;
}

QString Util::readDstFileFromIni()
{
    QString dstPath;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(DESTINATION_GROUNP);
    dstPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
    return dstPath;
}

int Util::checkDirown(QString path)
{
    QString home;
    if(!Util::readInitFile(HOME,DEFAULT,home))
    {
        home=QString(getenv("HOME"));
    }
    QStringList l=home.split("/");
    QString user=l.last();
    QString cmd="chown -R "+user+":"+user+" "+path;
    writecoreFile("CHOWN",cmd);
    FILE *pf;
    char buff[1000]={};
    QString res = "";
    pf = popen(cmd.toStdString().c_str(), "r");
    //fread(buff,sizeof(buff),sizeof(buff),pf);
    while(!feof(pf))
    {
        fread(buff,sizeof(buff)-1,1,pf);
        res += QString(buff);
        // qDebug()<<buff;
        memset(buff,0,sizeof(buff));
    }
    pclose(pf);
    //qDebug()<<res;
    writecoreFile("CHOWNRES",res);
    return 0;
}

QStringList Util::findDirPath(QString dirname, QString path)
{
    QDir d(path);
    QStringList dirlist;
    QFileInfoList list=d.entryInfoList();;
    foreach(QFileInfo a,list)
    {
        if(a.isDir())
        {
            if(a.fileName()==dirname)
            {
                dirlist.append(a.filePath());
            }
            QStringList listbuf=findDirPath(dirname,a.filePath());
            foreach(QFileInfo b,listbuf)
            {
                dirlist.append(b.filePath());
            }
        }
    }
    return dirlist;
}

QString Util::getcurrentlanguage()
{
    QString dstPath;
    QSettings *appSetting = new QSettings(QSettings::IniFormat, QSettings::UserScope, QCoreApplication::organizationName(), QCoreApplication::applicationName());
    appSetting->beginGroup(LANGUAGE_DEFAULT);
    dstPath = appSetting->value(DEFAULT).toString();
    appSetting->endGroup();
    delete appSetting;
    return dstPath;
}

QString Util::GetCmdRes(QString cmd)
{
    FILE *pf;
    char buff[1000]={};
    QString res = "";
    pf = popen(cmd.toStdString().c_str(), "r");
    //fread(buff,sizeof(buff),sizeof(buff),pf);
    while(!feof(pf))
    {
        fread(buff,sizeof(buff)-1,1,pf);
        res += QString(buff);
       // qDebug()<<buff;
        memset(buff,0,sizeof(buff));
    }
    pclose(pf);
    return res;
}

